﻿# Finds the folder of 'Machine Party.exe' through the Steam libraries (app 4108000).

function Find-GameDir {
	$steam = (Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction SilentlyContinue).SteamPath
	if (-not $steam) { return $null }
	$libraries = @($steam.Replace("/", "\"))
	$vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
	if (Test-Path $vdf) {
		foreach ($line in Get-Content $vdf) {
			if ($line -match '"path"\s+"(.+)"') { $libraries += $Matches[1].Replace("\\", "\") }
		}
	}
	foreach ($library in ($libraries | Select-Object -Unique)) {
		$manifest = Join-Path $library "steamapps\appmanifest_4108000.acf"
		if (-not (Test-Path $manifest)) { continue }
		$installdir = $null
		foreach ($line in Get-Content $manifest) {
			if ($line -match '"installdir"\s+"(.+)"') { $installdir = $Matches[1] }
		}
		if (-not $installdir) { continue }
		$root = Join-Path $library "steamapps\common\$installdir"
		$exe = Get-ChildItem -Path $root -Recurse -Filter "Machine Party.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
		if ($exe) { return $exe.DirectoryName }
	}
	return $null
}
