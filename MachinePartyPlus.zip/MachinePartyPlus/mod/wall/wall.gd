extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LE MUR: steel walls slide across the deck from the back. Each one has door holes (step in) and low bars
## (jump over). Anyone the wall catches is pushed ahead of it, toward the open front edge. The walls get faster,
## the doors narrower, and late in the game they come in pairs. Last one standing wins.
##
## The host draws each wall and broadcasts it; every peer slides it on its own clock and pushes the runners it
## simulates, so nobody waits on the network to be blocked.

const HALF_X: float = 7.0
const HALF_Z: float = 6.0
const SLOTS: int = 14
const WALL_HEIGHT: float = 2.2
const WALL_THICK: float = 0.5
const BAR_HEIGHT: float = 0.45
const START_Z: float = -10.0
const END_Z: float = 10.0
enum Slot { SOLID, DOOR, BAR }

# id -> {"node": Node3D, "pattern": Array, "speed": float, "z": float}
var walls: Dictionary = {}
var next_id: int = 0
var spawn_timer: float = 2.0
var mat_panel: Material
var mat_frame: Material

func spawn_points() -> Array[Vector3]:
	return [Vector3(-4.5, 0.1, 2.0), Vector3(4.5, 0.1, 2.0), Vector3(-1.5, 0.1, 3.5), Vector3(1.5, 0.1, 3.5), Vector3(0, 0.1, 1.0)]

func spawn_yaw(_index: int) -> float:
	return PI

func build_arena():

	max_duration = 120.0
	set_camera(Vector3(0.0, 9.0, 11.0), Vector3(0.0, 0.3, -1.2))

	add_sound("ambience", "res://audio/unique/chisel gauntlet/machine ambience.ogg", -8.0, true)
	add_sound("horn", "res://audio/sfx/escalator_pit_fail_alert.ogg", -6.0)
	add_sound("push", "res://audio/unique/disco dodge/dd fall scream impact.ogg", -4.0)

	# the junk platform compactors stand on both sides like the walls' stores
	add_backdrop_model("res://minigames/junk_platform/models/junk platform compactors3/junk platform compactors3.glb", Vector3(-16.0, -12.0, -16.0))
	add_backdrop_model("res://minigames/junk_platform/models/junk platform compactors3/junk platform compactors3.glb", Vector3(16.0, -12.0, -16.0), 180.0)

	mat_panel = DA.base_material(DA.TEX_METAL, Color(1.1, 1.05, 1.0), 0.45)
	mat_frame = DA.kind_material("mp_hazard")

	var deck_material: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_HAZARD, Color(0.95, 0.93, 0.9), 1.0 / 7.0)
	add_box(Vector3(HALF_X * 2.0, 0.6, HALF_Z * 2.0), Vector3(0.0, -0.3, 0.0), deck_material)
	# side rails: the only ways off are the front and the back
	for side in [-1.0, 1.0]:
		add_box(Vector3(0.3, 0.9, HALF_Z * 2.0), Vector3(side * (HALF_X + 0.15), 0.45, 0.0), mat_frame)
	# the guide rails the walls slide on
	for side in [-1.0, 1.0]:
		add_box(Vector3(0.4, 0.4, 24.0), Vector3(side * (HALF_X + 0.6), 0.2, 0.0), DA.kind_material("mp_dark"), null, false)
	# danger strip along the front edge
	add_box(Vector3(HALF_X * 2.0, 0.05, 0.4), Vector3(0.0, 0.02, HALF_Z - 0.2), unshaded(Color(1.0, 0.2, 0.1)), null, false)

	add_key_lights(Vector3(0.0, 11.0, 2.0), 95.0, 28.0)
	add_light(Vector3(0.0, 4.0, -12.0), Color(1.0, 0.5, 0.2), 20.0, 16.0)
	add_light(Vector3(0.0, 10.0, -16.0), Color(0.56, 0.545, 0.485), 40.0, 30.0)

	if Engine.has_meta("mpplus_preview"):
		spawn_wall_rpc(0, make_pattern(), 0.0)
		walls[0].z = -2.5
		walls[0].node.position.z = -2.5

func on_play_start_local():
	fade_in_ambience()

func server_tick(delta: float):

	spawn_timer -= delta
	if spawn_timer > 0.0:
		return

	var speed: float = min(2.2 + play_time * 0.03, 5.0)
	spawn_wall_rpc.rpc(next_id, make_pattern(), speed)
	next_id += 1
	# late game: the next wall follows closely
	var gap: float = 9.0 if play_time < 40.0 else (6.0 if play_time < 75.0 else 4.5)
	spawn_timer = gap / speed

## A wall: a few door holes, maybe a bar to jump. Fewer and narrower doors as time goes.
func make_pattern() -> Array:
	var pattern: Array = []
	pattern.resize(SLOTS)
	pattern.fill(Slot.SOLID)
	var door_width: int = 2 if play_time < 50.0 else 1
	var doors: int = clampi(3 - int(play_time / 30.0), 1, 3)
	var bars: int = 1 if play_time > 15.0 else 0
	if play_time > 60.0:
		bars = 2
	var free: Array = range(SLOTS)
	free.shuffle()
	for i in doors + bars:
		var start: int = free[i]
		var width: int = door_width if i < doors else 3
		for k in width:
			var slot: int = clampi(start + k, 0, SLOTS - 1)
			pattern[slot] = Slot.DOOR if i < doors else Slot.BAR
	return pattern

@rpc("authority", "call_local", "reliable")
func spawn_wall_rpc(id: int, pattern: Array, speed: float):
	play_sound("horn")
	var node := Node3D.new()
	node.position = Vector3(0.0, 0.0, START_Z)
	arena.add_child(node)
	var slot_width: float = HALF_X * 2.0 / SLOTS
	for i in SLOTS:
		var x: float = - HALF_X + (i + 0.5) * slot_width
		match pattern[i]:
			Slot.SOLID:
				add_box(Vector3(slot_width, WALL_HEIGHT, WALL_THICK), Vector3(x, WALL_HEIGHT * 0.5, 0.0), mat_panel, node, false)
			Slot.BAR:
				add_box(Vector3(slot_width, BAR_HEIGHT, WALL_THICK), Vector3(x, BAR_HEIGHT * 0.5, 0.0), unshaded(Color(1.0, 0.75, 0.1)), node, false)
				add_box(Vector3(slot_width, 0.5, WALL_THICK), Vector3(x, WALL_HEIGHT - 0.25, 0.0), mat_panel, node, false)
			Slot.DOOR:
				add_box(Vector3(slot_width, 0.5, WALL_THICK), Vector3(x, WALL_HEIGHT - 0.25, 0.0), mat_panel, node, false)
				add_box(Vector3(slot_width, 0.04, WALL_THICK + 0.2), Vector3(x, 0.02, 0.0), unshaded(Color(0.2, 1.0, 0.35)), node, false)
	add_box(Vector3(HALF_X * 2.0 + 0.6, 0.25, WALL_THICK + 0.1), Vector3(0.0, WALL_HEIGHT + 0.12, 0.0), mat_frame, node, false)
	var lamp := OmniLight3D.new()
	lamp.position = Vector3(0.0, WALL_HEIGHT + 0.8, 0.0)
	lamp.light_color = Color(1.0, 0.55, 0.2)
	lamp.light_energy = 4.0
	lamp.omni_range = 7.0
	node.add_child(lamp)
	walls[id] = {"node": node, "pattern": pattern, "speed": speed, "z": START_Z}

func visual_tick(delta: float):

	for id in walls.keys():
		var wall: Dictionary = walls[id]
		wall.z += wall.speed * delta
		wall.node.position.z = wall.z
		if wall.z > END_Z:
			wall.node.queue_free()
			walls.erase(id)

	if not running:
		return

	for player in local_runners():
		for wall in walls.values():
			push_from_wall(player, wall)

## Catch the runners standing in the wall's way and carry them ahead of it.
func push_from_wall(player, wall: Dictionary):
	var pos: Vector3 = player.global_position
	var depth: float = pos.z - wall.z
	var reach: float = WALL_THICK * 0.5 + 0.35
	if abs(depth) > reach:
		return
	var slot: int = clampi(int((pos.x + HALF_X) / (HALF_X * 2.0 / SLOTS)), 0, SLOTS - 1)
	match wall.pattern[slot]:
		Slot.DOOR:
			# the door frame still catches anyone straddling its edge
			var center: float = - HALF_X + (slot + 0.5) * (HALF_X * 2.0 / SLOTS)
			if abs(pos.x - center) < 0.55 or neighbour_is_door(wall.pattern, slot, pos.x - center):
				return
		Slot.BAR:
			if pos.y > BAR_HEIGHT - 0.05:
				return
	if depth >= -0.1:
		# caught on the wall's face: carried along
		player.global_position.z = wall.z + reach
		if player.shove_velocity.length() < 1.0:
			sfx_rpc.rpc("push")
			player.shove_velocity = Vector3(0.0, 0.0, wall.speed * 0.6)
	else:
		player.global_position.z = wall.z - reach

func neighbour_is_door(pattern: Array, slot: int, offset: float) -> bool:
	var other: int = slot + (1 if offset > 0.0 else -1)
	return other >= 0 and other < SLOTS and pattern[other] == Slot.DOOR
