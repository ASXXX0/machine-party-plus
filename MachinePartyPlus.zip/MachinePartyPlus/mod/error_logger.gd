extends Logger

## Copies engine and script errors into mod.log as they happen. The game's own godot.log is only written out
## when the game quits cleanly, so errors before a crash or a kill would otherwise be lost.

var file: FileAccess
var mutex := Mutex.new()

func _init(_file: FileAccess) -> void :
	file = _file

func _log_error(function: String, file_name: String, line: int, code: String, rationale: String, _editor_notify: bool, error_type: int, _script_backtrace: Array[ScriptBacktrace]) -> void :
	mutex.lock()
	if file:
		file.store_line("ERROR[%d] %s (%s:%d %s) %s" % [error_type, rationale if rationale != "" else code, file_name, line, function, code if rationale != "" else ""])
		file.flush()
	mutex.unlock()

func _log_message(_message: String, _error: bool) -> void :
	pass
