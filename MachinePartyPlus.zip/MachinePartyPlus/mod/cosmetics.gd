extends Node

## Machine Party Overtime cosmetics: three hats made in Blender (welding helmet, beacon hard hat, gear crown).
## - Every character's CustomizationAssigner gets them as soon as it enters the tree, before its _ready assigns
##   the saved hat; the game's own assign_hat then shows them by name, also for remote players with the mod.
##   (Patching customization_assigner.gd does not work: the game loads that class before the patcher runs.)
## - The customization screen gets three more slots, built from its last slot.

const DA = preload("user://mods/machine_party_unlocked/da_kit.gd")

# name -> [glb, height offset on top of the game's hard hat placement]
const HATS: Dictionary = {
	"mp_welding": ["hat_welding.glb", -0.07],
	"mp_beacon": ["hat_beacon.glb", 0.0],
	"mp_gear_crown": ["hat_gear_crown.glb", -0.06],
}
# the character screens are lit dimly; the arena materials need a lift to read as well as the game's hats
const BRIGHTNESS: float = 2.2
# the hats are placed like the game's hard hat, whose model is ~0.55 m wide, Y up, front +Z (Blender -Y):
# the Blender hats were made for a 0.24 m head, so they are scaled up to match
var model_basis: Basis = Basis.from_scale(Vector3.ONE * 1.45)
var model_offset: Vector3 = Vector3(0.0, 0.04, 0.0)

var templates: Dictionary = {}

func _ready() -> void :
	get_tree().node_added.connect(_on_node_added)

## Parsing a glb is slow and every character needs the hats: parse once, then copy.
func make_hat(hat_name: String) -> Node3D:
	if not templates.has(hat_name):
		var model: Node3D = DA.load_model(HATS[hat_name][0])
		model.transform = Transform3D(model_basis, model_offset + Vector3(0.0, HATS[hat_name][1], 0.0))
		brighten(model)
		templates[hat_name] = model
	var holder := Node3D.new()
	holder.name = hat_name
	holder.add_child(templates[hat_name].duplicate())
	return holder

func brighten(model: Node):
	for mesh in model.find_children("*", "MeshInstance3D", true, false):
		for i in mesh.get_surface_override_material_count():
			var material = mesh.get_surface_override_material(i)
			if material == null:
				material = mesh.mesh.surface_get_material(i)
			if material is StandardMaterial3D and not material.emission_enabled:
				material = material.duplicate()
				material.albedo_color = material.albedo_color * BRIGHTNESS
				mesh.set_surface_override_material(i, material)

## Adds the mod hats next to the game's own, placed like its hard hat.
func ensure_hats(assigner: Node):
	var parent: Node3D = assigner.bone_attachment_hat
	if parent == null or parent.has_node(NodePath(HATS.keys()[0])):
		return
	var reference: Node3D = parent.get_node_or_null("hard_hat")
	for hat_name in HATS.keys():
		var holder: Node3D = make_hat(hat_name)
		if reference:
			holder.transform = reference.transform
		holder.visible = false
		parent.add_child(holder)



func _on_node_added(node: Node):
	if node is CustomizationAssigner:
		ensure_hats(node)
	elif node is CustomizationSelection:
		add_slots.call_deferred(node)

## Three more slots on the customization screen, cloned from the last one.
func add_slots(selection: CustomizationSelection):

	if not selection.is_node_ready():
		await selection.ready

	var last_rect: Control = selection.selection_rect_array[-1].get_parent().get_parent()
	var spawn_offset_x: float = 3.0 * (selection.customizations.size() + 1)
	var column: int = 0

	for hat_name in HATS.keys():

		var slot: Control = last_rect.duplicate(Node.DUPLICATE_GROUPS | Node.DUPLICATE_SCRIPTS)
		slot.name = "rect_" + hat_name
		# a narrow column right of the 3 x 3 grid (the row below holds the suit colours)
		slot.position = Vector2(last_rect.position.x + 104.0, 28.0 + column * 100.0)
		slot.scale = Vector2.ONE * 0.72
		for child in slot.find_children("*", "", true, false):
			if "assigned_cosmetic" in child:
				child.assigned_cosmetic = hat_name
		last_rect.add_sibling(slot)

		# the preview: one more cosmetic stand rendered to its own viewport, like the game's
		var instance: Customization_SelectionInstance = selection.cosmetic_selection_instance.instantiate()
		selection.cosmetic_selection_parent.add_child(instance)
		spawn_offset_x += 3.0
		var cam_origin: Vector3 = instance.camera_parent.transform.origin
		instance.camera_parent.transform.origin = Vector3(cam_origin.x - spawn_offset_x, cam_origin.y, cam_origin.z - 10.0)
		var preview: Node3D = make_hat(hat_name)
		preview.scale = Vector3.ONE * 1.2
		instance.cosmetic_holder_parent.add_child(preview)
		instance.setup_cosmetic(hat_name)

		for rect in slot.find_children("*", "TextureRect", true, false):
			if rect.name.begins_with("viewport feed"):
				rect.texture = instance.assigned_viewport.get_texture()

		column += 1

	# the character on screen may already wear one of these
	if Globals.active_cosmetic_hat.begins_with("mp_"):
		selection.customization_assigner.assign_hat(Globals.active_cosmetic_hat)
