extends RefCounted

## L'ATELIER: the pieces an arena is built from, the map format, and the local map library.
##
## A map is a Dictionary:
##   {"id": String, "name": String, "author": String, "origin": "mine"|"downloaded", "published": bool,
##    "updated": int, "cells": {"x,z": {"floor": bool, "item": String, "rot": int}}}
## Cells are CELL metres wide on a GRID x GRID board centred on the origin; rot is a quarter-turn count,
## rot 0 facing -Z (up the screen). Maps live in user://mods/machine_party_unlocked/atelier/maps/<id>.json.

const DA = preload("user://mods/machine_party_unlocked/da_kit.gd")

const GRID: int = 12
const CELL: float = 2.0
const DIR: String = "user://mods/machine_party_unlocked/atelier/"
const MAPS: String = DIR + "maps/"

# item -> [editor label, category, draws its own surface (replaces the plain floor)]
const ITEMS: Dictionary = {
	"floor": ["SOL", "SOLS", true],
	"high": ["PLATEFORME HAUTE", "SOLS", true],
	"ramp": ["RAMPE", "SOLS", true],
	"ice": ["GLACE", "SOLS", true],
	"belt": ["TAPIS ROULANT", "SOLS", true],
	"mover": ["PLATEFORME MOBILE", "SOLS", true],
	"crumble": ["DALLE FRAGILE", "SOLS", true],
	"trapdoor": ["TRAPPE", "SOLS", true],
	"trampoline": ["TRAMPOLINE", "SOLS", true],
	"press": ["PRESSE", "PIEGES", false],
	"arm": ["BRAS", "PIEGES", false],
	"piston": ["VERIN", "PIEGES", false],
	"fan": ["VENTILO", "PIEGES", false],
	"saw": ["SCIE", "PIEGES", false],
	"pendulum": ["PENDULE", "PIEGES", false],
	"electric": ["DALLE ELECTRIQUE", "PIEGES", true],
	"block": ["MURET", "DECOR", false],
	"fence": ["BARRIERE", "DECOR", false],
	"crate": ["CAISSE", "DECOR", false],
	"barrel": ["BARIL", "DECOR", false],
	"lamp": ["LAMPE", "DECOR", false],
	"spawn": ["DEPART", "DEPART", false],
}
const CATEGORIES: Array[String] = ["SOLS", "PIEGES", "DECOR", "DEPART"]

static func key(cell: Vector2i) -> String:
	return "%d,%d" % [cell.x, cell.y]

static func cell_of(cell_key: String) -> Vector2i:
	return Vector2i(int(cell_key.get_slice(",", 0)), int(cell_key.get_slice(",", 1)))

static func center(cell: Vector2i) -> Vector3:
	var offset: float = (GRID - 1) * CELL * 0.5
	return Vector3(cell.x * CELL - offset, 0.0, cell.y * CELL - offset)

static func cell_at(position: Vector3) -> Vector2i:
	var offset: float = (GRID - 1) * CELL * 0.5
	return Vector2i(roundi((position.x + offset) / CELL), roundi((position.z + offset) / CELL))

static func inside(cell: Vector2i) -> bool:
	return cell.x >= 0 and cell.x < GRID and cell.y >= 0 and cell.y < GRID

static func facing(rot) -> Vector3:
	return [Vector3(0, 0, -1), Vector3(1, 0, 0), Vector3(0, 0, 1), Vector3(-1, 0, 0)][posmod(int(rot), 4)]

## Height of the walkable surface of a cell (for spawns and the camera).
static func surface(info: Dictionary) -> float:
	match info.get("item", ""):
		"high": return 1.1
		"trampoline": return 0.4
	return 0.0



# ---------------- the library ----------------

static func new_id() -> String:
	var bytes := PackedByteArray()
	for i in 6:
		bytes.append(randi() % 256)
	return bytes.hex_encode()

static func my_name() -> String:
	if Engine.has_singleton("Steam") or ClassDB.class_exists("Steam"):
		var steam_name = Steam.getPersonaName()
		if steam_name is String and steam_name != "":
			return steam_name
	return "Moi"

static func save(map: Dictionary):
	DirAccess.make_dir_recursive_absolute(MAPS)
	if not map.has("id") or map.id == "":
		map.id = new_id()
	map.updated = int(Time.get_unix_time_from_system())
	var file := FileAccess.open(MAPS + map.id + ".json", FileAccess.WRITE)
	file.store_string(JSON.stringify(map))

static func load_map(id: String) -> Dictionary:
	var text: String = FileAccess.get_file_as_string(MAPS + id + ".json")
	var data = JSON.parse_string(text) if text != "" else null
	return data if data is Dictionary and data.has("cells") else {}

static func delete(id: String):
	DirAccess.remove_absolute(MAPS + id + ".json")

static func library() -> Array:
	migrate()
	var maps: Array = []
	for file_name in DirAccess.get_files_at(MAPS):
		if file_name.ends_with(".json"):
			var map: Dictionary = load_map(file_name.trim_suffix(".json"))
			if not map.is_empty():
				maps.append(map)
	maps.sort_custom(func(a, b): return a.get("updated", 0) > b.get("updated", 0))
	return maps

## Maps saved by the first Atelier version (atelier/<name>.json) move into the library.
static func migrate():
	DirAccess.make_dir_recursive_absolute(MAPS)
	for file_name in DirAccess.get_files_at(DIR):
		if not file_name.ends_with(".json"):
			continue
		# only old maps move; other files here (store_config.json) stay
		var data = JSON.parse_string(FileAccess.get_file_as_string(DIR + file_name))
		if not (data is Dictionary and data.has("cells")):
			continue
		data.id = new_id()
		data.author = my_name()
		data.origin = "mine"
		data.published = false
		save(data)
		if FileAccess.get_file_as_string(DIR + "active.txt").strip_edges() == file_name.trim_suffix(".json"):
			set_active(data.id)
		DirAccess.remove_absolute(DIR + file_name)

static func set_active(id: String):
	DirAccess.make_dir_recursive_absolute(DIR)
	FileAccess.open(DIR + "active.txt", FileAccess.WRITE).store_string(id)

static func active_id() -> String:
	return FileAccess.get_file_as_string(DIR + "active.txt").strip_edges()

## The arena the host plays: the active one, or the sample.
static func active() -> Dictionary:
	migrate()
	var map: Dictionary = load_map(active_id()) if active_id() != "" else {}
	return map if not map.is_empty() else sample()

static func piece_count(map: Dictionary) -> int:
	var count: int = 0
	for info in map.get("cells", {}).values():
		if info.get("item", "") != "" and info.item != "floor":
			count += 1
	return count

## A default arena, so the minigame always has something to play.
static func sample() -> Dictionary:
	var cells: Dictionary = {}
	for x in range(2, 10):
		for z in range(2, 10):
			cells[key(Vector2i(x, z))] = {"floor": true, "item": "", "rot": 0}
	for c in [Vector2i(3, 3), Vector2i(8, 3), Vector2i(3, 8), Vector2i(8, 8), Vector2i(5, 8)]:
		cells[key(c)].item = "spawn"
	cells[key(Vector2i(5, 5))].item = "arm"
	for c in [Vector2i(2, 6), Vector2i(9, 4)]:
		cells[key(c)].item = "press"
	for c in [Vector2i(4, 6), Vector2i(7, 4)]:
		cells[key(c)].item = "piston"
	for c in [Vector2i(6, 7), Vector2i(7, 7)]:
		cells[key(c)].item = "ice"
	cells[key(Vector2i(2, 2))].item = "fan"
	cells[key(Vector2i(2, 2))].rot = 2
	cells[key(Vector2i(6, 2))].item = "high"
	cells[key(Vector2i(6, 3))].item = "ramp"
	cells[key(Vector2i(9, 9))].item = "trampoline"
	return {"id": "", "name": "exemple", "author": "Machine Party+", "origin": "mine", "published": false, "cells": cells}



# ---------------- visuals ----------------

static func model(file_name: String) -> Node3D:
	return DA.load_model(file_name)

## The visual of one cell, the same in the editor and in the game. Moving parts are named so the minigame can
## animate them: Item/Head (press), Item/Arm, Item/Plate (piston), Item/Blades (fan), Item/Blade (saw),
## Item/Ball (pendulum), Item/Doors/* (trapdoor), Item (mover, crumble).
static func build_visual(info: Dictionary) -> Node3D:
	var root := Node3D.new()
	var item: String = info.get("item", "")
	var replaces_floor: bool = ITEMS.get(item, ["", "", false])[2]
	if not replaces_floor or item == "floor":
		root.add_child(floor_tile(Color(0.95, 0.93, 0.9)))
	var item_root := Node3D.new()
	item_root.name = "Item"
	item_root.rotation.y = - posmod(int(info.get("rot", 0)), 4) * PI * 0.5
	root.add_child(item_root)
	match item:
		"high":
			item_root.add_child(model("at_high.glb"))
		"ramp":
			item_root.add_child(model("at_ramp.glb"))
		"ice":
			var ice := floor_tile(Color(0.7, 0.9, 1.1))
			var m: StandardMaterial3D = ice.material_override
			m.emission_enabled = true
			m.emission = Color(0.4, 0.7, 1.0)
			m.emission_energy_multiplier = 0.35
			m.roughness = 0.05
			m.metallic = 0.6
			item_root.add_child(ice)
		"belt":
			item_root.add_child(floor_tile(Color(0.5, 0.5, 0.5)))
			item_root.add_child(model("at_belt.glb"))
		"mover":
			item_root.add_child(model("at_mover.glb"))
		"crumble":
			item_root.add_child(model("at_crumble.glb"))
		"trapdoor":
			item_root.add_child(model("at_trapdoor_frame.glb"))
			var doors := Node3D.new()
			doors.name = "Doors"
			item_root.add_child(doors)
			for side in [-1.0, 1.0]:
				var hinge := Node3D.new()
				hinge.name = "Left" if side < 0 else "Right"
				hinge.position = Vector3(side * 0.9, 0.0, 0.0)
				hinge.rotation.y = 0.0 if side < 0 else PI
				hinge.add_child(model("at_trapdoor_door.glb"))
				doors.add_child(hinge)
		"trampoline":
			item_root.add_child(floor_tile(Color(0.6, 0.6, 0.6)))
			var pad: Node3D = model("at_trampoline.glb")
			pad.name = "Pad"
			item_root.add_child(pad)
		"electric":
			item_root.add_child(model("at_electric.glb"))
			var glow := OmniLight3D.new()
			glow.name = "Glow"
			glow.light_color = Color(0.4, 0.7, 1.0)
			glow.light_energy = 0.0
			glow.omni_range = 3.0
			glow.position.y = 0.6
			item_root.add_child(glow)
		"block":
			item_root.add_child(box(Vector3(CELL - 0.1, 1.1, CELL - 0.1), Vector3(0, 0.55, 0), DA.kind_material("mp_metal")))
			item_root.add_child(box(Vector3(CELL, 0.15, CELL), Vector3(0, 1.12, 0), DA.kind_material("mp_hazard")))
		"press":
			var head := Node3D.new()
			head.name = "Head"
			head.position.y = 6.0
			head.add_child(box(Vector3(CELL - 0.2, 1.0, CELL - 0.2), Vector3(0, 0.0, 0), DA.kind_material("mp_dark")))
			head.add_child(box(Vector3(CELL - 0.1, 0.3, CELL - 0.1), Vector3(0, -0.45, 0), DA.kind_material("mp_hazard")))
			var rod := MeshInstance3D.new()
			var rod_mesh := CylinderMesh.new()
			rod_mesh.top_radius = 0.18
			rod_mesh.bottom_radius = 0.18
			rod_mesh.height = 2.5
			rod.mesh = rod_mesh
			rod.material_override = DA.kind_material("mp_rod")
			rod.position.y = 1.7
			head.add_child(rod)
			item_root.add_child(head)
			item_root.add_child(box(Vector3(CELL - 0.2, 0.03, CELL - 0.2), Vector3(0, 0.02, 0), DA.kind_material("mp_hazard")))
		"arm":
			item_root.add_child(model("sweeper_hub.glb"))
			var arm := Node3D.new()
			arm.name = "Arm"
			var beam: Node3D = model("sweeper_arm.glb")
			beam.scale = Vector3(0.65, 1.0, 1.0)
			arm.add_child(beam)
			item_root.add_child(arm)
		"piston":
			var plate := box(Vector3(CELL - 0.15, 0.2, CELL - 0.15), Vector3(0, 0.05, 0), DA.kind_material("mp_light"))
			plate.name = "Plate"
			item_root.add_child(plate)
		"fan":
			item_root.add_child(box(Vector3(1.8, 1.6, 0.5), Vector3(0, 0.8, 0.6), DA.kind_material("mp_dark")))
			var blades := Node3D.new()
			blades.name = "Blades"
			blades.position = Vector3(0, 0.8, 0.3)
			for k in 3:
				var blade := box(Vector3(0.25, 1.4, 0.05), Vector3.ZERO, DA.kind_material("mp_metal"))
				blade.rotation.z = k * PI / 3.0
				blades.add_child(blade)
			item_root.add_child(blades)
			item_root.add_child(box(Vector3(0.3, 0.03, 1.2), Vector3(0, 0.02, -0.6), DA.kind_material("mp_hazard")))
		"saw":
			# the blade runs from this cell two cells forward and back
			var track: Node3D = model("at_saw_track.glb")
			track.scale = Vector3(1.0, 1.0, 3.0)
			track.position = Vector3(0, 0, - CELL)
			item_root.add_child(track)
			var blade_root := Node3D.new()
			blade_root.name = "Blade"
			blade_root.position.y = 0.45
			var blade: Node3D = model("at_saw_blade.glb")
			blade.rotation.y = PI * 0.5
			blade_root.add_child(blade)
			item_root.add_child(blade_root)
		"pendulum":
			item_root.add_child(model("at_pendulum_frame.glb"))
			var swing := Node3D.new()
			swing.name = "Ball"
			swing.position.y = 4.4
			var chain := box(Vector3(0.08, 3.2, 0.08), Vector3(0, -1.6, 0), DA.kind_material("mp_rubber"))
			swing.add_child(chain)
			var ball := MeshInstance3D.new()
			var sphere := SphereMesh.new()
			sphere.radius = 0.6
			sphere.height = 1.2
			ball.mesh = sphere
			ball.material_override = DA.kind_material("mp_dark")
			ball.position.y = -3.4
			swing.add_child(ball)
			item_root.add_child(swing)
		"fence":
			item_root.add_child(model("at_fence.glb"))
		"crate":
			item_root.add_child(model("at_crate.glb"))
		"barrel":
			item_root.add_child(model("at_barrel.glb"))
		"lamp":
			item_root.add_child(model("at_lamp.glb"))
			var light := OmniLight3D.new()
			light.position = Vector3(0.6, 2.3, 0)
			light.light_color = Color(1.0, 0.75, 0.45)
			light.light_energy = 3.0
			light.omni_range = 6.0
			item_root.add_child(light)
		"spawn":
			var ring := MeshInstance3D.new()
			var torus := TorusMesh.new()
			torus.inner_radius = 0.55
			torus.outer_radius = 0.75
			ring.mesh = torus
			var mat := StandardMaterial3D.new()
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			mat.albedo_color = Color(0.3, 1.0, 0.4)
			ring.material_override = mat
			ring.scale = Vector3(1, 0.1, 1)
			ring.position.y = 0.03
			item_root.add_child(ring)
	return root

static func floor_tile(tint: Color) -> MeshInstance3D:
	var tile := MeshInstance3D.new()
	var tile_mesh := BoxMesh.new()
	tile_mesh.size = Vector3(CELL - 0.06, 0.5, CELL - 0.06)
	tile.mesh = tile_mesh
	tile.material_override = DA.base_material(DA.TEX_FLOOR_HAZARD, tint, 0.5)
	tile.position.y = -0.25
	return tile

static func box(size: Vector3, position: Vector3, material: Material) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var box_mesh := BoxMesh.new()
	box_mesh.size = size
	mesh.mesh = box_mesh
	mesh.material_override = material
	mesh.position = position
	return mesh
