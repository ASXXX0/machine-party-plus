extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## L'ATELIER, the minigame: the host's own arena, built in the editor, sent to everyone (and saved in their
## library) and played as a last one standing. What each piece does:
##   floors   - PLATEFORME HAUTE (1.1 m), RAMPE, GLACE (slippery), TAPIS ROULANT (carries you), PLATEFORME
##              MOBILE (goes 2 cells and back), DALLE FRAGILE (falls after you stand on it, comes back),
##              TRAPPE (opens now and then), TRAMPOLINE (throws you up and forward);
##   traps    - PRESSE (crushes its cell), BRAS (turns, flings), VERIN (launches), VENTILO (blows down its lane),
##              SCIE (runs 2 cells forward and back, kills), PENDULE (swings across, knocks off),
##              DALLE ELECTRIQUE (glows, then zaps whoever stands on it);
##   decor    - MURET, BARRIERE, CAISSE, BARIL (solid), LAMPE (light).
## The host times presses, pistons, fans, trapdoors and electric tiles; arms, saws, pendulums and movers run on
## every peer's own clock (the play time is shared). Each peer applies the pushes to the runners it simulates.

const PIECES = preload("user://mods/machine_party_unlocked/atelier/pieces.gd")
const FAN_REACH: int = 5
const ARM_LENGTH: float = 6.0

var map: Dictionary = {}
var built: bool = false
var cells: Dictionary = {}
var bodies: Dictionary = {}
var timers: Dictionary = {}
var arms: Array = []
var hit_timers: Dictionary = {}
var blowing: Dictionary = {}
var crumbling: Dictionary = {}
var phases: Dictionary = {}

func fall_height() -> float:
	return -7.0

func build_arena():
	max_duration = 100.0
	add_sound("ambience", "res://audio/unique/chisel gauntlet/machine ambience.ogg", -8.0, true)
	add_sound("warn", "res://audio/sfx/burn_recycle/beep.ogg", -8.0)
	add_sound("slam", "res://audio/sfx/manufacture_gun_drop_gear.ogg", -2.0)
	add_sound("launch", "res://audio/unique/disco dodge/dd piston impact7.ogg", -2.0)
	add_sound("hit", "res://audio/unique/disco dodge/dd fall scream impact.ogg", -4.0)
	add_sound("wind", "res://audio/sfx/escalator_pit_wind.ogg", -4.0)
	add_sound("zap", "res://audio/sfx/bad_explosion.ogg", -6.0)
	add_sound("boing", "res://audio/sfx/disco_twang.ogg", -2.0)
	add_sound("crack", "res://audio/unique/disco dodge/dd tiles fall.ogg", -2.0)
	DA.add_backdrop(self, Vector3(40.0, -10.0, -50.0), 20.0)
	add_key_lights(Vector3(0.0, 14.0, 3.0), 120.0, 32.0)
	set_camera(Vector3(0.0, 20.0, 15.0), Vector3(0.0, -1.0, 1.0))
	if Engine.has_meta("mpplus_preview"):
		build_map(PIECES.active())

## The host sends its arena before anyone spawns; everyone keeps a copy in their library.
func initialize(_round_number: int, _total_rounds: int, _scores: Dictionary = {}):
	map_rpc.rpc(JSON.stringify(PIECES.active()))
	super.initialize(_round_number, _total_rounds, _scores)

@rpc("authority", "call_local", "reliable")
func map_rpc(text: String):
	var data = JSON.parse_string(text)
	if not (data is Dictionary and data.has("cells")):
		return
	build_map(data)
	var store = get_node_or_null("/root/MachinePartyMod/Store")
	if store and not multiplayer.is_server():
		store.receive_map(data, true)

func build_map(data: Dictionary):
	if built:
		return
	built = true
	map = data
	var low := Vector2(INF, INF)
	var high := Vector2(-INF, -INF)
	for cell_key in map.cells.keys():
		var cell: Vector2i = PIECES.cell_of(cell_key)
		var info: Dictionary = map.cells[cell_key]
		var item: String = info.get("item", "")
		var node: Node3D = PIECES.build_visual(info)
		node.position = PIECES.center(cell)
		arena.add_child(node)
		cells[cell_key] = node
		build_body(cell_key, cell, info)
		phases[cell_key] = (cell.x * 0.37 + cell.y * 0.71)
		if item == "arm":
			arms.append({"cell": cell, "dir": 1.0 if posmod(int(info.get("rot", 0)), 2) == 0 else -1.0, "node": node.get_node("Item/Arm")})
		var p: Vector3 = PIECES.center(cell)
		low = Vector2(min(low.x, p.x), min(low.y, p.z))
		high = Vector2(max(high.x, p.x), max(high.y, p.z))
	if low.x != INF:
		var mid := Vector3((low.x + high.x) * 0.5, 0.0, (low.y + high.y) * 0.5)
		var extent: float = max(high.x - low.x, high.y - low.y) + PIECES.CELL * 2.0
		set_camera(mid + Vector3(0.0, extent * 0.85 + 4.0, extent * 0.62 + 3.0), mid + Vector3(0.0, -1.0, 0.8))
		camera_origin = camera.position

## The collision of a cell: what you stand on and what blocks you.
func build_body(cell_key: String, cell: Vector2i, info: Dictionary):
	var item: String = info.get("item", "")
	var rot: float = - posmod(int(info.get("rot", 0)), 4) * PI * 0.5
	var body: CollisionObject3D = AnimatableBody3D.new() if item == "mover" else StaticBody3D.new()
	if body is AnimatableBody3D:
		body.sync_to_physics = true
	body.position = PIECES.center(cell)
	body.rotation.y = rot
	arena.add_child(body)
	bodies[cell_key] = body
	var shapes: Array = []
	match item:
		"high":
			shapes.append([Vector3(PIECES.CELL, 1.1, PIECES.CELL), Vector3(0, 0.55, 0)])
		"ramp":
			var wedge := ConvexPolygonShape3D.new()
			var h: float = PIECES.CELL * 0.5
			wedge.points = PackedVector3Array([Vector3(-h, 0, h), Vector3(h, 0, h), Vector3(h, 0, -h), Vector3(-h, 0, -h),
				Vector3(-h, 1.1, -h), Vector3(h, 1.1, -h), Vector3(-h, -0.5, h), Vector3(h, -0.5, h), Vector3(h, -0.5, -h), Vector3(-h, -0.5, -h)])
			var shape := CollisionShape3D.new()
			shape.shape = wedge
			body.add_child(shape)
		"trampoline":
			shapes.append([Vector3(PIECES.CELL, 0.9, PIECES.CELL), Vector3(0, -0.05, 0)])
		"mover":
			shapes.append([Vector3(PIECES.CELL - 0.1, 0.25, PIECES.CELL - 0.1), Vector3(0, -0.125, 0)])
		"block", "crate":
			shapes.append([Vector3(PIECES.CELL, 0.5, PIECES.CELL), Vector3(0, -0.25, 0)])
			shapes.append([Vector3(1.9 if item == "block" else 1.1, 1.1, 1.9 if item == "block" else 1.1), Vector3(0, 0.55, 0)])
		"fence":
			shapes.append([Vector3(PIECES.CELL, 0.5, PIECES.CELL), Vector3(0, -0.25, 0)])
			shapes.append([Vector3(2.0, 0.9, 0.15), Vector3(0, 0.45, 0)])
		"barrel":
			shapes.append([Vector3(PIECES.CELL, 0.5, PIECES.CELL), Vector3(0, -0.25, 0)])
			shapes.append([Vector3(0.75, 1.0, 0.75), Vector3(0, 0.5, 0)])
		_:
			shapes.append([Vector3(PIECES.CELL, 0.5, PIECES.CELL), Vector3(0, -0.25, 0)])
	for spec in shapes:
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = spec[0]
		shape.shape = box
		shape.position = spec[1]
		body.add_child(shape)

func set_floor_solid(cell_key: String, solid: bool):
	for child in bodies[cell_key].get_children():
		if child is CollisionShape3D:
			child.set_deferred("disabled", not solid)

func spawn_points() -> Array[Vector3]:
	var out: Array[Vector3] = []
	var data: Dictionary = map if built else PIECES.active()
	for cell_key in data.cells.keys():
		if data.cells[cell_key].get("item", "") == "spawn":
			out.append(PIECES.center(PIECES.cell_of(cell_key)) + Vector3(0.0, 0.2, 0.0))
	if out.is_empty():
		out.append(Vector3(0.0, 0.2, 0.0))
	return out

func on_play_start_local():
	fade_in_ambience()
	if map.get("name", "") != "":
		set_countdown_mesage_rpc("\"%s\"" % str(map.name).to_upper(), 1.2)

func on_server_play_start():
	for cell_key in map.cells.keys():
		match map.cells[cell_key].get("item", ""):
			"press": timers[cell_key] = randf_range(2.0, 5.0)
			"piston": timers[cell_key] = randf_range(2.5, 5.5)
			"fan": timers[cell_key] = randf_range(3.0, 6.0)
			"trapdoor": timers[cell_key] = randf_range(4.0, 8.0)
			"electric": timers[cell_key] = randf_range(3.0, 6.0)



# ---------------- host-timed pieces ----------------

func server_tick(delta: float):
	var pace: float = 1.0 + play_time * 0.01
	for cell_key in timers.keys():
		timers[cell_key] -= delta * pace
		if timers[cell_key] > 0.0:
			continue
		match map.cells[cell_key].item:
			"press":
				timers[cell_key] = randf_range(4.0, 6.5)
				press_cycle(cell_key)
			"piston":
				timers[cell_key] = randf_range(3.5, 6.0)
				piston_rpc.rpc(cell_key)
			"fan":
				timers[cell_key] = randf_range(6.0, 9.0)
				fan_rpc.rpc(cell_key)
			"trapdoor":
				timers[cell_key] = randf_range(6.0, 9.0)
				trapdoor_rpc.rpc(cell_key)
			"electric":
				timers[cell_key] = randf_range(4.5, 7.0)
				electric_cycle(cell_key)

	# crumbling tiles: someone stood on them
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		var cell_key: String = PIECES.key(PIECES.cell_at(player.global_position))
		if map.cells.has(cell_key) and map.cells[cell_key].get("item", "") == "crumble" and not crumbling.has(cell_key):
			crumbling[cell_key] = true
			crumble_rpc.rpc(cell_key)

func players_on(cell_key: String, max_height: float = 2.0) -> Array:
	var cell: Vector2i = PIECES.cell_of(cell_key)
	var out: Array = []
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if is_instance_valid(player) and player.active and PIECES.cell_at(player.global_position) == cell and player.global_position.y < max_height:
			out.append(network_id)
	return out

func press_cycle(cell_key: String):
	press_warn_rpc.rpc(cell_key)
	await get_tree().create_timer(1.2, false).timeout
	if game_end or not is_inside_tree():
		return
	press_slam_rpc.rpc(cell_key)
	await get_tree().create_timer(0.1, false).timeout
	for network_id in players_on(cell_key):
		crush(network_id)

func electric_cycle(cell_key: String):
	electric_rpc.rpc(cell_key, true)
	await get_tree().create_timer(1.3, false).timeout
	if game_end or not is_inside_tree():
		return
	electric_rpc.rpc(cell_key, false)
	sfx_rpc.rpc("zap")
	for network_id in players_on(cell_key, 0.6):
		crush(network_id)

@rpc("authority", "call_local", "reliable")
func press_warn_rpc(cell_key: String):
	play_sound("warn")
	warn_ring(PIECES.center(PIECES.cell_of(cell_key)), PIECES.CELL * 0.5, 1.2)
	var head: Node3D = cells[cell_key].get_node("Item/Head")
	head.create_tween().tween_property(head, "position:y", 4.5, 1.0)

@rpc("authority", "call_local", "reliable")
func press_slam_rpc(cell_key: String):
	play_sound("slam")
	shake = min(shake + 0.4, 1.2)
	var head: Node3D = cells[cell_key].get_node("Item/Head")
	var t := head.create_tween()
	t.tween_property(head, "position:y", 0.65, 0.1).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
	t.tween_interval(0.5)
	t.tween_property(head, "position:y", 6.0, 0.8)

@rpc("authority", "call_local", "reliable")
func electric_rpc(cell_key: String, charging: bool):
	var glow: OmniLight3D = cells[cell_key].get_node("Item/Glow")
	if charging:
		play_sound("warn")
		var t := glow.create_tween().set_loops(6)
		t.tween_property(glow, "light_energy", 6.0, 0.1)
		t.tween_property(glow, "light_energy", 1.0, 0.1)
	else:
		var flash := glow.create_tween()
		flash.tween_property(glow, "light_energy", 30.0, 0.05)
		flash.tween_property(glow, "light_energy", 0.0, 0.4)

@rpc("authority", "call_local", "reliable")
func piston_rpc(cell_key: String):
	var plate: MeshInstance3D = cells[cell_key].get_node("Item/Plate")
	var glow := plate.create_tween().set_loops(5)
	glow.tween_property(plate, "scale", Vector3(1.0, 2.5, 1.0), 0.1)
	glow.tween_property(plate, "scale", Vector3.ONE, 0.1)
	await get_tree().create_timer(1.0, false).timeout
	if not is_inside_tree():
		return
	play_sound("launch")
	var root: Node3D = cells[cell_key]
	var t := root.create_tween()
	t.tween_property(root, "position:y", 1.4, 0.1).set_trans(Tween.TRANS_EXPO)
	t.tween_property(root, "position:y", 0.0, 0.5)
	if not running:
		return
	var cell: Vector2i = PIECES.cell_of(cell_key)
	for player in local_runners():
		if PIECES.cell_at(player.global_position) == cell and player.is_on_floor():
			var angle: float = randf() * TAU
			push_runner(player, Vector3(cos(angle), 0.0, sin(angle)), 9.0)
			player.velocity.y = 12.0

@rpc("authority", "call_local", "reliable")
func fan_rpc(cell_key: String):
	play_sound("warn")
	await get_tree().create_timer(1.2, false).timeout
	if not is_inside_tree():
		return
	audio["wind"].play()
	blowing[cell_key] = true
	await get_tree().create_timer(3.0, false).timeout
	blowing.erase(cell_key)
	if blowing.is_empty() and audio.has("wind"):
		audio["wind"].stop()

@rpc("authority", "call_local", "reliable")
func trapdoor_rpc(cell_key: String):
	play_sound("warn")
	warn_ring(PIECES.center(PIECES.cell_of(cell_key)), PIECES.CELL * 0.5, 1.0, Color(1.0, 0.6, 0.1))
	await get_tree().create_timer(1.0, false).timeout
	if not is_inside_tree():
		return
	set_floor_solid(cell_key, false)
	var doors: Node3D = cells[cell_key].get_node("Item/Doors")
	for hinge in doors.get_children():
		hinge.create_tween().tween_property(hinge, "rotation:z", -1.4, 0.25).set_ease(Tween.EASE_IN)
	await get_tree().create_timer(2.2, false).timeout
	if not is_inside_tree():
		return
	for hinge in doors.get_children():
		hinge.create_tween().tween_property(hinge, "rotation:z", 0.0, 0.5)
	await get_tree().create_timer(0.4, false).timeout
	set_floor_solid(cell_key, true)

@rpc("authority", "call_local", "reliable")
func crumble_rpc(cell_key: String):
	var item: Node3D = cells[cell_key].get_node("Item")
	var shake_tween := item.create_tween().set_loops(6)
	shake_tween.tween_property(item, "position:x", 0.06, 0.05)
	shake_tween.tween_property(item, "position:x", -0.06, 0.05)
	await get_tree().create_timer(0.7, false).timeout
	if not is_inside_tree():
		return
	play_sound("crack")
	set_floor_solid(cell_key, false)
	var fall := item.create_tween()
	fall.tween_property(item, "position:y", -12.0, 1.0).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	await get_tree().create_timer(5.0, false).timeout
	if not is_inside_tree():
		return
	item.position = Vector3(0.0, -3.0, 0.0)
	item.create_tween().tween_property(item, "position:y", 0.0, 0.8).set_trans(Tween.TRANS_BACK)
	await get_tree().create_timer(0.8, false).timeout
	set_floor_solid(cell_key, true)
	crumbling.erase(cell_key)



# ---------------- clock-driven pieces and pushes ----------------

func _physics_process(_delta: float) -> void :
	if replaying or not built:
		return
	var t: float = play_time
	for cell_key in bodies.keys():
		var info: Dictionary = map.cells[cell_key]
		if info.get("item", "") == "mover":
			var travel: float = (1.0 - cos(t * 0.9 + phases[cell_key])) * 0.5 * PIECES.CELL * 2.0
			var position: Vector3 = PIECES.center(PIECES.cell_of(cell_key)) + PIECES.facing(info.rot) * travel
			bodies[cell_key].position = position
			cells[cell_key].position = position

func visual_tick(delta: float):
	if not built:
		return
	var t: float = play_time
	var speed: float = 1.1 + min(t * 0.015, 1.4)
	for arm in arms:
		arm.node.rotation.y += arm.dir * speed * delta
	for cell_key in map.cells.keys():
		var item: String = map.cells[cell_key].get("item", "")
		match item:
			"fan":
				cells[cell_key].get_node("Item/Blades").rotation.z += delta * (18.0 if blowing.has(cell_key) else 1.5)
			"saw":
				var blade: Node3D = cells[cell_key].get_node("Item/Blade")
				blade.position.z = - (1.0 - cos(t * 1.6 + phases[cell_key])) * 0.5 * PIECES.CELL * 2.0
				blade.rotation.x -= delta * 20.0
			"pendulum":
				cells[cell_key].get_node("Item/Ball").rotation.z = sin(t * 1.9 + phases[cell_key]) * 1.1

	if not running:
		return

	for player in local_runners():
		apply_cell_effects(player, delta, speed)

func apply_cell_effects(player, delta: float, arm_speed: float):
	var network_id: int = player.player_presence.network_id
	var pos: Vector3 = player.global_position
	var cell_key: String = PIECES.key(PIECES.cell_at(pos))
	var info: Dictionary = map.cells.get(cell_key, {})
	var item: String = info.get("item", "")

	# ice: slippery while on it (a breakdown may already make everyone slip)
	if not player.has_meta("base_slippery"):
		player.set_meta("base_slippery", player.mpplus_slippery)
	player.mpplus_slippery = item == "ice" or player.get_meta("base_slippery")

	if player.is_on_floor():
		match item:
			"belt":
				player.move_and_collide(PIECES.facing(info.rot) * 2.6 * delta)
			"trampoline":
				sfx_rpc.rpc("boing")
				push_runner(player, PIECES.facing(info.rot), 5.0)
				player.velocity.y = 13.0
				var pad: Node3D = cells[cell_key].get_node("Item/Pad")
				var squash := pad.create_tween()
				squash.tween_property(pad, "scale", Vector3(1.0, 0.5, 1.0), 0.06)
				squash.tween_property(pad, "scale", Vector3.ONE, 0.2).set_trans(Tween.TRANS_BACK)

	# fans blow down their lane
	for fan_key in blowing.keys():
		var fan_info: Dictionary = map.cells[fan_key]
		var direction: Vector3 = PIECES.facing(fan_info.rot)
		var offset: Vector3 = pos - PIECES.center(PIECES.cell_of(fan_key))
		var along: float = offset.dot(direction)
		var across: float = abs(offset.dot(Vector3(direction.z, 0.0, - direction.x)))
		if along > 0.0 and along < FAN_REACH * PIECES.CELL and across < PIECES.CELL * 0.6 and player.is_on_floor():
			player.move_and_collide(direction * 6.5 * delta)

	hit_timers[network_id] = max(hit_timers.get(network_id, 0.0) - delta, 0.0)
	if hit_timers[network_id] > 0.0:
		return

	# saws kill, pendulums and arms knock you away
	for other_key in map.cells.keys():
		var other: String = map.cells[other_key].get("item", "")
		if other == "saw":
			var blade: Node3D = cells[other_key].get_node("Item/Blade")
			var blade_pos: Vector3 = blade.global_position
			if Vector2(pos.x - blade_pos.x, pos.z - blade_pos.z).length() < 0.75 and pos.y < 1.0:
				hit_timers[network_id] = 2.0
				request_crush_rpc.rpc_id(1, network_id)
				return
		elif other == "pendulum":
			var ball: Node3D = cells[other_key].get_node("Item/Ball").get_child(1)
			var ball_pos: Vector3 = ball.global_position
			if (pos + Vector3(0.0, 0.9, 0.0)).distance_to(ball_pos) < 1.2:
				hit_timers[network_id] = 0.8
				sfx_rpc.rpc("hit")
				var swing: float = cos(play_time * 1.9 + phases[other_key])
				var across: Vector3 = PIECES.facing(posmod(int(map.cells[other_key].rot) + 1, 4))
				push_runner(player, across * sign(swing) * -1.0, 16.0)
				return

	if pos.y > 0.55:
		return
	for arm in arms:
		var pivot: Vector3 = PIECES.center(arm.cell)
		var flat := Vector3(pos.x - pivot.x, 0.0, pos.z - pivot.z)
		if flat.length() < 0.8 or flat.length() > ARM_LENGTH:
			continue
		var angle: float = arm.node.rotation.y + cells[PIECES.key(arm.cell)].get_node("Item").rotation.y
		var arm_dir := Vector3(cos(angle), 0.0, - sin(angle))
		if flat.dot(arm_dir) < 0.0 or abs(flat.cross(arm_dir).y) > 0.75:
			continue
		hit_timers[network_id] = 0.7
		sfx_rpc.rpc("hit")
		var tangent: Vector3 = Vector3(- sin(angle), 0.0, - cos(angle)) * arm.dir
		push_runner(player, (tangent + flat.normalized() * 0.6), 13.0 + arm_speed * 3.0)
		return
