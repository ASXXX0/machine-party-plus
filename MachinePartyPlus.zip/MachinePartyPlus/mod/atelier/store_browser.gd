extends Control

## The STORE, from the main menu: every published L'Atelier map as a card with its picture, name, author,
## likes and downloads. Pick a card for the details: download it, play it (download + make it the map the host
## plays), open it in the Atelier, or like it.

const PIECES = preload("user://mods/machine_party_unlocked/atelier/pieces.gd")
const ACCENT := Color(1.0, 0.6, 0.15)
const CARD_SIZE := Vector2(214, 196)

var store: Node
var rows: Array = []
var busy: bool = false
var grid: GridContainer
var sort_button: OptionButton
var search_edit: LineEdit
var status: Label
var detail: PanelContainer
var detail_image: TextureRect
var detail_title: Label
var detail_text: Label
var detail_row: Dictionary = {}

func _ready() -> void :
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	CursorManager.set_locked(false, false)
	CursorManager.set_active(true)
	CursorManager.set_cursor(true, false)
	store = get_node_or_null("/root/MachinePartyMod/Store")
	position = Vector2.ZERO
	size = Vector2(960, 540)

	var background := ColorRect.new()
	background.color = Color(0.035, 0.04, 0.04)
	background.position = Vector2(-10, -10)
	background.size = Vector2(980, 560)
	add_child(background)
	var stripe := ColorRect.new()
	stripe.color = ACCENT
	stripe.position = Vector2(0, 52)
	stripe.size = Vector2(960, 2)
	add_child(stripe)

	var title := label("STORE DE L'ATELIER", 24, ACCENT)
	title.position = Vector2(20, 12)
	add_child(title)

	var bar := HBoxContainer.new()
	bar.position = Vector2(400, 14)
	bar.add_theme_constant_override("separation", 8)
	add_child(bar)
	sort_button = OptionButton.new()
	for text in ["RECENTES", "POPULAIRES", "MIEUX NOTEES"]:
		sort_button.add_item(text)
	sort_button.add_theme_font_size_override("font_size", 12)
	sort_button.item_selected.connect(func(_i): refresh())
	bar.add_child(sort_button)
	search_edit = LineEdit.new()
	search_edit.placeholder_text = "chercher une carte"
	search_edit.custom_minimum_size = Vector2(170, 0)
	search_edit.text_submitted.connect(func(_t): refresh())
	bar.add_child(search_edit)
	bar.add_child(button("ATELIER", func(): get_tree().change_scene_to_file("user://mods/machine_party_unlocked/atelier/editor.tscn")))
	bar.add_child(button("RETOUR", leave))

	var scroll := ScrollContainer.new()
	scroll.position = Vector2(14, 64)
	scroll.size = Vector2(932, 450)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	grid = GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	scroll.add_child(grid)

	status = label("", 12, Color(0.9, 0.88, 0.8))
	status.position = Vector2(20, 518)
	add_child(status)

	build_detail()
	refresh()

func label(text: String, font_size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 4)
	return l

func button(text: String, action: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", 12)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(action)
	return b

func panel_style(border: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.09, 0.09, 0.1)
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(3)
	style.set_content_margin_all(6)
	return style

func refresh():
	if busy or not store:
		return
	busy = true
	for child in grid.get_children():
		child.queue_free()
	status.text = "Chargement du store..."
	var answer: Array = await store.list_maps(["recent", "popular", "liked"][sort_button.selected], search_edit.text)
	busy = false
	if not answer[0]:
		status.text = "Store indisponible : " + str(answer[1])
		return
	rows = answer[1] if answer[1] is Array else []
	for row in rows:
		grid.add_child(make_card(row))
	status.text = "%d cartes" % rows.size() if not rows.is_empty() else "Aucune carte pour l'instant : publie la premiere depuis l'Atelier !"

func make_card(row: Dictionary) -> Control:
	var card := Button.new()
	card.custom_minimum_size = CARD_SIZE
	card.focus_mode = Control.FOCUS_NONE
	card.add_theme_stylebox_override("normal", panel_style(Color(0.25, 0.25, 0.25)))
	card.add_theme_stylebox_override("hover", panel_style(ACCENT))
	card.add_theme_stylebox_override("pressed", panel_style(ACCENT))
	card.pressed.connect(show_detail.bind(row))

	var image := TextureRect.new()
	image.position = Vector2(6, 6)
	image.size = Vector2(CARD_SIZE.x - 12, 124)
	image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	image.texture = store.thumb_texture(row)
	image.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(image)
	if image.texture == null:
		var empty := label("PAS D'IMAGE", 11, Color(0.4, 0.4, 0.4))
		empty.position = Vector2(70, 58)
		card.add_child(empty)

	var name_label := label(str(row.name), 14, Color(0.95, 0.93, 0.88))
	name_label.position = Vector2(8, 132)
	name_label.size = Vector2(CARD_SIZE.x - 16, 18)
	name_label.clip_text = true
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(name_label)
	var author := label("par " + str(row.author), 11, Color(0.65, 0.65, 0.6))
	author.position = Vector2(8, 151)
	author.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(author)
	var stats := label("%d J'AIME    %d DL    %d PIECES" % [row.likes, row.downloads, row.pieces], 11, ACCENT)
	stats.position = Vector2(8, 170)
	stats.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(stats)
	return card

func build_detail():
	var shade := ColorRect.new()
	shade.name = "Shade"
	shade.color = Color(0, 0, 0, 0.7)
	shade.position = Vector2(-10, -10)
	shade.size = Vector2(980, 560)
	shade.visible = false
	add_child(shade)
	detail = PanelContainer.new()
	detail.add_theme_stylebox_override("panel", panel_style(ACCENT))
	detail.position = Vector2(150, 50)
	detail.custom_minimum_size = Vector2(660, 0)
	detail.visible = false
	add_child(detail)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	detail.add_child(column)
	detail_image = TextureRect.new()
	detail_image.custom_minimum_size = Vector2(648, 300)
	detail_image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	detail_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	column.add_child(detail_image)
	detail_title = label("", 20, ACCENT)
	column.add_child(detail_title)
	detail_text = label("", 13, Color(0.9, 0.88, 0.8))
	column.add_child(detail_text)
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	column.add_child(actions)
	actions.add_child(button("JOUER CETTE CARTE", play_selected))
	actions.add_child(button("TELECHARGER", download_selected))
	actions.add_child(button("OUVRIR DANS L'ATELIER", open_selected))
	actions.add_child(button("J'AIME", like_selected))
	actions.add_child(button("FERMER", hide_detail))

func show_detail(row: Dictionary):
	detail_row = row
	detail_image.texture = store.thumb_texture(row)
	detail_title.text = str(row.name)
	var owned: bool = not PIECES.load_map(str(row.id)).is_empty()
	detail_text.text = "par %s\n%d j'aime  -  %d telechargements  -  %d pieces%s" % [
		row.author, row.likes, row.downloads, row.pieces, "\nDeja dans ta bibliotheque" if owned else ""]
	get_node("Shade").visible = true
	detail.visible = true

func hide_detail():
	get_node("Shade").visible = false
	detail.visible = false

func ensure_downloaded() -> Dictionary:
	var local: Dictionary = PIECES.load_map(str(detail_row.id))
	if not local.is_empty() and int(local.get("version", 0)) >= int(detail_row.get("version", 0)):
		return local
	status.text = "Telechargement..."
	var map: Dictionary = await store.download(str(detail_row.id))
	if map.is_empty():
		status.text = "Echec du telechargement."
	return map

func download_selected():
	if busy or detail_row.is_empty():
		return
	busy = true
	var map: Dictionary = await ensure_downloaded()
	busy = false
	if not map.is_empty():
		status.text = "\"%s\" est dans ta bibliotheque." % map.name
		show_detail(detail_row)

func play_selected():
	if busy or detail_row.is_empty():
		return
	busy = true
	var map: Dictionary = await ensure_downloaded()
	busy = false
	if map.is_empty():
		return
	PIECES.set_active(map.id)
	store.set_workshop_title(map.name, map.get("author", ""))
	status.text = "\"%s\" sera jouee dans L'ATELIER quand tu es l'hote." % map.name
	hide_detail()

func open_selected():
	if busy or detail_row.is_empty():
		return
	busy = true
	var map: Dictionary = await ensure_downloaded()
	busy = false
	if map.is_empty():
		return
	PIECES.set_active(map.id)
	get_tree().change_scene_to_file("user://mods/machine_party_unlocked/atelier/editor.tscn")

func like_selected():
	if busy or detail_row.is_empty():
		return
	busy = true
	var answer: Array = await store.like(str(detail_row.id))
	busy = false
	if answer[0]:
		detail_row.likes = int(answer[1])
		show_detail(detail_row)
		status.text = "Merci pour le j'aime !"
	else:
		status.text = "Echec : " + str(answer[1])

func _unhandled_input(event: InputEvent) -> void :
	if event is InputEventKey and event.pressed and event.physical_keycode == KEY_ESCAPE:
		if detail.visible:
			hide_detail()
		else:
			leave()

func leave():
	get_tree().change_scene_to_file("res://scenes/main_menu/main_menu.tscn")
