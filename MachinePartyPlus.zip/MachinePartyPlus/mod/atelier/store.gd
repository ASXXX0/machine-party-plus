extends Node

## L'ATELIER store: the online catalogue of published maps (Supabase, store/schema.sql). Lives at
## /root/MachinePartyMod/Store. Only the project's publishable key is used: reads go through the maps_public
## view, every write through a checked database function. Each install keeps a random secret (secret.txt);
## the server stores its hash, so only the author's install can update or delete a map.
##
## A map the host plays in L'ATELIER is also sent in game and saved by everyone (receive_map).

const PIECES = preload("user://mods/machine_party_unlocked/atelier/pieces.gd")
const CONFIG_PATH = "user://mods/machine_party_unlocked/atelier/store_config.json"
const SECRET_PATH = "user://mods/machine_party_unlocked/atelier/secret.txt"
const ORDERS: Dictionary = {"recent": "updated_at.desc", "popular": "downloads.desc", "liked": "likes.desc"}

var url: String = ""
var key: String = ""
var toast_layer: CanvasLayer
var toast: Label
var title_translations: Array[Translation] = []
var title_timer: float = 2.0
var shown_title: String = ""
var thumb_cache: Dictionary = {}

signal library_changed()

func _ready() -> void :
	var config = JSON.parse_string(FileAccess.get_file_as_string(CONFIG_PATH))
	if config is Dictionary:
		url = str(config.get("url", ""))
		key = str(config.get("key", ""))
	var active: Dictionary = PIECES.active()
	set_workshop_title(active.get("name", ""), active.get("author", ""))

## The minigame's name in the intermission, playlist and round screen is a translation key: it shows the name of
## the map the host will play. The host repeats it to everyone while they are connected.
func _process(delta: float) -> void :
	if not NetworkManager.is_active() or not multiplayer.is_server():
		return
	title_timer -= delta
	if title_timer > 0.0:
		return
	title_timer = 5.0
	var active: Dictionary = PIECES.active()
	host_map_rpc.rpc(str(active.get("name", "")).left(40), str(active.get("author", "")).left(40))

@rpc("authority", "call_local", "reliable")
func host_map_rpc(map_name: String, author: String):
	set_workshop_title(map_name.left(40), author.left(40))

func set_workshop_title(map_name: String, author: String):
	var title: String = "L'ATELIER : " + map_name.to_upper() if map_name != "" else "L'ATELIER"
	var tagline: String = "UNE CARTE DE " + author.to_upper() if author != "" else "LES CARTES DES JOUEURS"
	if title == shown_title:
		return
	shown_title = title
	for old in title_translations:
		TranslationServer.remove_translation(old)
	title_translations.clear()
	var locales: Array = ["fr", "en", TranslationServer.get_locale()]
	for locale in locales:
		var translation := Translation.new()
		translation.locale = locale
		translation.add_message("MPPLUS_WORKSHOP", title)
		translation.add_message("MPPLUS_WORKSHOP_TAG", tagline)
		TranslationServer.add_translation(translation)
		title_translations.append(translation)
	if get_parent() and get_parent().has_method("mod_log"):
		get_parent().mod_log("workshop title: " + tr("MPPLUS_WORKSHOP") + " / " + tr("MPPLUS_WORKSHOP_TAG"))

func online() -> bool:
	return url != "" and key != ""

func secret() -> String:
	var value: String = FileAccess.get_file_as_string(SECRET_PATH).strip_edges()
	if value.length() < 24:
		var bytes := Crypto.new().generate_random_bytes(24)
		value = bytes.hex_encode()
		DirAccess.make_dir_recursive_absolute(PIECES.DIR)
		FileAccess.open(SECRET_PATH, FileAccess.WRITE).store_string(value)
	return value

## One HTTPS call; returns [ok, parsed body or error text].
func request(method: int, path: String, body = null) -> Array:
	if not online():
		return [false, "store non configure"]
	var http := HTTPRequest.new()
	http.timeout = 12.0
	add_child(http)
	var headers: PackedStringArray = ["apikey: " + key, "Content-Type: application/json"]
	var err: int = http.request(url + path, headers, method, JSON.stringify(body) if body != null else "")
	if err != OK:
		http.queue_free()
		return [false, "connexion impossible"]
	var result: Array = await http.request_completed
	http.queue_free()
	var text: String = result[3].get_string_from_utf8()
	var data = JSON.parse_string(text) if text != "" else null
	if result[0] != HTTPRequest.RESULT_SUCCESS:
		return [false, "pas de connexion au store"]
	if result[1] >= 300:
		var message: String = str(data.get("message", "erreur %d" % result[1])) if data is Dictionary else "erreur %d" % result[1]
		return [false, message]
	return [true, data]

func call_function(function_name: String, args: Dictionary) -> Array:
	return await request(HTTPClient.METHOD_POST, "/rest/v1/rpc/" + function_name, args)

## A map's picture from the store, as a texture (cached).
func thumb_texture(row: Dictionary) -> Texture2D:
	var data: String = str(row.get("thumb", ""))
	if data == "":
		return null
	var cache_key: String = str(row.get("id", "")) + str(row.get("version", ""))
	if thumb_cache.has(cache_key):
		return thumb_cache[cache_key]
	var image := Image.new()
	if image.load_jpg_from_buffer(Marshalls.base64_to_raw(data)) != OK:
		return null
	var texture := ImageTexture.create_from_image(image)
	thumb_cache[cache_key] = texture
	return texture

## The catalogue: up to 100 maps, in the given order ("recent", "popular", "liked"), optionally matching a name.
func list_maps(order: String, search: String = "") -> Array:
	var path: String = "/rest/v1/maps_public?select=*&limit=100&order=" + ORDERS.get(order, ORDERS.recent)
	if search.strip_edges() != "":
		path += "&name=ilike.*" + search.strip_edges().uri_encode() + "*"
	return await request(HTTPClient.METHOD_GET, path)

## Downloads a map into the library; returns the saved map, or {} on failure.
func download(id: String) -> Dictionary:
	var answer: Array = await call_function("download_map", {"p_id": id})
	if not answer[0] or not answer[1] is Dictionary:
		return {}
	return save_downloaded(answer[1])

func publish(map: Dictionary, thumb: String = "") -> Array:
	var answer: Array = await call_function("publish_map", {
		"p_id": map.id, "p_name": map.name, "p_author": map.get("author", PIECES.my_name()),
		"p_cells": map.cells, "p_secret": secret(), "p_thumb": thumb,
	})
	if answer[0]:
		map.published = true
		map.version = int(answer[1])
		PIECES.save(map)
	return answer

func unpublish(map: Dictionary) -> Array:
	var answer: Array = await call_function("delete_map", {"p_id": map.id, "p_secret": secret()})
	if answer[0]:
		map.published = false
		PIECES.save(map)
	return answer

func like(id: String) -> Array:
	return await call_function("like_map", {"p_id": id, "p_secret": secret()})



func save_downloaded(data: Dictionary) -> Dictionary:
	var id: String = str(data.get("id", ""))
	if id.length() != 12 or not id.is_valid_hex_number():
		return {}
	var existing: Dictionary = PIECES.load_map(id)
	if not existing.is_empty() and existing.get("origin", "") == "mine":
		return existing
	var map: Dictionary = {
		"id": id,
		"name": str(data.get("name", "carte")).left(40),
		"author": str(data.get("author", "?")).left(40),
		"origin": "downloaded",
		"published": true,
		"version": int(data.get("version", 0)),
		"cells": sanitize(data.get("cells", {})),
	}
	PIECES.save(map)
	library_changed.emit()
	return map

## Keeps a copy of the map the host plays, so everyone has it afterwards.
func receive_map(data: Dictionary, _played: bool):
	var id: String = str(data.get("id", ""))
	if id == "" or not PIECES.load_map(id).is_empty():
		return
	var map: Dictionary = save_downloaded(data)
	if not map.is_empty():
		show_toast("CARTE AJOUTEE A TA BIBLIOTHEQUE : %s (par %s)" % [map.name, map.author])

## Only known pieces on the board: a received map is data, nothing else.
func sanitize(raw) -> Dictionary:
	var cells: Dictionary = {}
	if not raw is Dictionary:
		return cells
	for cell_key in raw.keys():
		var info = raw[cell_key]
		var cell: Vector2i = PIECES.cell_of(str(cell_key))
		if not info is Dictionary or not PIECES.inside(cell):
			continue
		var item: String = str(info.get("item", ""))
		if item != "" and not PIECES.ITEMS.has(item):
			item = ""
		cells[PIECES.key(cell)] = {"floor": bool(info.get("floor", true)), "item": item, "rot": posmod(int(info.get("rot", 0)), 4)}
	return cells

func show_toast(text: String):
	if not toast_layer:
		toast_layer = CanvasLayer.new()
		toast_layer.layer = 125
		add_child(toast_layer)
		toast = Label.new()
		toast.add_theme_font_size_override("font_size", 13)
		toast.add_theme_color_override("font_color", Color(0.4, 1.0, 0.5))
		toast.add_theme_color_override("font_outline_color", Color.BLACK)
		toast.add_theme_constant_override("outline_size", 5)
		toast.position = Vector2(14, 70)
		toast_layer.add_child(toast)
	toast.text = text
	toast.modulate.a = 1.0
	var t := toast.create_tween()
	t.tween_interval(4.0)
	t.tween_property(toast, "modulate:a", 0.0, 0.6)
