extends Node3D

## L'ATELIER, the editor: paint a map on a 12 x 12 grid with the mouse, keep a library of maps, publish them
## to the online store and download other players' maps.
## Left click paints the selected piece (drag to paint several), right click erases, R or the wheel turns it.

const PIECES = preload("user://mods/machine_party_unlocked/atelier/pieces.gd")
const DA = preload("user://mods/machine_party_unlocked/da_kit.gd")

var map: Dictionary = {}
var visuals: Dictionary = {}
var tool: String = "floor"
var rot: int = 0
var camera: Camera3D
var cursor: Node3D
var cursor_cell: Vector2i = Vector2i(-1, -1)
var painting: int = 0
var busy: bool = false

var store: Node
var name_edit: LineEdit
var status: Label
var tool_buttons: Dictionary = {}
var tab_map: Control
var tab_store: Control
var library_list: ItemList
var library_ids: Array = []
var store_list: ItemList
var store_rows: Array = []
var store_info: Label
var sort_button: OptionButton
var search_edit: LineEdit
var publish_button: Button

func _ready() -> void :
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	CursorManager.set_locked(false, false)
	CursorManager.set_active(true)
	CursorManager.set_cursor(true, false)
	store = get_node_or_null("/root/MachinePartyMod/Store")

	var world := WorldEnvironment.new()
	world.environment = DA.environment()
	add_child(world)
	DA.add_post_processing(self)

	camera = Camera3D.new()
	camera.fov = 58.0
	add_child(camera)
	# the board sits between the tool list (left) and the panels (right)
	camera.look_at_from_position(Vector3(3.5, 24, 15), Vector3(3.5, 0, 1.5), Vector3.UP)
	camera.current = true

	var key := OmniLight3D.new()
	key.position = Vector3(0, 14, 4)
	key.light_color = Color(0.56, 0.545, 0.485)
	key.light_energy = 90.0
	key.omni_range = 50.0
	add_child(key)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 20, 22)
	fill.light_color = Color(0.56, 0.545, 0.485)
	fill.light_energy = 22.0
	fill.omni_range = 400.0
	add_child(fill)

	var size: float = PIECES.GRID * PIECES.CELL
	var board := MeshInstance3D.new()
	var board_mesh := BoxMesh.new()
	board_mesh.size = Vector3(size, 0.1, size)
	board.mesh = board_mesh
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.08, 0.08, 0.09)
	board.material_override = dark
	board.position.y = -0.62
	add_child(board)
	for i in PIECES.GRID + 1:
		var t: float = - size * 0.5 + i * PIECES.CELL
		add_child(PIECES.box(Vector3(size, 0.02, 0.04), Vector3(0, -0.55, t), unshaded(Color(0.3, 0.3, 0.3))))
		add_child(PIECES.box(Vector3(0.04, 0.02, size), Vector3(t, -0.55, 0), unshaded(Color(0.3, 0.3, 0.3))))

	cursor = Node3D.new()
	cursor.add_child(PIECES.box(Vector3(PIECES.CELL, 0.05, PIECES.CELL), Vector3(0, 0.6, 0), unshaded(Color(1.0, 0.8, 0.2, 0.35))))
	cursor.add_child(PIECES.box(Vector3(0.25, 0.06, 0.8), Vector3(0, 0.62, -0.6), unshaded(Color(1.0, 0.8, 0.2, 0.8))))
	add_child(cursor)

	build_ui()
	open_map(PIECES.active())
	refresh_library()

func unshaded(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = color
	if color.a < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m



# ---------------- the board ----------------

func open_map(data: Dictionary):
	for node in visuals.values():
		node.queue_free()
	visuals.clear()
	map = data.duplicate(true)
	if not map.has("cells"):
		map.cells = {}
	name_edit.text = map.get("name", "")
	for cell_key in map.cells.keys():
		refresh(PIECES.cell_of(cell_key))
	update_publish_button()

func refresh(cell: Vector2i):
	var cell_key: String = PIECES.key(cell)
	if visuals.has(cell_key):
		visuals[cell_key].queue_free()
		visuals.erase(cell_key)
	if not map.cells.has(cell_key):
		return
	var node: Node3D = PIECES.build_visual(map.cells[cell_key])
	node.position = PIECES.center(cell)
	add_child(node)
	visuals[cell_key] = node

func paint(cell: Vector2i):
	if not PIECES.inside(cell):
		return
	var cell_key: String = PIECES.key(cell)
	var data: Dictionary = map.cells.get(cell_key, {"floor": true, "item": "", "rot": 0})
	if data.item == tool and data.rot == rot:
		return
	data.floor = true
	data.item = "" if tool == "floor" else tool
	data.rot = rot
	map.cells[cell_key] = data
	refresh(cell)

func erase(cell: Vector2i):
	var cell_key: String = PIECES.key(cell)
	if not map.cells.has(cell_key):
		return
	# first the piece, then the floor
	if map.cells[cell_key].item != "":
		map.cells[cell_key].item = ""
	else:
		map.cells.erase(cell_key)
	refresh(cell)

func mouse_cell(screen: Vector2) -> Vector2i:
	var origin: Vector3 = camera.project_ray_origin(screen)
	var direction: Vector3 = camera.project_ray_normal(screen)
	if abs(direction.y) < 0.001:
		return Vector2i(-1, -1)
	return PIECES.cell_at(origin + direction * (- origin.y / direction.y))

func _unhandled_input(event: InputEvent) -> void :
	if event is InputEventMouseMotion:
		cursor_cell = mouse_cell(event.position)
		cursor.visible = PIECES.inside(cursor_cell) and tab_map.visible
		if cursor.visible:
			cursor.position = PIECES.center(cursor_cell)
		if painting == 1:
			paint(cursor_cell)
		elif painting == 2:
			erase(cursor_cell)
	elif event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			painting = 1 if event.pressed else 0
			if event.pressed:
				paint(mouse_cell(event.position))
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			painting = 2 if event.pressed else 0
			if event.pressed:
				erase(mouse_cell(event.position))
		elif event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
			turn(1 if event.button_index == MOUSE_BUTTON_WHEEL_UP else -1)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode == KEY_R:
			turn(1)
		elif event.physical_keycode == KEY_ESCAPE:
			leave()

func turn(amount: int):
	rot = posmod(rot + amount, 4)
	cursor.rotation.y = - rot * PI * 0.5
	say("Orientation : %s" % ["haut", "droite", "bas", "gauche"][rot])
	var cell_key: String = PIECES.key(cursor_cell)
	if map.cells.has(cell_key) and map.cells[cell_key].item != "":
		map.cells[cell_key].rot = rot
		refresh(cursor_cell)



# ---------------- interface ----------------

func build_ui():
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)

	var title := label("L'ATELIER", 20, Color(1.0, 0.6, 0.15))
	title.position = Vector2(12, 6)
	layer.add_child(title)

	var scroll := ScrollContainer.new()
	scroll.position = Vector2(10, 38)
	scroll.size = Vector2(150, 400)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	layer.add_child(scroll)
	var tools := VBoxContainer.new()
	tools.add_theme_constant_override("separation", 2)
	scroll.add_child(tools)
	for category in PIECES.CATEGORIES:
		tools.add_child(label(category, 11, Color(1.0, 0.6, 0.15)))
		for item in PIECES.ITEMS.keys():
			if PIECES.ITEMS[item][1] != category:
				continue
			var button := make_button(PIECES.ITEMS[item][0], 11)
			button.toggle_mode = true
			button.custom_minimum_size = Vector2(136, 0)
			button.pressed.connect(select_tool.bind(item))
			tools.add_child(button)
			tool_buttons[item] = button
	select_tool("floor")

	var help := label("Clic gauche : poser\nClic droit : effacer\nMolette ou R : tourner\nEchap : quitter", 10, Color(0.75, 0.75, 0.7))
	help.position = Vector2(12, 448)
	layer.add_child(help)

	# right side: two tabs
	var tabs := HBoxContainer.new()
	tabs.position = Vector2(706, 8)
	tabs.add_theme_constant_override("separation", 4)
	layer.add_child(tabs)
	var tab_map_button := make_button("MA CARTE", 13)
	tab_map_button.custom_minimum_size = Vector2(118, 0)
	tabs.add_child(tab_map_button)
	var tab_store_button := make_button("STORE", 13)
	tab_store_button.custom_minimum_size = Vector2(118, 0)
	tabs.add_child(tab_store_button)

	tab_map = VBoxContainer.new()
	tab_map.position = Vector2(706, 42)
	tab_map.custom_minimum_size = Vector2(240, 0)
	tab_map.add_theme_constant_override("separation", 4)
	layer.add_child(tab_map)
	tab_map.add_child(label("NOM DE LA CARTE", 10, Color(0.8, 0.8, 0.75)))
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "ma carte"
	name_edit.max_length = 40
	tab_map.add_child(name_edit)
	var row1 := HBoxContainer.new()
	tab_map.add_child(row1)
	row1.add_child(wide_button("SAUVEGARDER", save_map))
	row1.add_child(wide_button("NOUVELLE", new_map))
	var row2 := HBoxContainer.new()
	tab_map.add_child(row2)
	row2.add_child(wide_button("JOUER CETTE CARTE", use_map))
	publish_button = wide_button("PUBLIER", publish_map)
	row2.add_child(publish_button)
	tab_map.add_child(label("MA BIBLIOTHEQUE", 10, Color(0.8, 0.8, 0.75)))
	library_list = ItemList.new()
	library_list.custom_minimum_size = Vector2(240, 230)
	library_list.add_theme_font_size_override("font_size", 11)
	library_list.item_activated.connect(func(i): open_map(PIECES.load_map(library_ids[i])))
	tab_map.add_child(library_list)
	var row3 := HBoxContainer.new()
	tab_map.add_child(row3)
	row3.add_child(wide_button("OUVRIR", func(): open_selected()))
	row3.add_child(wide_button("SUPPRIMER", func(): delete_selected()))

	tab_store = VBoxContainer.new()
	tab_store.position = Vector2(706, 42)
	tab_store.custom_minimum_size = Vector2(240, 0)
	tab_store.add_theme_constant_override("separation", 4)
	tab_store.visible = false
	layer.add_child(tab_store)
	var filters := HBoxContainer.new()
	tab_store.add_child(filters)
	sort_button = OptionButton.new()
	sort_button.add_item("RECENTES")
	sort_button.add_item("POPULAIRES")
	sort_button.add_item("MIEUX NOTEES")
	sort_button.add_theme_font_size_override("font_size", 11)
	sort_button.item_selected.connect(func(_i): refresh_store())
	filters.add_child(sort_button)
	search_edit = LineEdit.new()
	search_edit.placeholder_text = "chercher"
	search_edit.custom_minimum_size = Vector2(110, 0)
	search_edit.text_submitted.connect(func(_t): refresh_store())
	filters.add_child(search_edit)
	store_list = ItemList.new()
	store_list.custom_minimum_size = Vector2(240, 250)
	store_list.add_theme_font_size_override("font_size", 11)
	store_list.item_selected.connect(show_store_info)
	tab_store.add_child(store_list)
	store_info = label("", 11, Color(0.9, 0.88, 0.8))
	store_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	store_info.custom_minimum_size = Vector2(240, 40)
	tab_store.add_child(store_info)
	var row4 := HBoxContainer.new()
	tab_store.add_child(row4)
	row4.add_child(wide_button("TELECHARGER", download_selected))
	row4.add_child(wide_button("J'AIME", like_selected))
	tab_store.add_child(wide_button("ACTUALISER", refresh_store))

	tab_map_button.pressed.connect(func():
		tab_map.visible = true
		tab_store.visible = false)
	tab_store_button.pressed.connect(func():
		tab_map.visible = false
		tab_store.visible = true
		refresh_store())

	var back := make_button("RETOUR AU MENU", 12)
	back.position = Vector2(706, 506)
	back.custom_minimum_size = Vector2(240, 0)
	back.pressed.connect(leave)
	layer.add_child(back)

	status = label("", 12, Color(0.95, 0.9, 0.6))
	status.position = Vector2(170, 512)
	layer.add_child(status)

func label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 4)
	return l

func make_button(text: String, size: int = 12) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", size)
	b.focus_mode = Control.FOCUS_NONE
	return b

func wide_button(text: String, action: Callable) -> Button:
	var b := make_button(text, 11)
	b.custom_minimum_size = Vector2(118, 0)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(action)
	return b

func say(text: String):
	status.text = text

func select_tool(item: String):
	tool = item
	for other in tool_buttons.keys():
		tool_buttons[other].button_pressed = other == item



# ---------------- library ----------------

func refresh_library():
	library_list.clear()
	library_ids.clear()
	var active: String = PIECES.active_id()
	for entry in PIECES.library():
		var tags: Array[String] = []
		if entry.id == active:
			tags.append("ACTIVE")
		if entry.get("origin", "mine") == "downloaded":
			tags.append("de " + str(entry.get("author", "?")))
		elif entry.get("published", false):
			tags.append("publiee")
		library_list.add_item("%s%s" % [entry.name, ("  [" + ", ".join(tags) + "]") if not tags.is_empty() else ""])
		library_ids.append(entry.id)

func selected_library_id() -> String:
	var picked: PackedInt32Array = library_list.get_selected_items()
	return library_ids[picked[0]] if not picked.is_empty() else ""

func open_selected():
	var id: String = selected_library_id()
	if id != "":
		open_map(PIECES.load_map(id))
		say("Carte ouverte.")

func delete_selected():
	var id: String = selected_library_id()
	if id == "":
		return
	PIECES.delete(id)
	if map.get("id", "") == id:
		map.id = ""
	refresh_library()
	say("Carte supprimee de ta bibliotheque.")

func spawn_count() -> int:
	var count: int = 0
	for data in map.cells.values():
		if data.item == "spawn":
			count += 1
	return count

## Saves into the library. Editing someone else's map makes it your own copy.
func save_map() -> bool:
	var map_name: String = name_edit.text.strip_edges()
	if map_name == "":
		say("Donne un nom a ta carte.")
		return false
	if spawn_count() == 0:
		say("Pose au moins un DEPART (5 conseilles).")
		return false
	if map.get("origin", "mine") == "downloaded" or map.get("author", "") not in ["", PIECES.my_name()]:
		map.id = ""
		map.published = false
		if map_name == map.get("name", ""):
			map_name = (map_name + " (copie)").left(40)
	map.name = map_name
	map.author = PIECES.my_name()
	map.origin = "mine"
	PIECES.save(map)
	name_edit.text = map.name
	refresh_library()
	update_publish_button()
	say("\"%s\" sauvegardee." % map.name)
	return true

func new_map():
	open_map({"id": "", "name": "", "author": PIECES.my_name(), "origin": "mine", "published": false, "cells": {}})
	say("Nouvelle carte.")

func use_map():
	if not save_map():
		return
	PIECES.set_active(map.id)
	if store:
		store.set_workshop_title(map.name, map.get("author", ""))
	refresh_library()
	say("\"%s\" sera jouee dans L'ATELIER quand tu es l'hote." % map.name)

func update_publish_button():
	if publish_button:
		publish_button.text = "METTRE A JOUR" if map.get("published", false) and map.get("origin", "mine") == "mine" else "PUBLIER"

func publish_map():
	if busy or not store:
		return
	if not save_map():
		return
	busy = true
	say("Publication...")
	var thumb: String = await capture_thumb()
	var answer: Array = await store.publish(map, thumb)
	busy = false
	if answer[0]:
		say("\"%s\" est sur le store !" % map.name)
		refresh_library()
		update_publish_button()
	else:
		say("Echec de la publication : " + str(answer[1]))



## The map's picture for the store: the board seen from its own camera, as a base64 JPEG.
func capture_thumb() -> String:
	var low := Vector2(INF, INF)
	var high := Vector2(-INF, -INF)
	for cell_key in map.cells.keys():
		var p: Vector3 = PIECES.center(PIECES.cell_of(cell_key))
		low = Vector2(min(low.x, p.x), min(low.y, p.z))
		high = Vector2(max(high.x, p.x), max(high.y, p.z))
	if low.x == INF:
		return ""
	var mid := Vector3((low.x + high.x) * 0.5, 0.0, (low.y + high.y) * 0.5)
	var extent: float = max(high.x - low.x, high.y - low.y) + PIECES.CELL * 2.0
	var shot := SubViewport.new()
	shot.size = Vector2i(400, 250)
	shot.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(shot)
	var shot_camera := Camera3D.new()
	shot_camera.fov = 50.0
	shot.add_child(shot_camera)
	shot_camera.look_at_from_position(mid + Vector3(0.0, extent * 0.8 + 3.0, extent * 0.7 + 3.0), mid + Vector3(0.0, -0.5, 0.0), Vector3.UP)
	shot_camera.current = true
	cursor.visible = false
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var image: Image = shot.get_texture().get_image()
	shot.queue_free()
	if image == null:
		return ""
	return Marshalls.raw_to_base64(image.save_jpg_to_buffer(0.8))

# ---------------- store ----------------

func refresh_store():
	if busy or not store:
		return
	busy = true
	store_list.clear()
	store_rows = []
	store_info.text = "Chargement..."
	var answer: Array = await store.list_maps(["recent", "popular", "liked"][sort_button.selected], search_edit.text)
	busy = false
	if not answer[0]:
		store_info.text = "Store indisponible : " + str(answer[1])
		return
	store_rows = answer[1] if answer[1] is Array else []
	for row in store_rows:
		store_list.add_item("%s  -  %s" % [row.name, row.author])
	store_info.text = "%d cartes. Choisis-en une." % store_rows.size() if not store_rows.is_empty() else "Aucune carte pour l'instant. Publie la premiere !"

func selected_row() -> Dictionary:
	var picked: PackedInt32Array = store_list.get_selected_items()
	return store_rows[picked[0]] if not picked.is_empty() else {}

func show_store_info(_index: int):
	var row: Dictionary = selected_row()
	if row.is_empty():
		return
	store_info.text = "%s, par %s\n%d pieces  -  %d telechargements  -  %d j'aime" % [row.name, row.author, row.pieces, row.downloads, row.likes]

func download_selected():
	var row: Dictionary = selected_row()
	if row.is_empty() or busy:
		return
	busy = true
	say("Telechargement...")
	var downloaded: Dictionary = await store.download(row.id)
	busy = false
	if downloaded.is_empty():
		say("Echec du telechargement.")
		return
	refresh_library()
	open_map(downloaded)
	say("\"%s\" de %s est dans ta bibliotheque. JOUER CETTE CARTE pour la lancer." % [downloaded.name, downloaded.author])

func like_selected():
	var row: Dictionary = selected_row()
	if row.is_empty() or busy:
		return
	busy = true
	var answer: Array = await store.like(row.id)
	busy = false
	say("Merci pour le j'aime !" if answer[0] else "Echec : " + str(answer[1]))
	if answer[0]:
		row.likes = int(answer[1])
		show_store_info(0)

func leave():
	get_tree().change_scene_to_file("res://scenes/main_menu/main_menu.tscn")
