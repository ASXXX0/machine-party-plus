extends Node

## Machine Party Overtime party layer. Lives at /root/MachinePartyMod/Party on every peer (same path everywhere, so it
## can RPC without the minigame scene):
## - factory breakdowns: before some minigames the host draws a modifier that bends the rules for everyone;
## - party stats kept by the host (falls, jumps, emotes, ghost shoves, wins), turned into titles at the end.

const MODIFIER_CHANCE: float = 0.4
const MODIFIERS: Dictionary = {
	"turbo": ["TURBO", "Tout le monde va 1,6 fois plus vite."],
	"lowgrav": ["GRAVITE BASSE", "On saute plus haut et on retombe lentement."],
	"inverted": ["COMMANDES INVERSEES", "Gauche c'est droite, haut c'est bas."],
	"slippery": ["SOL SAVONNEUX", "Ca glisse : freine a l'avance."],
	"fog": ["BROUILLARD", "On n'y voit presque plus rien."],
	"strong": ["POUSSEE MAX", "Les poussees envoient deux fois plus loin."],
}
# these need the patched Disco Dodge runner; the others work on any minigame
const RUNNER_ONLY: Array[String] = ["inverted", "slippery", "strong"]
const RUNNER_GAMES: Array[String] = ["DiscoDodge", "Sweeper", "Press", "Crane", "Minority", "Balance", "Finale",
	"Wall", "Searchlight", "Foundry", "Paint", "Delivery", "Fans", "Slope", "Maze", "Pendulum", "Pistons", "Workshop", "Cable", "Dalles", "Vedette"]
const NO_BODY_GAMES: Array[String] = ["Pressure", "Cadence"]

var modifier: String = ""
var modifier_identifier: int = -1
var active_minigame: Node
var scan_timer: float = 0.0

# host only: network id -> {stat: count}
var stats: Dictionary = {}

var layer: CanvasLayer
var banner: Control
var banner_title: Label
var banner_text: Label
var corner_tag: Label

func _ready() -> void :
	GameManager.minigame_loaded.connect(_on_minigame_loaded)
	get_tree().node_added.connect(_on_node_added)
	build_ui()



func _on_node_added(node: Node):

	if node is IntermissionManager:
		# a new party starts
		stats.clear()
		return

	if node is Minigame:
		active_minigame = node
		if multiplayer.is_server():
			node.player_scores_finalized.connect(_on_scores_finalized)
		return

	if multiplayer.is_server() and node is CharacterBody3D and node.has_signal("died"):
		node.died.connect(func(network_id): add_stat(network_id, "falls"))

func _on_minigame_loaded(identifier: int):

	if not multiplayer.is_server():
		return

	var key: String = Globals.MinigameIdentifier.keys()[identifier]
	var choice: String = ""
	if not Globals.CutsceneMinigameIdentifiers.has(identifier) \
			and not Globals.CutsceneGlitchedPickerMinigameIdentifiers.has(identifier) \
			and randf() < MODIFIER_CHANCE:
		var pool: Array = []
		for mod_key in MODIFIERS.keys():
			if RUNNER_ONLY.has(mod_key) and not RUNNER_GAMES.has(key):
				continue
			if NO_BODY_GAMES.has(key) and mod_key != "fog":
				continue
			pool.append(mod_key)
		choice = pool.pick_random()
	set_modifier_rpc.rpc(identifier, choice)

@rpc("authority", "call_local", "reliable")
func set_modifier_rpc(identifier: int, key: String):
	modifier = key
	modifier_identifier = identifier
	corner_tag.visible = false
	if key == "":
		return
	show_banner()

func _process(delta: float) -> void :

	if modifier == "":
		return

	if not is_instance_valid(active_minigame) or GameManager.current_minigame_identifier != modifier_identifier:
		corner_tag.visible = false
		return

	corner_tag.visible = not banner.visible
	scan_timer -= delta
	if scan_timer > 0.0:
		return
	scan_timer = 0.5

	# minigames spawn their players late (on initialize), so keep looking for new bodies
	for body in active_minigame.find_children("*", "CharacterBody3D", true, false):
		if not body.has_meta("mpplus_modifier"):
			body.set_meta("mpplus_modifier", modifier)
			apply_to_body(body)
	if modifier == "fog":
		for world in active_minigame.find_children("*", "WorldEnvironment", true, false):
			if world.environment and not world.has_meta("mpplus_fog"):
				world.set_meta("mpplus_fog", true)
				world.environment = world.environment.duplicate()
				world.environment.fog_enabled = true
				world.environment.fog_light_color = Color(0.25, 0.26, 0.27)
				world.environment.fog_density = 0.025
				world.environment.fog_sky_affect = 1.0

func apply_to_body(body: Node):
	match modifier:
		"turbo":
			if "speed" in body and body.speed is float:
				body.speed *= 1.6
		"lowgrav":
			if "gravity" in body and body.gravity is float:
				body.gravity *= 0.45
		"inverted":
			if "mpplus_input_sign" in body:
				body.mpplus_input_sign = -1.0
		"slippery":
			if "mpplus_slippery" in body:
				body.mpplus_slippery = true
		"strong":
			if "shove_strength" in body:
				body.shove_strength *= 2.0



func add_stat(network_id: int, stat: String, amount: int = 1):
	if not multiplayer.is_server():
		return
	if not stats.has(network_id):
		stats[network_id] = {}
	stats[network_id][stat] = stats[network_id].get(stat, 0) + amount

@rpc("any_peer", "call_local", "reliable")
func add_stat_remote(network_id: int, stat: String):
	add_stat(network_id, stat)

func _on_scores_finalized(scores: Dictionary):
	var best: int = -999999
	for network_id in scores.keys():
		best = max(best, scores[network_id])
	for network_id in scores.keys():
		if scores[network_id] == best:
			add_stat(network_id, "wins")

func stat_of(network_id: int, stat: String) -> int:
	return stats.get(network_id, {}).get(stat, 0)

## Host: the party is over, hand out the titles.
func session_ended():

	var ids: Array = PlayerManager.player_presences.keys()
	if ids.is_empty():
		return

	var lines: Array = []
	add_title(lines, ids, "wins", true, 1, "MACHINE A GAGNER", "%d manches gagnees")
	add_title(lines, ids, "falls", true, 1, "LE PLUS EJECTE", "%d chutes")
	var falls: Array = ids.map(func(i): return stat_of(i, "falls"))
	if ids.size() > 1 and falls.min() < falls.max():
		add_title(lines, ids, "falls", false, 0, "INCREVABLE", "%d chutes seulement")
	add_title(lines, ids, "jumps", true, 3, "KANGOUROU", "%d sauts")
	add_title(lines, ids, "ghost", true, 1, "FANTOME FARCEUR", "%d coups de fantome")
	add_title(lines, ids, "emotes", true, 2, "GRANDE GUEULE", "%d provocations")

	if lines.is_empty():
		return
	show_titles_rpc.rpc(lines)

func add_title(lines: Array, ids: Array, stat: String, highest: bool, minimum: int, title: String, detail: String):
	var best_id: int = -1
	var best_value: int = 0
	for network_id in ids:
		var value: int = stat_of(network_id, stat)
		if best_id == -1 or (value > best_value if highest else value < best_value):
			best_id = network_id
			best_value = value
	if best_id == -1 or (highest and best_value < minimum):
		return
	var player_name: String = PlayerManager.player_presences[best_id].network_name
	lines.append([title, player_name, detail % best_value])



func build_ui():

	layer = CanvasLayer.new()
	layer.layer = 110
	add_child(layer)

	banner = PanelContainer.new()
	banner.visible = false
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.04, 0.03, 0.92)
	style.border_color = Color(1.0, 0.55, 0.1)
	style.set_border_width_all(2)
	style.set_content_margin_all(10)
	banner.add_theme_stylebox_override("panel", style)
	banner.position = Vector2(230, 30)
	banner.custom_minimum_size = Vector2(500, 0)
	layer.add_child(banner)
	var column := VBoxContainer.new()
	banner.add_child(column)
	banner_title = make_label(22, Color(1.0, 0.6, 0.15))
	column.add_child(banner_title)
	banner_text = make_label(14, Color(0.92, 0.9, 0.85))
	column.add_child(banner_text)

	corner_tag = make_label(12, Color(1.0, 0.6, 0.15))
	corner_tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	corner_tag.position = Vector2(12, 512)
	corner_tag.visible = false
	layer.add_child(corner_tag)

func make_label(size: int, color: Color) -> Label:
	var label := Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color.BLACK)
	label.add_theme_constant_override("outline_size", 4)
	return label

func show_banner():
	banner_title.text = "PANNE D'USINE : " + MODIFIERS[modifier][0]
	banner_text.text = MODIFIERS[modifier][1]
	corner_tag.text = "PANNE : " + MODIFIERS[modifier][0]
	banner.visible = true
	banner.modulate.a = 0.0
	var t := banner.create_tween()
	t.tween_interval(1.5)
	t.tween_property(banner, "modulate:a", 1.0, 0.3)
	t.tween_interval(7.0)
	t.tween_property(banner, "modulate:a", 0.0, 0.5)
	t.tween_callback(func(): banner.visible = false)

@rpc("authority", "call_local", "reliable")
func show_titles_rpc(lines: Array):

	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.03, 0.03, 0.94)
	style.border_color = Color(1.0, 0.55, 0.1)
	style.set_border_width_all(2)
	style.set_content_margin_all(16)
	panel.add_theme_stylebox_override("panel", style)
	panel.custom_minimum_size = Vector2(560, 0)
	panel.modulate.a = 0.0
	layer.add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 6)
	panel.add_child(column)
	var heading := make_label(24, Color(1.0, 0.6, 0.15))
	heading.text = "TITRES DE LA SOIREE"
	column.add_child(heading)

	var rows: Array[Control] = []
	for line in lines:
		var row := VBoxContainer.new()
		row.add_theme_constant_override("separation", 0)
		var title := make_label(18, Color(1.0, 0.85, 0.35))
		title.text = "%s : %s" % [line[0], line[1]]
		row.add_child(title)
		var detail := make_label(12, Color(0.8, 0.78, 0.74))
		detail.text = line[2]
		row.add_child(detail)
		row.modulate.a = 0.0
		column.add_child(row)
		rows.append(row)

	await get_tree().process_frame
	panel.position = (Vector2(960, 540) - panel.size) * 0.5

	var t := panel.create_tween()
	t.tween_interval(1.5)
	t.tween_property(panel, "modulate:a", 1.0, 0.4)
	for row in rows:
		t.tween_interval(0.7)
		t.tween_property(row, "modulate:a", 1.0, 0.3)
	t.tween_interval(12.0)
	t.tween_property(panel, "modulate:a", 0.0, 0.8)
	t.tween_callback(panel.queue_free)
