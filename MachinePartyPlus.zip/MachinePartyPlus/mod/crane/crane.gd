extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LA GRUE: one player runs an overhead claw crane from the booth and drops the others into the shredder; the
## rest dodge (and shove each other under the claw). The operator seat rotates with the minigame round. Alone,
## the crane is driven by the machine. The claw is simulated on the server and synced; runners stay
## owner-simulated like in the game's other minigames, and a caught runner is pinned to the claw on every peer.

const ARENA_HALF := Vector2(9.5, 6.5)
const CLAW_UP_Y: float = 6.5
const CLAW_DOWN_Y: float = 1.75
const CLAW_SPEED: float = 7.5
const GRAB_RADIUS: float = 1.35
const SHREDDER_POS := Vector3(0.0, 0.0, -9.6)
const BOOTH_POS := Vector3(-12.5, 2.2, 2.0)

enum Claw { MOVE, DROP, LIFT, CARRY, RELEASE, RETURN }

var operator_id: int = -1
var claw_state: int = Claw.MOVE
var claw_pos := Vector3(0.0, CLAW_UP_Y, 0.0)
var claw_open: float = 1.0
var claw_input := Vector2.ZERO
var caught_id: int = -1
var catches: int = 0
var ai_wait: float = 0.0
var sync_timer: float = 0.0

# visuals
var claw_node: Node3D
var finger_pivots: Array[Node3D] = []
var gantry_node: Node3D
var trolley_node: Node3D
var shadow_node: MeshInstance3D
var drums: Array[Node3D] = []
var shown_claw := Vector3(0.0, CLAW_UP_Y, 0.0)
var shown_open: float = 1.0
var shown_caught: int = -1

func spawn_points() -> Array[Vector3]:
	return [Vector3(-4, 0.1, 2), Vector3(4, 0.1, 2), Vector3(-2, 0.1, 4.5), Vector3(2, 0.1, 4.5), Vector3(0, 0.1, 1)]

func build_arena():

	max_duration = 60.0

	set_camera(Vector3(0.0, 15.0, 15.5), Vector3(0.0, 0.0, -1.5))

	add_sound("ambience", "res://audio/unique/dvd roomba/dvd roomba ambience.ogg", -8.0, true)
	add_sound("motor", "res://audio/unique/intermission/intermission servo2.ogg", -6.0)
	add_sound("drop", "res://audio/unique/intermission/intermission servo1.ogg", -4.0)
	add_sound("grab", "res://audio/sfx/manufacture_gun_pickup_gear.ogg", 0.0)
	add_sound("shred", "res://audio/unique/disco dodge/dd fall scream impact.ogg", 0.0)
	add_sound("miss", "res://audio/sfx/manufacture_gun_wrong_insert_error.ogg", -6.0)

	# warehouse of Forklift Certified around a fenced pick floor
	var warehouse: PackedScene = load("res://minigames/forklift_certified/models/forklift certified visuals1/forklift certified visuals1.glb")
	if warehouse:
		var hall: Node3D = warehouse.instantiate()
		hall.rotation.y = - PI * 0.5
		hall.position = Vector3(0.0, -0.02, -85.0)
		arena.add_child(hall)

	var floor_body := StaticBody3D.new()
	arena.add_child(floor_body)
	add_box_collider(floor_body, Vector3(60, 1, 60), Vector3(0, -0.5, 0))
	# invisible fences keep runners on the pick floor
	add_box_collider(floor_body, Vector3(1, 6, 16), Vector3(-ARENA_HALF.x - 0.5, 3, 0))
	add_box_collider(floor_body, Vector3(1, 6, 16), Vector3(ARENA_HALF.x + 0.5, 3, 0))
	add_box_collider(floor_body, Vector3(22, 6, 1), Vector3(0, 3, -ARENA_HALF.y - 0.5))
	add_box_collider(floor_body, Vector3(22, 6, 1), Vector3(0, 3, ARENA_HALF.y + 0.5))

	var pad := MeshInstance3D.new()
	var pad_mesh := PlaneMesh.new()
	pad_mesh.size = ARENA_HALF * 2.0
	pad.mesh = pad_mesh
	var pad_material: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_HAZARD, Color(0.85, 0.83, 0.78), 1.0 / 3.0)
	pad.material_override = pad_material
	pad.position = Vector3(0, 0.01, 0)
	arena.add_child(pad)

	for z in [-ARENA_HALF.y, ARENA_HALF.y]:
		var rail := MeshInstance3D.new()
		var rail_mesh := BoxMesh.new()
		rail_mesh.size = Vector3(ARENA_HALF.x * 2.0 + 0.4, 1.1, 0.2)
		rail.mesh = rail_mesh
		rail.material_override = DA.kind_material("mp_hazard")
		rail.position = Vector3(0, 0.55, z)
		arena.add_child(rail)
	for x in [-ARENA_HALF.x, ARENA_HALF.x]:
		var rail := MeshInstance3D.new()
		var rail_mesh := BoxMesh.new()
		rail_mesh.size = Vector3(0.2, 1.1, ARENA_HALF.y * 2.0)
		rail.mesh = rail_mesh
		rail.material_override = DA.kind_material("mp_hazard")
		rail.position = Vector3(x, 0.55, 0)
		arena.add_child(rail)

	# shredder behind the back fence
	var shredder: Node3D = DA.load_model("shredder.glb")
	shredder.position = SHREDDER_POS + Vector3(0, 0.02, 0)
	arena.add_child(shredder)
	for z in [-0.55, 0.55]:
		var drum: Node3D = DA.load_model("shredder_drum.glb")
		drum.position = SHREDDER_POS + Vector3(0, -0.7, z)
		arena.add_child(drum)
		drums.append(drum)

	# gantry over the floor: runway beams along Z, a bridge that follows the claw, a trolley on the bridge
	for x in [-11.3, 11.3]:
		var runway := MeshInstance3D.new()
		var runway_mesh := BoxMesh.new()
		runway_mesh.size = Vector3(0.6, 0.8, 26.0)
		runway.mesh = runway_mesh
		runway.material_override = DA.kind_material("mp_dark")
		runway.position = Vector3(x, 9.6, -2.0)
		arena.add_child(runway)
		for z in [-14.0, 10.0]:
			var column := MeshInstance3D.new()
			var column_mesh := BoxMesh.new()
			column_mesh.size = Vector3(0.5, 10.0, 0.5)
			column.mesh = column_mesh
			column.material_override = DA.kind_material("mp_metal")
			column.position = Vector3(x, 5.0, z)
			arena.add_child(column)

	gantry_node = DA.load_model("gantry.glb")
	gantry_node.position = Vector3(0, 9.0, 0)
	arena.add_child(gantry_node)

	trolley_node = MeshInstance3D.new()
	var trolley_mesh := BoxMesh.new()
	trolley_mesh.size = Vector3(1.4, 0.8, 1.6)
	trolley_node.mesh = trolley_mesh
	trolley_node.material_override = DA.kind_material("mp_dark")
	trolley_node.position = Vector3(0, 9.9, 0)
	arena.add_child(trolley_node)

	claw_node = DA.load_model("claw_body.glb")
	claw_node.position = claw_pos
	arena.add_child(claw_node)
	for k in 3:
		var angle: float = k * TAU / 3.0
		var pivot := Node3D.new()
		pivot.position = Vector3(cos(angle) * 0.45, -0.3, sin(angle) * 0.45)
		pivot.rotation.y = - angle
		claw_node.add_child(pivot)
		pivot.add_child(DA.load_model("claw_finger.glb"))
		finger_pivots.append(pivot)

	shadow_node = MeshInstance3D.new()
	var shadow_mesh := CylinderMesh.new()
	shadow_mesh.top_radius = GRAB_RADIUS
	shadow_mesh.bottom_radius = GRAB_RADIUS
	shadow_mesh.height = 0.02
	shadow_node.mesh = shadow_mesh
	var shadow_material := StandardMaterial3D.new()
	shadow_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shadow_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	shadow_material.albedo_color = Color(0.9, 0.1, 0.05, 0.35)
	shadow_node.material_override = shadow_material
	shadow_node.position = Vector3(0, 0.03, 0)
	arena.add_child(shadow_node)

	var booth := MeshInstance3D.new()
	var booth_mesh := BoxMesh.new()
	booth_mesh.size = Vector3(3.0, 0.4, 3.0)
	booth.mesh = booth_mesh
	booth.material_override = DA.kind_material("mp_dark")
	booth.position = BOOTH_POS - Vector3(0, 0.2, 0)
	arena.add_child(booth)
	var booth_body := StaticBody3D.new()
	arena.add_child(booth_body)
	add_box_collider(booth_body, Vector3(3.0, 0.4, 3.0), BOOTH_POS - Vector3(0, 0.2, 0))

	var key := OmniLight3D.new()
	key.position = Vector3(0, 8, 1)
	key.light_color = Color(0.56, 0.545, 0.485)
	key.light_energy = 70.0
	key.omni_range = 40.0
	key.shadow_enabled = true
	arena.add_child(key)
	var shred_light := OmniLight3D.new()
	shred_light.position = SHREDDER_POS + Vector3(0, 1.5, 1.5)
	shred_light.light_color = Color(1.0, 0.3, 0.1)
	shred_light.light_energy = 8.0
	shred_light.omni_range = 8.0
	arena.add_child(shred_light)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 15, 25)
	fill.light_color = Color(0.56, 0.545, 0.485)
	fill.light_energy = 14.0
	fill.omni_range = 400.0
	arena.add_child(fill)

func add_box_collider(body: StaticBody3D, size: Vector3, _position: Vector3):
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	shape.position = _position
	body.add_child(shape)



func initialize(_round_number: int, _total_rounds: int, _scores: Dictionary = {}):
	super.initialize(_round_number, _total_rounds, _scores)

	var ids: Array = players.keys()
	if ids.size() >= 2:
		operator_id = ids[(_round_number - 1) % ids.size()]
	set_operator_rpc.rpc(operator_id)

@rpc("authority", "call_local", "reliable")
func set_operator_rpc(_operator_id: int):
	operator_id = _operator_id
	if operator_id == -1:
		return
	await get_tree().process_frame
	var operator = players.get(operator_id, null)
	if operator:
		operator.teleport_rpc(BOOTH_POS)
		operator.visuals.rotation.y = deg_to_rad(-60.0)
		if multiplayer.is_server():
			active_players.erase(operator_id)

func on_play_start():
	for network_id in players.keys():
		if network_id != operator_id:
			players[network_id].set_active_rpc.rpc(true)

func on_play_start_local():
	if operator_id == multiplayer.get_unique_id():
		set_countdown_mesage_rpc("TU ES LA GRUE", 1.2)

func check_game_end_on_death():
	if game_end:
		return
	var runners_left: int = 0
	for network_id in active_players.keys():
		if network_id != operator_id:
			runners_left += 1
	if runners_left == 0:
		end_game()

func compute_scores() -> Dictionary[int, int]:
	var scores: Dictionary[int, int]
	for i in dead_players.size():
		scores[dead_players[i]] = i
	for network_id in active_players.keys():
		scores[network_id] = player_count
	if operator_id != -1:
		var runners: int = player_count - 1
		scores[operator_id] = player_count if catches >= runners else catches
	return scores



func visual_tick(delta: float):

	# operator input goes to the server
	if running and operator_id != -1 and operator_id == multiplayer.get_unique_id() and not PauseMenu.active:
		var input := Vector2(Input.get_axis("left", "right"), Input.get_axis("up", "down"))
		var drop: bool = Input.is_action_just_pressed("action_1")
		if multiplayer.is_server():
			claw_input = input
			if drop:
				request_drop()
		else:
			operator_input_rpc.rpc_id(1, input)
			if drop:
				operator_drop_rpc.rpc_id(1)

	shown_claw = shown_claw.lerp(claw_pos, min(delta * 14.0, 1.0)) if multiplayer.is_server() else shown_claw.lerp(claw_pos, min(delta * 10.0, 1.0))
	shown_open = lerp(shown_open, claw_open, min(delta * 10.0, 1.0))

	if claw_node:
		claw_node.position = shown_claw
		gantry_node.position.z = shown_claw.z
		trolley_node.position = Vector3(shown_claw.x, 9.9, shown_claw.z)
		shadow_node.position = Vector3(shown_claw.x, 0.03, shown_claw.z)
		shadow_node.visible = shown_claw.z > -ARENA_HALF.y - 0.5
		for pivot in finger_pivots:
			pivot.rotation.z = lerp(0.0, deg_to_rad(38.0), shown_open)
		for i in drums.size():
			drums[i].rotation.x += delta * (6.0 if i == 0 else -6.0)

	# a caught runner hangs from the claw on every peer
	if shown_caught != -1:
		var caught = players.get(shown_caught, null)
		if is_instance_valid(caught):
			caught.global_position = shown_claw + Vector3(0.0, -1.7, 0.0)

func server_tick(delta: float):

	if operator_id == -1:
		ai_drive(delta)

	match claw_state:
		Claw.MOVE:
			var move := Vector3(claw_input.x, 0.0, claw_input.y)
			if move.length() > 1.0:
				move = move.normalized()
			claw_pos += move * CLAW_SPEED * delta
			claw_pos.x = clamp(claw_pos.x, - ARENA_HALF.x + 0.5, ARENA_HALF.x - 0.5)
			claw_pos.z = clamp(claw_pos.z, - ARENA_HALF.y + 0.5, ARENA_HALF.y - 0.5)
		Claw.DROP:
			claw_pos.y = move_toward(claw_pos.y, CLAW_DOWN_Y, 16.0 * delta)
			if claw_pos.y <= CLAW_DOWN_Y:
				claw_open = 0.0
				try_grab()
		Claw.LIFT:
			claw_pos.y = move_toward(claw_pos.y, CLAW_UP_Y, 7.0 * delta)
			if claw_pos.y >= CLAW_UP_Y:
				claw_state = Claw.CARRY if caught_id != -1 else Claw.MOVE
				claw_open = 0.0 if caught_id != -1 else 1.0
		Claw.CARRY:
			var target := Vector3(SHREDDER_POS.x, CLAW_UP_Y, SHREDDER_POS.z)
			claw_pos = claw_pos.move_toward(target, CLAW_SPEED * 1.1 * delta)
			if claw_pos.distance_to(target) < 0.05:
				claw_state = Claw.RELEASE
				release_caught()
		Claw.RETURN:
			var home := Vector3(0.0, CLAW_UP_Y, 0.0)
			claw_pos = claw_pos.move_toward(home, CLAW_SPEED * delta)
			if claw_pos.distance_to(home) < 0.05:
				claw_state = Claw.MOVE

	sync_timer -= delta
	if sync_timer <= 0.0:
		sync_timer = 0.05
		sync_claw_rpc.rpc(claw_pos, claw_open)

func request_drop():
	if claw_state != Claw.MOVE:
		return
	claw_state = Claw.DROP
	claw_open = 1.0
	sound_rpc.rpc("drop")

func try_grab():

	var best_id: int = -1
	var best_distance: float = GRAB_RADIUS
	for network_id in active_players.keys():
		if network_id == operator_id:
			continue
		var player = active_players[network_id]
		var flat := Vector2(player.global_position.x - claw_pos.x, player.global_position.z - claw_pos.z)
		if flat.length() < best_distance:
			best_distance = flat.length()
			best_id = network_id

	caught_id = best_id
	claw_state = Claw.LIFT
	if caught_id != -1:
		caught_rpc.rpc(caught_id)
	else:
		sound_rpc.rpc("miss")

func release_caught():
	claw_open = 1.0
	var victim: int = caught_id
	caught_id = -1
	catches += 1
	released_rpc.rpc(victim)
	EffectManager.spawn_rpc.rpc(&"bloodmist_01", SHREDDER_POS + Vector3(0, 1.0, 0), Vector3.ZERO, Vector3.ONE)
	eliminate(victim)
	await get_tree().create_timer(0.6, false).timeout
	claw_state = Claw.RETURN

func ai_drive(delta: float):

	if claw_state != Claw.MOVE:
		claw_input = Vector2.ZERO
		return

	var target_player = null
	var best: float = INF
	for player in active_players.values():
		var d: float = Vector2(player.global_position.x - claw_pos.x, player.global_position.z - claw_pos.z).length()
		if d < best:
			best = d
			target_player = player
	if target_player == null:
		claw_input = Vector2.ZERO
		return

	var aim := Vector2(target_player.global_position.x - claw_pos.x, target_player.global_position.z - claw_pos.z)
	claw_input = aim.normalized() * clamp(aim.length() / 2.0, 0.0, 0.8)
	ai_wait -= delta
	if aim.length() < 0.9 and ai_wait <= 0.0:
		ai_wait = randf_range(0.6, 1.4)
		request_drop()



@rpc("any_peer", "call_remote", "unreliable_ordered")
func operator_input_rpc(input: Vector2):
	if multiplayer.is_server() and multiplayer.get_remote_sender_id() == operator_id:
		claw_input = input.limit_length(1.0)

@rpc("any_peer", "call_remote", "reliable")
func operator_drop_rpc():
	if multiplayer.is_server() and multiplayer.get_remote_sender_id() == operator_id:
		request_drop()

@rpc("authority", "call_remote", "unreliable_ordered")
func sync_claw_rpc(_claw_pos: Vector3, _claw_open: float):
	claw_pos = _claw_pos
	claw_open = _claw_open

@rpc("authority", "call_local", "reliable")
func caught_rpc(network_id: int):
	shown_caught = network_id
	play_sound("grab")
	var player = players.get(network_id, null)
	if player:
		player.active = false
		player.start_falling()

@rpc("authority", "call_local", "reliable")
func released_rpc(network_id: int):
	shown_caught = -1
	play_sound("shred")
	shake = min(shake + 0.6, 1.2)
	var player = players.get(network_id, null)
	if player:
		var t := create_tween()
		t.tween_property(player, "global_position", SHREDDER_POS + Vector3(0, -3.0, 0), 0.5).set_ease(Tween.EASE_IN)
		t.tween_callback( func(): player.visible = false)

@rpc("authority", "call_local", "reliable")
func sound_rpc(key: String):
	play_sound(key)
