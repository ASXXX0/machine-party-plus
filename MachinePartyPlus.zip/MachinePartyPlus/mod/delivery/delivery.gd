extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LIVRAISON: one parcel on the station platform. Walk into it to pick it up; whoever carries it is slower and
## drops it when shoved. Each player has a hatch of their own colour on the edge of the platform: bring the
## parcel to yours to score, and a new parcel drops in the middle. Every third delivery the parcel is a heavy
## one (slower, worth 2). First to 5 points, or most points when the clock runs out.

const HALF: float = 8.0
const HATCHES: Array[Vector3] = [
	Vector3(-7.0, 0.0, -7.0), Vector3(7.0, 0.0, -7.0), Vector3(7.0, 0.0, 7.0), Vector3(-7.0, 0.0, 7.0), Vector3(0.0, 0.0, -7.6)
]
const TARGET: int = 5
const CARRY_SLOW: float = 0.72

var parcel: Node3D
var parcel_pos: Vector3 = Vector3.ZERO
var carrier: int = -1
var heavy: bool = false
var deliveries: int = 0
var pickup_lock: Dictionary = {}
var hatches: Dictionary = {}
var base_speed: Dictionary = {}
var drop_requested: bool = false

func spawn_points() -> Array[Vector3]:
	return [Vector3(-3, 0.1, -3), Vector3(3, 0.1, -3), Vector3(3, 0.1, 3), Vector3(-3, 0.1, 3), Vector3(0, 0.1, -4)]

func build_arena():

	max_duration = 90.0
	set_camera(Vector3(0.0, 17.0, 14.0), Vector3(0.0, -1.0, 0.8))

	add_sound("ambience", "res://audio/unique/chisel gauntlet/machine ambience.ogg", -8.0, true)
	add_sound("pickup", "res://audio/sfx/manufacture_gun_pickup_gear.ogg", -2.0)
	add_sound("drop", "res://audio/sfx/manufacture_gun_drop_gear.ogg", -2.0)
	add_sound("score", "res://audio/sfx/manufacture_gun_correct_item_inserted.ogg", 0.0)
	add_sound("horn", "res://audio/sfx/airplane ding.ogg", -4.0)

	# a goods wagon waiting along the platform
	add_backdrop_model("res://minigames/train_race/models/train visuals2/train visuals2.glb", Vector3(-14.0, 0.0, 0.0))

	var deck: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_MARKED, Color(0.95, 0.93, 0.9), 1.0 / 8.0)
	add_box(Vector3(HALF * 2.0, 0.6, HALF * 2.0), Vector3(0.0, -0.3, 0.0), deck)
	for side in [-1.0, 1.0]:
		add_box(Vector3(0.3, 0.9, HALF * 2.0), Vector3(side * (HALF + 0.15), 0.45, 0.0), DA.kind_material("mp_hazard"))
		add_box(Vector3(HALF * 2.0 + 0.6, 0.9, 0.3), Vector3(0.0, 0.45, side * (HALF + 0.15)), DA.kind_material("mp_hazard"))

	parcel = Node3D.new()
	var box := MeshInstance3D.new()
	var box_mesh := BoxMesh.new()
	box_mesh.size = Vector3(0.75, 0.6, 0.75)
	box.mesh = box_mesh
	box.material_override = DA.base_material(DA.TEX_RUST, Color(1.0, 0.85, 0.6), 0.8)
	box.position.y = 0.3
	parcel.add_child(box)
	var strap := MeshInstance3D.new()
	var strap_mesh := BoxMesh.new()
	strap_mesh.size = Vector3(0.8, 0.62, 0.15)
	strap.mesh = strap_mesh
	strap.material_override = DA.kind_material("mp_hazard")
	strap.position.y = 0.3
	parcel.add_child(strap)
	var glow := OmniLight3D.new()
	glow.light_color = Color(1.0, 0.75, 0.3)
	glow.light_energy = 2.0
	glow.omni_range = 3.5
	glow.position.y = 1.2
	parcel.add_child(glow)
	arena.add_child(parcel)

	add_key_lights(Vector3(0.0, 12.0, 2.0), 70.0, 18.0)

	if Engine.has_meta("mpplus_preview"):
		for i in 4:
			build_hatch(i, SEAT_COLORS[i])

func build_hatch(seat: int, color: Color):
	var hatch := Node3D.new()
	hatch.position = HATCHES[seat]
	arena.add_child(hatch)
	var pad := MeshInstance3D.new()
	var pad_mesh := CylinderMesh.new()
	pad_mesh.top_radius = 1.1
	pad_mesh.bottom_radius = 1.1
	pad_mesh.height = 0.05
	pad.mesh = pad_mesh
	pad.material_override = unshaded(Color(color.r, color.g, color.b, 0.75))
	pad.position.y = 0.03
	hatch.add_child(pad)
	var chute: Node3D = DA.load_model("shredder.glb")
	chute.scale = Vector3.ONE * 0.28
	chute.position.y = 0.05
	hatch.add_child(chute)
	var lamp := OmniLight3D.new()
	lamp.light_color = color
	lamp.light_energy = 3.0
	lamp.omni_range = 3.5
	lamp.position.y = 1.5
	hatch.add_child(lamp)
	return hatch

@rpc("authority", "call_local", "reliable")
func hatches_rpc(network_ids: Array):
	for i in network_ids.size():
		hatches[network_ids[i]] = HATCHES[i]
		build_hatch(i, seat_color(network_ids[i]))

func on_play_start_local():
	fade_in_ambience()
	build_hud(true)

func on_server_play_start():
	hatches_rpc.rpc(players.keys())
	for network_id in players.keys():
		points[network_id] = 0
	points_rpc.rpc(points)

func server_tick(delta: float):

	for network_id in pickup_lock.keys():
		pickup_lock[network_id] = max(pickup_lock[network_id] - delta, 0.0)

	if carrier == -1:
		for network_id in active_players.keys():
			var player = active_players[network_id]
			if not is_instance_valid(player) or not player.active or pickup_lock.get(network_id, 0.0) > 0.0:
				continue
			if flat_distance(player.global_position, parcel_pos) < 0.9:
				carrier_rpc.rpc(network_id, heavy)
				break
		return

	var holder = players.get(carrier, null)
	if not is_instance_valid(holder) or not holder.active:
		drop(parcel_pos)
		return
	parcel_pos = holder.global_position
	if hatches.has(carrier) and flat_distance(holder.global_position, hatches[carrier]) < 1.1:
		var scorer: int = carrier
		add_points(scorer, 2 if heavy else 1)
		sfx_rpc.rpc("score")
		deliveries += 1
		heavy = deliveries % 3 == 2
		carrier_rpc.rpc(-1, heavy)
		parcel_pos = Vector3(randf_range(-2.0, 2.0), 0.0, randf_range(-2.0, 2.0))
		parcel_at_rpc.rpc(parcel_pos, true)
		if points.get(scorer, 0) >= TARGET:
			end_game()

@rpc("any_peer", "call_local", "reliable")
func request_drop_rpc(network_id: int):
	if multiplayer.is_server() and network_id == carrier and players.has(network_id):
		drop(players[network_id].global_position + Vector3(randf_range(-1.0, 1.0), 0.0, randf_range(-1.0, 1.0)))

func drop(position: Vector3):
	var flat := Vector3(position.x, 0.0, position.z)
	flat.x = clamp(flat.x, - HALF + 0.8, HALF - 0.8)
	flat.z = clamp(flat.z, - HALF + 0.8, HALF - 0.8)
	pickup_lock[carrier] = 1.2
	parcel_pos = flat
	carrier_rpc.rpc(-1, heavy)
	parcel_at_rpc.rpc(flat, false)

func flat_distance(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()

@rpc("authority", "call_local", "reliable")
func carrier_rpc(network_id: int, is_heavy: bool):
	# give back the old carrier's speed
	if carrier != -1 and players.has(carrier) and base_speed.has(carrier):
		players[carrier].speed = base_speed[carrier]
	carrier = network_id
	drop_requested = false
	heavy = is_heavy
	parcel.scale = Vector3.ONE * (1.35 if heavy else 1.0)
	if carrier == -1:
		play_sound("drop")
		return
	play_sound("pickup")
	var holder = players.get(carrier, null)
	if holder:
		base_speed[carrier] = base_speed.get(carrier, holder.speed)
		holder.speed = base_speed[carrier] * (CARRY_SLOW - (0.12 if heavy else 0.0))

@rpc("authority", "call_local", "reliable")
func parcel_at_rpc(position: Vector3, fresh: bool):
	parcel_pos = position
	if fresh:
		play_sound("horn")
		parcel.position = position + Vector3(0.0, 6.0, 0.0)
		parcel.create_tween().tween_property(parcel, "position", position, 0.4).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	else:
		parcel.position = position

func visual_tick(delta: float):
	# a shove knocks the parcel loose; only the carrier's own peer sees its `shoved` flag reset reliably
	for player in local_runners():
		if player.player_presence.network_id == carrier and player.shoved and not drop_requested:
			drop_requested = true
			request_drop_rpc.rpc_id(1, carrier)
	if carrier != -1 and players.has(carrier) and is_instance_valid(players[carrier]):
		parcel.position = players[carrier].global_position + Vector3(0.0, 2.05, 0.0)
		parcel.rotation.y += delta * 2.0

func compute_scores() -> Dictionary[int, int]:
	return rank_scores(points)

func check_game_end_on_death():
	if game_end:
		return
	if active_players.is_empty():
		end_game()
