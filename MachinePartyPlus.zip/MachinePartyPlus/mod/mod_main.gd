extends Node

## Machine Party+ runtime hooks: gives the new and revived minigames a briefing card in the intermission screen.

# controls: [text, keyboard/controller icon ids]; ids are InputIconMapping.InputAction (0 action_1, 1 action_2, 2 aim, 6 move)
const BRIEFINGS: Dictionary = {
	"Sweeper": {
		"template": "DiscoDodge",
		"pages": ["> Un bras industriel balaie la plateforme.\n> S'il te touche, tu voles.\n> Pousse les autres dans le vide.\n> Le dernier debout gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Press": {
		"template": "DiscoDodge",
		"pages": ["> Des presses s'abattent sur la grille.\n> Les dalles rouges vont être écrasées.\n> Pousse les autres dessous.\n> Le dernier en vie gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Pressure": {
		"template": "SmokeBreak",
		"pages": ["> Maintiens pour pomper la pression.\n> Relâche pour bloquer ton score.\n> Chaque chaudière explose à un seuil caché.\n> 3 manches. Le plus haut sans exploser gagne."],
		"controls": [["POMPER (MAINTENIR)", [0]]],
	},
	"Crane": {
		"template": "DiscoDodge",
		"pages": ["> Un joueur pilote la grue depuis la cabine.\n> Grue : déplace la pince, appuie pour la lâcher.\n> Les autres : évitez l'ombre rouge.\n> Attrapé = broyé. Le rôle tourne à chaque manche."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["POUSSER / LÂCHER LA PINCE", [0]], ["SAUTER", [1]]],
	},
	"Minority": {
		"template": "DiscoDodge",
		"pages": ["> Monte sur un des trois monte-charges.\n> Le plus rempli tombe dans le silo.\n> Le sol central s'ouvre aussi.\n> Sois dans la minorité. Dernier debout gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Cadence": {
		"template": "ManufactureGun",
		"pages": ["> Des pièces arrivent sur ton tapis.\n> Tamponne-les pile sous la presse.\n> Taper dans le vide bloque ta presse.\n> La chaîne accélère. Meilleur score gagne."],
		"controls": [["TAMPONNER", [0]]],
	},
	"Wall": {
		"template": "DiscoDodge",
		"pages": ["> Des murs avancent sur le plateau.\n> Glisse-toi dans un trou vert.\n> Saute les barres jaunes.\n> Sinon le mur te pousse dans le vide."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Searchlight": {
		"template": "DiscoDodge",
		"pages": ["> Ramasse les fusibles pour marquer.\n> Un projecteur qui te voit te grille.\n> L'ombre d'une caisse te protège.\n> Le plus de fusibles gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Foundry": {
		"template": "DiscoDodge",
		"pages": ["> Le métal en fusion monte.\n> Les piliers s'enfoncent sous ton poids.\n> Saute d'un pilier à l'autre.\n> Toucher le métal = brûlé."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Paint": {
		"template": "DiscoDodge",
		"pages": ["> Tu peins le sol en marchant.\n> Le rouleau efface sa bande rouge.\n> Le seau peint une grande zone.\n> Le plus grand territoire gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Delivery": {
		"template": "DiscoDodge",
		"pages": ["> Ramasse le colis.\n> Porte-le jusqu'à ta trappe.\n> Pousse le porteur pour le voler.\n> Premier à 5 points."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Fans": {
		"template": "DiscoDodge",
		"pages": ["> Les ventilateurs clignotent puis soufflent.\n> Le vent te pousse vers le vide.\n> Cache-toi derrière une cloison.\n> Dernier debout gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Slope": {
		"template": "DiscoDodge",
		"pages": ["> Tu glisses toujours vers le bas.\n> Ramasse les boulons.\n> Évite les boules d'acier.\n> Le plus de boulons gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Maze": {
		"template": "DiscoDodge",
		"pages": ["> Les cloisons montent et descendent.\n> Sors par la porte verte.\n> Premier dehors : 3 points.\n> Quatre manches."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Pendulum": {
		"template": "DiscoDodge",
		"pages": ["> Touche le bouton d'en face.\n> Puis reviens toucher l'autre.\n> Les boulets te jettent en bas.\n> Le plus d'allers-retours gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Pistons": {
		"template": "DiscoDodge",
		"pages": ["> Les vérins brillent puis s'éjectent.\n> Si tu es dessus, tu voles.\n> Saute juste avant pour l'esquiver.\n> Dernier debout gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Workshop": {
		"template": "DiscoDodge",
		"pages": ["> L'arene construite par l'hote dans l'Atelier.\n> Presses, bras, verins et ventilos.\n> Saute par-dessus les bras.\n> Dernier debout gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Finale": {
		"template": "DiscoDodge",
		"pages": ["> Dernière épreuve : les points comptent double.\n> Saute par-dessus les bras qui tournent.\n> Fuis les cercles rouges : une presse tombe.\n> Le bord s'effondre. Dernier debout gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"Balance": {
		"template": "DiscoDodge",
		"pages": ["> Le plateau penche du côté le plus lourd.\n> En pente, tout le monde glisse.\n> Évite les lests qui tombent et glissent.\n> Fais basculer les autres. Dernier debout gagne."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PUSH", [0]], ["SAUTER", [1]]],
	},
	"ShapeCutter": {
		"template": "DuckHunt",
		"pages": ["> Chacun son tour au poste de découpe.\n> Découpe la forme montrée sur l'écran.\n> Clic droit pour valider (25 s max).\n> La découpe la plus précise gagne."],
		"controls": [["VISER", [2]], ["DÉCOUPER (MAINTENIR)", [0]], ["VALIDER", [1]]],
	},
	"ScavangerChairs": {
		"template": "ManufactureGun",
		"pages": ["> Trouve l'objet affiché sur l'écran.\n> Reviens au centre avant la fin du chrono.\n> Le sol s'ouvre autour du centre.\n> Mauvais objet = éliminé."],
		"controls": [["LOC_CONTROL_MOVE", [6]], ["LOC_CONTROL_PICKUP_ITEMS", [0]], ["LÂCHER / POUSSER", [1]]],
	},
	"MemorizePath": {
		"template": "EscalatorPit",
		"pages": ["> Mémorise les portes vertes.\n> Les rouges te font exploser (2 vies).\n> Atteins la plateforme avant le chrono.\n> Le chemin s'allonge à chaque tour."],
		"controls": [["LOC_CONTROL_MOVE", [6]]],
	},
}

const GHOSTS = preload("user://mods/machine_party_unlocked/ghosts.gd")

const LOG_PATH = "user://mods/machine_party_unlocked/mod.log"

var log_file: FileAccess

func _ready() -> void :
	log_file = FileAccess.open(LOG_PATH, FileAccess.WRITE)
	OS.add_logger(load("user://mods/machine_party_unlocked/error_logger.gd").new(log_file))
	mod_log("loaded, version " + Globals.game_version)
	get_tree().node_added.connect(_on_node_added)

	var keybinds: Node = load("user://mods/machine_party_unlocked/keybinds.gd").new()
	keybinds.name = "Keybinds"
	add_child(keybinds)

	# party layer: same path on every peer (/root/MachinePartyMod/Party) so it can RPC
	var party: Node = load("user://mods/machine_party_unlocked/party.gd").new()
	party.name = "Party"
	add_child(party)

	# L'Atelier's online store: same path on every peer
	var store: Node = load("user://mods/machine_party_unlocked/atelier/store.gd").new()
	store.name = "Store"
	add_child(store)

	var updater: Node = load("user://mods/machine_party_unlocked/updater.gd").new()
	updater.name = "Updater"
	add_child(updater)

	var cosmetics: Node = load("user://mods/machine_party_unlocked/cosmetics.gd").new()
	cosmetics.name = "Cosmetics"
	add_child(cosmetics)

	for key in BRIEFINGS.keys():
		var scene = load(Globals.MinigamePaths[Globals.MinigameIdentifier[key]])
		mod_log(key + " scene " + ("OK" if scene is PackedScene and scene.can_instantiate() else "FAILED"))

	# the F1 debug menu ships a "reset achievements" button that wipes Steam stats: hide it
	if DebugTools.reset_achievements_button:
		DebugTools.reset_achievements_button.visible = false
		DebugTools.reset_achievements_button.disabled = true

	# dev only: -mpplus-preview=<Minigame> opens that arena without players, for art screenshots
	for arg in OS.get_cmdline_args():
		if arg.begins_with("-mpplus-preview="):
			start_preview(arg.get_slice("=", 1))
		elif arg.begins_with("-mpplus-test="):
			start_test(arg.get_slice("=", 1))

	# the patched scripts must be the ones the scenes resolve to
	var patched = FileAccess.get_file_as_string("user://mods/machine_party_unlocked/patches/list.txt")
	for res_path in patched.split("\n", false):
		var script: GDScript = load(res_path)
		var uses_patch: bool = script != null and not script.source_code.is_empty()
		mod_log(("patched " if uses_patch else "ORIGINAL ") + res_path)

func mod_log(message: String):
	print("[Machine Party+] ", message)
	if log_file:
		log_file.store_line(Time.get_time_string_from_system() + " " + message)
		log_file.flush()

## dev only: -debug-tools -mpplus-test=<Minigame> hosts a private game alone and opens that minigame through the
## game's own debug picker, so it can be played for real with the keyboard.
func start_test(key: String):

	await get_tree().create_timer(4.0).timeout
	GameManager.host_game = true
	GameManager.custom_game = true
	GameManager.arcade_game = false
	get_tree().change_scene_to_file("res://scenes/lobby/lobby_scene.tscn")

	# nobody may see or join the test lobby
	var backend = null
	for i in 60:
		await get_tree().create_timer(0.5).timeout
		backend = NetworkManager.active_backend
		if backend and "lobby_id" in backend and backend.lobby_id > 0:
			break
	if backend and "lobby_id" in backend and backend.lobby_id > 0:
		Steam.setLobbyJoinable(backend.lobby_id, false)
		Steam.setLobbyType(backend.lobby_id, 0)
		mod_log("test lobby %d made private" % backend.lobby_id)

	await get_tree().create_timer(2.0).timeout
	var lobby = get_tree().current_scene
	if lobby and lobby.has_method("start_game_rpc"):
		lobby.start_game_rpc.rpc()
	else:
		mod_log("test: lobby scene not found")
		return

	for i in 60:
		await get_tree().create_timer(0.5).timeout
		if DebugTools.game_instance:
			break
	await get_tree().create_timer(4.0).timeout
	mod_log("test: loading " + key)
	DebugTools.minigame_button_pressed(Globals.MinigameIdentifier[key])

## "Atelier" in the main menu, right under "Personnalisation": opens the arena editor.
func add_workshop_button(menu: Node):
	await menu.ready
	var template: Button = menu.customization_button
	var button: Button = template.duplicate(Node.DUPLICATE_GROUPS | Node.DUPLICATE_SCRIPTS)
	button.name = "MPPlusWorkshop"
	button.text = "Atelier"
	template.add_sibling(button)
	button.pressed.connect(func(): get_tree().change_scene_to_file("user://mods/machine_party_unlocked/atelier/editor.tscn"))
	var store_button: Button = template.duplicate(Node.DUPLICATE_GROUPS | Node.DUPLICATE_SCRIPTS)
	store_button.name = "MPPlusStore"
	store_button.text = "Store"
	button.add_sibling(store_button)
	store_button.pressed.connect(func(): get_tree().change_scene_to_file("user://mods/machine_party_unlocked/atelier/store_browser.tscn"))
	follow_template(button, template)
	follow_template(store_button, template)

## The menus fade their own buttons in and out (the copies were made while they were transparent): a copied
## button keeps the look of the button it was copied from for as long as both exist.
func follow_template(copy: Control, template: Control):
	while is_instance_valid(copy) and is_instance_valid(template):
		copy.modulate = template.modulate
		copy.self_modulate = template.self_modulate
		copy.visible = template.visible
		await get_tree().process_frame

func start_preview(key: String):

	await get_tree().create_timer(5.0).timeout
	Engine.set_meta("mpplus_preview", true)
	get_tree().change_scene_to_file(Globals.MinigamePaths[Globals.MinigameIdentifier[key]])
	await get_tree().create_timer(1.0).timeout

	var scene = get_tree().current_scene
	if scene is Minigame:
		scene.minigame_overlay.visible = false

	var player_scene: PackedScene = load("res://minigames/disco_dodge/components/player/disco_dodge_player.tscn")
	for i in 3:
		var dummy: Node3D = player_scene.instantiate()
		scene.add_child(dummy)
		dummy.global_position = Vector3(-4.5 + i * 4.5, 0.05, 1.5 + (i % 2) * 3.0)
	var cam: Camera3D = get_viewport().get_camera_3d()
	mod_log("preview camera " + (str(cam.get_path()) + " at " + str(cam.global_position) + " looking " + str(-cam.global_basis.z) if cam else "none"))
	mod_log("preview " + key)

func _on_node_added(node: Node):
	# a patched script that the game had already loaded keeps running the original: report it
	var script = node.get_script()
	if script is GDScript and script.resource_path == "" and script.source_code == "":
		mod_log("STALE (unpatched) script on " + str(node.get_path()))
	if node is IntermissionManager:
		add_briefings(node)
	elif node is MainMenu:
		$Keybinds.hook_main_menu(node)
		add_workshop_button(node)
	elif node is Minigame:
		mod_log("minigame started: " + node.name)
		if node.scene_file_path.begins_with("user://mods/"):
			var ghosts: Node = GHOSTS.new()
			ghosts.name = "MPPlusGhosts"
			node.add_child.call_deferred(ghosts)

func add_briefings(manager: IntermissionManager):

	for key in BRIEFINGS.keys():

		var identifier: int = Globals.MinigameIdentifier[key]
		var template_identifier: int = Globals.MinigameIdentifier[BRIEFINGS[key]["template"]]

		var template: Intermission_IconResource = null
		var exists: bool = false
		for icon_resource in manager.minigame_icon_resource_array:
			if icon_resource.identifier == identifier:
				exists = true
			if icon_resource.identifier == template_identifier:
				template = icon_resource

		if exists or template == null:
			continue

		var briefing: Intermission_IconResource = template.duplicate()
		briefing.identifier = identifier
		var icon = load(Globals.MinigameIconPaths.get(identifier, ""))
		if icon is Texture2D:
			briefing.icon_texture = icon

		var pages: Array[String] = []
		pages.assign(BRIEFINGS[key]["pages"])
		briefing.brief_instructions_content_pages = pages

		var controls: Array[IntermissionControlInputLabelData] = []
		for control in BRIEFINGS[key]["controls"]:
			var data := IntermissionControlInputLabelData.new()
			data.control_text = control[0]
			data.keyboard_icons.assign(control[1])
			data.controller_icons.assign(control[1])
			controls.append(data)
		briefing.controls_data = controls

		manager.minigame_icon_resource_array.append(briefing)
		mod_log("briefing added for " + key)
