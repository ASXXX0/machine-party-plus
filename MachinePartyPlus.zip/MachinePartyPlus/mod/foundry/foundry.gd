extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## FONDERIE: steel pillars of different heights stand in a pool of molten metal that keeps rising. A pillar
## sinks while someone stands on it and slowly comes back up when it is free, so nobody can camp: jump from
## pillar to pillar (the gaps need a jump) and shove the others into the metal. Last one standing wins.
##
## The host owns the pillar heights and the metal level and syncs them; each peer checks its own runners
## against the metal.

const GRID: int = 5
const SPACING: float = 2.7
const PILLAR_RADIUS: float = 1.05
const SINK_SPEED: float = 0.35
const RISE_SPEED: float = 0.2

var pillars: Array[AnimatableBody3D] = []
var base_heights: Array[float] = []
var heights: Array[float] = []
var metal: MeshInstance3D
var metal_light: OmniLight3D
var metal_y: float = -2.5
var sync_timer: float = 0.0

func spawn_points() -> Array[Vector3]:
	var points_out: Array[Vector3] = []
	for index in [6, 8, 16, 18, 12]:
		points_out.append(pillar_center(index) + Vector3(0.0, base_heights[index] + 0.2 if base_heights.size() > index else 2.0, 0.0))
	return points_out

func fall_height() -> float:
	return -12.0

func pillar_center(index: int) -> Vector3:
	var offset: float = (GRID - 1) * SPACING * 0.5
	return Vector3((index % GRID) * SPACING - offset, 0.0, (index / GRID) * SPACING - offset)

func build_arena():

	max_duration = 110.0
	set_camera(Vector3(0.0, 12.5, 11.0), Vector3(0.0, 0.2, 0.3))

	add_sound("ambience", "res://audio/ambience/industrial-machine-cycle_loop.ogg", -8.0, true)
	add_sound("burn", "res://audio/unique/disco dodge/dd fall scream.ogg", -2.0)
	add_sound("hiss", "res://audio/sfx/bad_explosion.ogg", -10.0)

	add_backdrop_model("res://minigames/burn_recycle/models/burn recycle visuals3/burn recycle visuals3.glb", Vector3(0.0, -4.0, -24.0))

	# heights are drawn from a fixed seed so every peer builds the same field
	var rng := RandomNumberGenerator.new()
	rng.seed = 7341
	var pillar_material: StandardMaterial3D = DA.base_material(DA.TEX_STEEL, Color(0.75, 0.72, 0.7), 0.6)
	var cap_material: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_MARKED, Color(1.0, 0.95, 0.9), 0.8)
	for index in GRID * GRID:
		var height: float = snappedf(rng.randf_range(0.6, 1.4), 0.2)
		base_heights.append(height)
		heights.append(height)

		var body := AnimatableBody3D.new()
		body.sync_to_physics = true
		body.position = pillar_center(index) + Vector3(0.0, height, 0.0)
		arena.add_child(body)
		var shape := CollisionShape3D.new()
		var cylinder := CylinderShape3D.new()
		cylinder.radius = PILLAR_RADIUS
		cylinder.height = 12.0
		shape.shape = cylinder
		shape.position.y = -6.0
		body.add_child(shape)
		var column := MeshInstance3D.new()
		var column_mesh := CylinderMesh.new()
		column_mesh.top_radius = PILLAR_RADIUS
		column_mesh.bottom_radius = PILLAR_RADIUS * 1.08
		column_mesh.height = 12.0
		column_mesh.radial_segments = 16
		column.mesh = column_mesh
		column.material_override = pillar_material
		column.position.y = -6.0
		body.add_child(column)
		var cap := MeshInstance3D.new()
		var cap_mesh := CylinderMesh.new()
		cap_mesh.top_radius = PILLAR_RADIUS + 0.04
		cap_mesh.bottom_radius = PILLAR_RADIUS + 0.04
		cap_mesh.height = 0.12
		cap_mesh.radial_segments = 16
		cap.mesh = cap_mesh
		cap.material_override = cap_material
		cap.position.y = -0.05
		body.add_child(cap)
		var rim := MeshInstance3D.new()
		var rim_mesh := TorusMesh.new()
		rim_mesh.inner_radius = PILLAR_RADIUS - 0.06
		rim_mesh.outer_radius = PILLAR_RADIUS + 0.06
		rim.mesh = rim_mesh
		rim.material_override = DA.kind_material("mp_hazard")
		rim.scale = Vector3(1.0, 0.6, 1.0)
		body.add_child(rim)
		pillars.append(body)

	metal = MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(44.0, 44.0)
	metal.mesh = plane
	var molten := StandardMaterial3D.new()
	molten.albedo_color = Color(0.22, 0.05, 0.01)
	molten.emission_enabled = true
	molten.emission = Color(0.9, 0.28, 0.02)
	molten.emission_energy_multiplier = 0.6
	molten.albedo_texture = DA.texture(DA.TEX_RUST)
	molten.emission_texture = DA.texture(DA.TEX_RUST)
	molten.uv1_scale = Vector3(8.0, 8.0, 1.0)
	molten.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
	metal.material_override = molten
	arena.add_child(metal)
	metal_light = add_light(Vector3(0.0, -1.0, 0.0), Color(1.0, 0.45, 0.1), 30.0, 30.0)

	add_key_lights(Vector3(0.0, 13.0, 3.0), 55.0, 14.0)
	set_metal(metal_y)

func set_metal(y: float):
	metal_y = y
	metal.position.y = y
	metal_light.position.y = y + 1.5

func on_play_start_local():
	fade_in_ambience()

func server_tick(delta: float):

	set_metal(min(-2.5 + play_time * 0.035, 1.9))

	var occupied: Array[bool] = []
	occupied.resize(pillars.size())
	occupied.fill(false)
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		var index: int = pillar_under(player.global_position)
		if index >= 0 and player.global_position.y > heights[index] - 0.3:
			occupied[index] = true

	for index in pillars.size():
		var floor_y: float = metal_y - 1.0
		if occupied[index]:
			heights[index] = max(heights[index] - SINK_SPEED * delta, floor_y)
		else:
			heights[index] = min(heights[index] + RISE_SPEED * delta, max(base_heights[index], metal_y + 0.6))

	sync_timer -= delta
	if sync_timer <= 0.0:
		sync_timer = 0.05
		field_rpc.rpc(heights, metal_y)

func pillar_under(position: Vector3) -> int:
	var offset: float = (GRID - 1) * SPACING * 0.5
	var col: int = roundi((position.x + offset) / SPACING)
	var row: int = roundi((position.z + offset) / SPACING)
	if col < 0 or col >= GRID or row < 0 or row >= GRID:
		return -1
	var index: int = row * GRID + col
	if Vector2(position.x - pillar_center(index).x, position.z - pillar_center(index).z).length() > PILLAR_RADIUS + 0.2:
		return -1
	return index

@rpc("authority", "call_remote", "unreliable_ordered")
func field_rpc(_heights: Array, _metal_y: float):
	for index in _heights.size():
		heights[index] = _heights[index]
	set_metal(_metal_y)

func _physics_process(_delta: float) -> void :
	if replaying:
		return
	for index in pillars.size():
		pillars[index].position.y = heights[index]

func visual_tick(delta: float):
	(metal.material_override as StandardMaterial3D).uv1_offset.x += delta * 0.02
	if not running:
		return
	# touching the metal burns: each peer reports its own runners
	for player in local_runners():
		if player.global_position.y < metal_y + 0.05 and not player.has_meta("burnt"):
			player.set_meta("burnt", true)
			sfx_rpc.rpc("burn")
			request_crush_rpc.rpc_id(1, player.player_presence.network_id)
