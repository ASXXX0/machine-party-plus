extends Node

## Machine Party+ updates: on the main menu, fetch the published manifest (latest.json, its URL is in
## update_url.txt) and, when it names a newer mod version, offer to install it. Accepting starts
## tools/update.ps1 (download, SHA-256 check, the package's own install.ps1, relaunch through Steam) and quits.

const MOD_DIR = "user://mods/machine_party_unlocked/"

var manifest: Dictionary = {}
var checked: bool = false
var layer: CanvasLayer

func _ready() -> void :
	get_tree().node_added.connect(_on_node_added)

func _on_node_added(node: Node):
	if node is MainMenu and not checked:
		checked = true
		check.call_deferred()

func current_version() -> String:
	# Globals.game_version is "<mod version>-<game version>", e.g. mpplus-10-v2.1.2
	var parts: PackedStringArray = Globals.game_version.split("-")
	return parts[0] + "-" + parts[1] if parts.size() >= 2 else Globals.game_version

func version_number(version: String) -> int:
	return int(version.get_slice("-", 1))

func check():
	var url: String = FileAccess.get_file_as_string(MOD_DIR + "update_url.txt").strip_edges()
	if url == "":
		return
	var request := HTTPRequest.new()
	request.timeout = 8.0
	add_child(request)
	request.request_completed.connect(_on_manifest.bind(request))
	if request.request(url) != OK:
		request.queue_free()

func _on_manifest(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray, request: HTTPRequest):
	request.queue_free()
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		get_parent().mod_log("update check failed (%d / %d)" % [result, code])
		return
	var data = JSON.parse_string(body.get_string_from_utf8())
	if not data is Dictionary or not data.has("version") or not data.has("zip_url") or not data.has("sha256"):
		return
	manifest = data
	get_parent().mod_log("update check: installed %s, published %s" % [current_version(), manifest.version])
	if version_number(manifest.version) > version_number(current_version()):
		show_offer()

func show_offer():
	layer = CanvasLayer.new()
	layer.layer = 130
	add_child(layer)

	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.03, 0.03, 0.95)
	style.border_color = Color(1.0, 0.55, 0.1)
	style.set_border_width_all(2)
	style.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", style)
	panel.custom_minimum_size = Vector2(400, 0)
	layer.add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	panel.add_child(column)
	var title := Label.new()
	title.text = "MISE A JOUR DISPONIBLE"
	title.add_theme_font_size_override("font_size", 18)
	title.add_theme_color_override("font_color", Color(1.0, 0.6, 0.15))
	column.add_child(title)
	var text := Label.new()
	text.text = "Machine Party+ %s (tu as %s).\nLe jeu va se fermer, s'installer puis se relancer." % [manifest.version, current_version()]
	if manifest.has("notes"):
		text.text += "\n\n" + str(manifest.notes)
	text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text.add_theme_font_size_override("font_size", 12)
	column.add_child(text)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	column.add_child(row)
	var update_button := Button.new()
	update_button.text = "METTRE A JOUR"
	update_button.pressed.connect(start_update)
	row.add_child(update_button)
	var later_button := Button.new()
	later_button.text = "PLUS TARD"
	later_button.pressed.connect(func(): layer.queue_free())
	row.add_child(later_button)

	await get_tree().process_frame
	panel.position = (Vector2(960, 540) - panel.size) * 0.5
	update_button.grab_focus()

func start_update():
	var script_path: String = ProjectSettings.globalize_path(MOD_DIR + "tools/update.ps1")
	var game_dir: String = OS.get_executable_path().get_base_dir()
	var args: PackedStringArray = [
		"-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script_path,
		"-ZipUrl", manifest.zip_url, "-Sha256", manifest.sha256, "-GameDir", game_dir, "-WaitPid", str(OS.get_process_id()),
	]
	var pid: int = OS.create_process("powershell.exe", args, true)
	get_parent().mod_log("update: started updater (pid %d) for %s" % [pid, manifest.version])
	if pid > 0:
		get_tree().quit()
