extends Node

## Machine Party+ keyboard remapping: a "TOUCHES" button in the pause menu opens a panel where each gameplay
## action gets two keys. Keys are physical (they follow the key position, so AZERTY/QWERTY both work) and are
## saved to keybinds.cfg. Only keyboard events are touched; controller and mouse bindings stay as they are.
##
## The game reloads the InputMap from the project settings in several places (MultiplayerInput.reload_defaults),
## so the custom keys are re-applied whenever they go missing.

const SAVE_PATH = "user://mods/machine_party_unlocked/keybinds.cfg"

# action -> label; the order is the panel order
const ACTIONS: Array = [
	["up", "HAUT"],
	["down", "BAS"],
	["left", "GAUCHE"],
	["right", "DROITE"],
	["action_1", "ACTION 1 (POUSSER)"],
	["action_2", "ACTION 2 (SAUTER)"],
	["action_3", "ACTION 3"],
	["action_4", "ACTION 4"],
	["intermission_ready_toggle", "PRET (ENTRACTE)"],
	["toggle_voip", "CHAT VOCAL"],
]
# a key moved onto one of these is taken off the others, so two moves never share a key
const EXCLUSIVE: Array[String] = ["up", "down", "left", "right", "action_1", "action_2", "action_3", "action_4"]

var defaults: Dictionary = {}
var custom: Dictionary = {}
var check_timer: float = 0.0

var layer: CanvasLayer
var panel: Control
var opened_from_pause: bool = false
var main_menu: Node
var key_buttons: Dictionary = {}
var hint_label: Label
var capturing: Array = []
const KEY_NAMES: Dictionary = {
	"Up": "FLECHE HAUT", "Down": "FLECHE BAS", "Left": "FLECHE GAUCHE", "Right": "FLECHE DROITE",
	"Space": "ESPACE", "Shift": "MAJ", "Enter": "ENTREE", "Tab": "TAB", "Comma": "VIRGULE",
	"Semicolon": "POINT-VIRGULE", "Period": "POINT", "Colon": "DEUX-POINTS", "Exclam": "!",
	"Kp Enter": "ENTREE PAVE", "Ctrl": "CTRL", "Alt": "ALT", "Capslock": "VERR MAJ",
}

# the menu under the panel is frozen while the panel is open, so its own keys (Escape, back) don't fire
var frozen_menu: Node
var frozen_mode: Node.ProcessMode

func _ready() -> void :
	for entry in ACTIONS:
		defaults[entry[0]] = project_keys(entry[0])
	load_custom()
	apply_custom()
	build_ui.call_deferred()

func project_keys(action: String) -> Array:
	var keys: Array = [0, 0]
	var setting = ProjectSettings.get_setting("input/" + action)
	if setting == null:
		return keys
	var i: int = 0
	for event in setting.events:
		if event is InputEventKey and i < 2:
			keys[i] = event.physical_keycode if event.physical_keycode != 0 else event.keycode
			i += 1
	return keys

func current_keys(action: String) -> Array:
	return custom.get(action, defaults[action])



func load_custom():
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	for entry in ACTIONS:
		if cfg.has_section_key("keys", entry[0]):
			custom[entry[0]] = cfg.get_value("keys", entry[0])

func save_custom():
	var cfg := ConfigFile.new()
	for action in custom.keys():
		cfg.set_value("keys", action, custom[action])
	cfg.save(SAVE_PATH)

func apply_custom():
	for action in custom.keys():
		if not InputMap.has_action(action):
			continue
		for event in InputMap.action_get_events(action):
			if event is InputEventKey:
				InputMap.action_erase_event(action, event)
		for key in custom[action]:
			if key == 0:
				continue
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)

func custom_applied() -> bool:
	for action in custom.keys():
		if not InputMap.has_action(action):
			continue
		var found: Array = []
		for event in InputMap.action_get_events(action):
			if event is InputEventKey:
				found.append(event.physical_keycode)
		var wanted: Array = custom[action].filter(func(k): return k != 0)
		if found != wanted:
			return false
	return true

func _process(delta: float) -> void :

	check_timer -= delta
	if check_timer <= 0.0:
		check_timer = 0.5
		if not custom.is_empty() and capturing.is_empty() and not custom_applied():
			apply_custom()

	if panel and panel.visible:
		if opened_from_pause and not PauseMenu.active:
			close_panel()
		elif not opened_from_pause and not is_instance_valid(main_menu):
			close_panel()



func build_ui():

	var settings_button: Button = PauseMenu.settings_button
	add_open_button(settings_button, true)

	layer = CanvasLayer.new()
	layer.layer = 120
	add_child(layer)

	panel = Control.new()
	panel.name = "MPPlusKeysPanel"
	panel.visible = false
	panel.position = Vector2.ZERO
	panel.size = Vector2(960, 540)
	layer.add_child(panel)

	var dim := ColorRect.new()
	dim.color = Color(0.0, 0.0, 0.0, 0.88)
	dim.position = Vector2(-10, -7)
	dim.size = Vector2(980, 555)
	panel.add_child(dim)

	var center := CenterContainer.new()
	center.position = Vector2.ZERO
	center.size = Vector2(960, 540)
	panel.add_child(center)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 6)
	center.add_child(column)

	var title := Label.new()
	title.text = "TOUCHES DU CLAVIER"
	title.theme = settings_button.theme
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(title)

	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 2)
	column.add_child(grid)

	for entry in ACTIONS:
		var label := Label.new()
		label.text = entry[1]
		label.theme = settings_button.theme
		label.add_theme_font_size_override("font_size", 14)
		label.custom_minimum_size = Vector2(230, 0)
		grid.add_child(label)
		var buttons: Array = []
		for slot in 2:
			var button: Button = make_button(settings_button, "")
			button.custom_minimum_size = Vector2(130, 0)
			button.pressed.connect(start_capture.bind(entry[0], slot))
			grid.add_child(button)
			buttons.append(button)
		key_buttons[entry[0]] = buttons

	hint_label = Label.new()
	hint_label.theme = settings_button.theme
	hint_label.add_theme_font_size_override("font_size", 12)
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(hint_label)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 20)
	column.add_child(row)
	var reset_button: Button = make_button(settings_button, "PAR DEFAUT")
	reset_button.pressed.connect(reset_all)
	row.add_child(reset_button)
	var back_button: Button = make_button(settings_button, "RETOUR")
	back_button.pressed.connect(close_panel)
	row.add_child(back_button)

	refresh()

## Adds a "TOUCHES" button right after an existing menu button, with the same look and sounds.
func add_open_button(template: Button, from_pause: bool):
	var open_button: Button = template.duplicate(Node.DUPLICATE_GROUPS | Node.DUPLICATE_SCRIPTS)
	open_button.name = "MPPlusKeys"
	open_button.text = "TOUCHES" if from_pause else "Touches"
	template.add_sibling(open_button)
	open_button.pressed.connect(open_panel.bind(from_pause))
	get_parent().follow_template(open_button, template)

## The main menu has its own Options page; it gets the button after "Langue".
func hook_main_menu(menu: Node):
	main_menu = menu
	await menu.ready
	if is_instance_valid(menu) and menu.options_language_button:
		add_open_button(menu.options_language_button, false)

func make_button(template: Button, text: String) -> Button:
	var button := Button.new()
	button.theme = template.theme
	button.text = text
	button.add_theme_font_size_override("font_size", 14)
	return button

func key_name(key: int) -> String:
	if key == 0:
		return "-"
	var label: Key = DisplayServer.keyboard_get_label_from_physical(key)
	var name: String = OS.get_keycode_string(label if label != KEY_NONE else key)
	return KEY_NAMES.get(name, name).to_upper()

func refresh():
	for action in key_buttons.keys():
		var keys: Array = current_keys(action)
		for slot in 2:
			key_buttons[action][slot].text = key_name(keys[slot])
	if capturing.is_empty():
		hint_label.text = "Clique sur une touche pour la changer."
	else:
		key_buttons[capturing[0]][capturing[1]].text = "..."
		hint_label.text = "Appuie sur la nouvelle touche (Echap annule, Retour arriere efface)."

func open_panel(from_pause: bool = true):
	opened_from_pause = from_pause
	if from_pause:
		PauseMenu.main_panel.visible = false
	frozen_menu = PauseMenu if from_pause else main_menu
	if is_instance_valid(frozen_menu):
		frozen_mode = frozen_menu.process_mode
		frozen_menu.process_mode = Node.PROCESS_MODE_DISABLED
	panel.visible = true
	refresh()

func close_panel():
	stop_capture()
	panel.visible = false
	unfreeze_menu(frozen_menu, frozen_mode)
	frozen_menu = null
	if opened_from_pause and PauseMenu.active:
		PauseMenu.main_panel.visible = true

## Waits two frames first: the Escape that closed the panel is still "just pressed" during this frame.
func unfreeze_menu(menu: Node, mode: Node.ProcessMode):
	if not is_instance_valid(menu):
		return
	await get_tree().process_frame
	await get_tree().process_frame
	if is_instance_valid(menu) and menu != frozen_menu:
		menu.process_mode = mode

func start_capture(action: String, slot: int):
	capturing = [action, slot]
	refresh()

func stop_capture():
	if capturing.is_empty():
		return
	capturing = []
	refresh()

func _input(event: InputEvent) -> void :

	if not panel or not panel.visible:
		return
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	get_viewport().set_input_as_handled()
	if capturing.is_empty():
		if event.physical_keycode == KEY_ESCAPE:
			close_panel()
		return

	var key: int = event.physical_keycode
	var action: String = capturing[0]
	var slot: int = capturing[1]
	if key == KEY_ESCAPE:
		stop_capture()
		return
	if key == KEY_BACKSPACE:
		key = 0

	var keys: Array = current_keys(action).duplicate()
	keys[slot] = key
	custom[action] = keys

	if key != 0 and EXCLUSIVE.has(action):
		for other in EXCLUSIVE:
			var other_keys: Array = current_keys(other).duplicate()
			for i in 2:
				if other_keys[i] == key and not (other == action and i == slot):
					other_keys[i] = 0
					custom[other] = other_keys

	save_custom()
	apply_custom()
	stop_capture()

func reset_all():
	stop_capture()
	for action in custom.keys():
		if not InputMap.has_action(action):
			continue
		for event in InputMap.action_get_events(action):
			if event is InputEventKey:
				InputMap.action_erase_event(action, event)
		for key in defaults[action]:
			if key == 0:
				continue
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)
	custom.clear()
	save_custom()
	refresh()
