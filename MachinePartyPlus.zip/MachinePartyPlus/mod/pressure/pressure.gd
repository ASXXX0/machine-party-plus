extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## PRESSION: push your luck. Hold the button to pump your boiler, release to lock the reading. Every boiler
## bursts at its own hidden threshold. Highest locked pressure wins the heat; three heats; everyone watches
## everyone's dial. Players never move: the rules run on the server, owners only send "pumping" on/off.

const HEATS: int = 3
const HEAT_TIME: float = 10.0
const MIN_THRESHOLD: float = 55.0
const MAX_THRESHOLD: float = 100.0
const STATION_SPACING: float = 3.6

enum BoilerState { IDLE, PUMPING, LOCKED, BURST }

var heat: int = 0
var heat_time: float = 0.0
var heat_running: bool = false

# server state, keyed by seat
var pressure: Array[float] = []
var state: Array[int] = []
var threshold: Array[float] = []
var heat_points: Array[int] = []

# visuals, keyed by seat
var boilers: Array[Node3D] = []
var needles: Array[Node3D] = []
var readouts: Array[Label3D] = []
var lamps: Array[OmniLight3D] = []
var shown_pressure: Array[float] = []

var local_pumping: bool = false

func station_x(seat: int, count: int) -> float:
	return (seat - (count - 1) * 0.5) * STATION_SPACING

func seats() -> int:
	return max(players.size(), PlayerManager.player_presences.size(), 1)

func spawn_points() -> Array[Vector3]:
	var count: int = PlayerManager.player_presences.size()
	var points: Array[Vector3] = []
	for seat in max(count, 1):
		points.append(Vector3(station_x(seat, count) + 1.0, 0.05, 0.6))
	return points

func spawn_yaw(_index: int) -> float:
	return deg_to_rad(20.0)

func build_arena():

	max_duration = 120.0

	set_camera(Vector3(0.0, 4.6, 9.5), Vector3(0.0, 2.0, -1.0))

	add_sound("ambience", "res://audio/ambience/industrial-machine-cycle_loop.ogg", -8.0, true)
	add_sound("burst", "res://audio/sfx/bad_explosion.ogg", 0.0)
	add_sound("lock", "res://audio/unique/chisel gauntlet/press_button_submit.ogg", -2.0)
	add_sound("warn", "res://audio/sfx/ekg_beep.ogg", -10.0)
	add_sound("heat", "res://audio/sfx/airplane ding.ogg", -4.0)

	# boiler room: the game's brick walls of The Filter, a tiled floor, warm low light
	var floor_body := StaticBody3D.new()
	arena.add_child(floor_body)
	var floor_shape := CollisionShape3D.new()
	var floor_box := BoxShape3D.new()
	floor_box.size = Vector3(40, 1, 30)
	floor_shape.shape = floor_box
	floor_shape.position = Vector3(0, -0.5, 0)
	floor_body.add_child(floor_shape)

	var floor_mesh := MeshInstance3D.new()
	var floor_plane := PlaneMesh.new()
	floor_plane.size = Vector2(40, 30)
	floor_mesh.mesh = floor_plane
	floor_mesh.material_override = DA.base_material(
		"res://minigames/burn_recycle/models/burn recycle visuals6/burn recycle visuals6_bnr floor tiles.png", Color(0.75, 0.72, 0.68), 0.25)
	arena.add_child(floor_mesh)

	var walls: PackedScene = load("res://minigames/burn_recycle/models/burn recycle visuals6/burn recycle visuals6.glb")
	if walls:
		var room: Node3D = walls.instantiate()
		room.position = Vector3(-5, 0, -11)
		arena.add_child(room)

	var key := OmniLight3D.new()
	key.position = Vector3(0, 7, 3)
	key.light_color = Color(0.62, 0.55, 0.45)
	key.light_energy = 40.0
	key.omni_range = 30.0
	key.shadow_enabled = true
	arena.add_child(key)

	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 6, 14)
	fill.light_color = Color(0.5, 0.52, 0.55)
	fill.light_energy = 10.0
	fill.omni_range = 60.0
	arena.add_child(fill)

	build_stations(max(PlayerManager.player_presences.size(), 4 if Engine.has_meta("mpplus_preview") else 1))

func build_stations(count: int):

	var dial_texture: Texture2D = make_dial_texture()

	for seat in count:
		var x: float = station_x(seat, count)

		var boiler: Node3D = DA.load_model("boiler.glb")
		boiler.position = Vector3(x, 0, -1.2)
		arena.add_child(boiler)
		boilers.append(boiler)

		var dial := MeshInstance3D.new()
		var quad := QuadMesh.new()
		quad.size = Vector2(0.84, 0.84)
		dial.mesh = quad
		var dial_material := StandardMaterial3D.new()
		dial_material.albedo_texture = dial_texture
		dial_material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
		dial_material.emission_enabled = true
		dial_material.emission_texture = dial_texture
		dial_material.emission_energy_multiplier = 0.35
		dial.material_override = dial_material
		dial.position = Vector3(0, 2.1, 0.97)
		boiler.add_child(dial)

		var needle_pivot := Node3D.new()
		needle_pivot.position = Vector3(0, 2.1, 1.0)
		boiler.add_child(needle_pivot)
		var needle := MeshInstance3D.new()
		var needle_mesh := BoxMesh.new()
		needle_mesh.size = Vector3(0.035, 0.34, 0.02)
		needle.mesh = needle_mesh
		var needle_material := StandardMaterial3D.new()
		needle_material.albedo_color = Color(0.7, 0.05, 0.03)
		needle.material_override = needle_material
		needle.position = Vector3(0, 0.14, 0)
		needle_pivot.add_child(needle)
		needle_pivot.rotation.z = deg_to_rad(135.0)
		needles.append(needle_pivot)

		var readout := Label3D.new()
		readout.text = ""
		readout.font_size = 96
		readout.pixel_size = 0.006
		readout.outline_size = 18
		readout.modulate = Color(1.0, 0.85, 0.4)
		readout.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		readout.position = Vector3(0, 4.7, 0)
		boiler.add_child(readout)
		readouts.append(readout)

		var lamp := OmniLight3D.new()
		lamp.position = Vector3(0, 1.0, 1.6)
		lamp.light_color = Color(1.0, 0.45, 0.15)
		lamp.light_energy = 1.5
		lamp.omni_range = 4.0
		boiler.add_child(lamp)
		lamps.append(lamp)

		shown_pressure.append(0.0)

## Off-white dial with ticks every 10 and a yellow-to-red danger arc from the lowest possible threshold.
func make_dial_texture() -> Texture2D:
	var size: int = 128
	var image := Image.create_empty(size, size, false, Image.FORMAT_RGBA8)
	var center := Vector2(size, size) * 0.5
	for y in size:
		for x in size:
			var d: Vector2 = Vector2(x + 0.5, y + 0.5) - center
			var r: float = d.length() / (size * 0.5)
			var color := Color(0, 0, 0, 0)
			if r <= 1.0:
				color = Color(0.86, 0.84, 0.78)
				var angle: float = rad_to_deg(atan2(d.x, - d.y))
				var value: float = (angle + 135.0) / 2.7
				if r > 0.9:
					color = Color(0.08, 0.08, 0.08)
				elif r > 0.62 and r < 0.84 and angle > -135.0 and angle < 135.0 and value >= MIN_THRESHOLD:
					var t: float = (value - MIN_THRESHOLD) / (100.0 - MIN_THRESHOLD)
					color = Color(0.95, 0.75, 0.1).lerp(Color(0.8, 0.05, 0.03), t)
				elif r > 0.74 and r < 0.9 and angle > -136.0 and angle < 136.0:
					var tick: float = fposmod(value, 10.0)
					if tick < 0.6 or tick > 9.4:
						color = Color(0.1, 0.1, 0.1)
				if r < 0.08:
					color = Color(0.1, 0.1, 0.1)
			image.set_pixel(x, y, color)
	return ImageTexture.create_from_image(image)



func on_play_start():
	# players stay put: they pump, they don't walk
	pass

func on_server_play_start():
	var count: int = players.size()
	pressure.resize(count)
	state.resize(count)
	threshold.resize(count)
	heat_points.resize(count)
	heat_points.fill(0)
	start_heat()

func start_heat():
	heat += 1
	heat_time = 0.0
	pressure.fill(0.0)
	state.fill(BoilerState.IDLE)
	for seat in threshold.size():
		threshold[seat] = randf_range(MIN_THRESHOLD, MAX_THRESHOLD)
	heat_start_rpc.rpc(heat)
	await get_tree().create_timer(1.2, false).timeout
	heat_running = true

func server_tick(delta: float):

	if not heat_running:
		return

	heat_time += delta
	var all_done: bool = true

	for seat in pressure.size():
		if state[seat] == BoilerState.PUMPING:
			pressure[seat] += (14.0 + pressure[seat] * 0.32) * delta
			if pressure[seat] >= threshold[seat]:
				pressure[seat] = threshold[seat]
				state[seat] = BoilerState.BURST
				burst_rpc.rpc(seat)
				shake_rpc.rpc(0.8)
		if state[seat] == BoilerState.IDLE or state[seat] == BoilerState.PUMPING:
			all_done = false

	sync_rpc.rpc(pressure, state)

	if heat_time >= HEAT_TIME or all_done:
		end_heat()

func end_heat():

	heat_running = false

	for seat in state.size():
		if state[seat] == BoilerState.PUMPING or (state[seat] == BoilerState.IDLE and pressure[seat] > 0.0):
			state[seat] = BoilerState.LOCKED
			lock_rpc.rpc(seat, pressure[seat])

	# points: one per boiler beaten, +1 for the heat winner; bursts score nothing
	var standing: Array = []
	for seat in state.size():
		if state[seat] == BoilerState.LOCKED:
			standing.append(seat)
	standing.sort_custom( func(a, b): return pressure[a] > pressure[b])
	for i in standing.size():
		heat_points[standing[i]] += standing.size() - i + (1 if i == 0 else 0)

	sync_rpc.rpc(pressure, state)
	heat_end_rpc.rpc(standing.slice(0, 1))

	await get_tree().create_timer(3.5, false).timeout

	if game_end:
		return
	if heat < HEATS:
		start_heat()
	else:
		end_game()

func compute_scores() -> Dictionary[int, int]:
	var ids: Array = players.keys()
	var order: Array = range(ids.size())
	order.sort_custom( func(a, b): return heat_points[a] > heat_points[b])
	var scores: Dictionary[int, int]
	for rank in order.size():
		var seat: int = order[rank]
		scores[ids[seat]] = player_count if rank == 0 else max(player_count - 1 - rank, 0)
	return scores

func visual_tick(delta: float):

	# owner input: send pumping on/off to the server
	if running and heat_running_visual:
		var seat: int = seat_of(multiplayer.get_unique_id())
		if seat >= 0 and not PauseMenu.active:
			var pumping: bool = Input.is_action_pressed("action_1")
			if pumping != local_pumping:
				local_pumping = pumping
				if multiplayer.is_server():
					set_pumping(seat, pumping)
				else:
					set_pumping_rpc.rpc_id(1, pumping)

	for seat in needles.size():
		var target: float = shown_target[seat] if seat < shown_target.size() else 0.0
		shown_pressure[seat] = lerp(shown_pressure[seat], target, min(delta * 12.0, 1.0))
		var wobble: float = sin(Time.get_ticks_msec() * 0.03 + seat) * shown_pressure[seat] * 0.012
		needles[seat].rotation.z = deg_to_rad(135.0 - 2.7 * (shown_pressure[seat] + wobble))
		if seat < shown_state.size() and shown_state[seat] == BoilerState.PUMPING:
			lamps[seat].light_energy = 1.5 + shown_pressure[seat] * 0.06
			boilers[seat].scale = Vector3.ONE * (1.0 + shown_pressure[seat] * 0.0006 * (1.0 + sin(Time.get_ticks_msec() * 0.05)))

var heat_running_visual: bool = false
var shown_target: Array[float] = []
var shown_state: Array[int] = []

func set_pumping(seat: int, pumping: bool):
	if not heat_running or seat < 0 or seat >= state.size():
		return
	if pumping and state[seat] == BoilerState.IDLE:
		state[seat] = BoilerState.PUMPING
	elif not pumping and state[seat] == BoilerState.PUMPING:
		state[seat] = BoilerState.LOCKED
		lock_rpc.rpc(seat, pressure[seat])



@rpc("any_peer", "call_remote", "reliable")
func set_pumping_rpc(pumping: bool):
	if not multiplayer.is_server():
		return
	set_pumping(seat_of(multiplayer.get_remote_sender_id()), pumping)

@rpc("authority", "call_local", "unreliable_ordered")
func sync_rpc(_pressure: Array, _state: Array):
	shown_target.assign(_pressure)
	shown_state.assign(_state)

@rpc("authority", "call_local", "reliable")
func heat_start_rpc(_heat: int):
	heat_running_visual = true
	local_pumping = false
	shown_target.clear()
	shown_state.clear()
	for seat in boilers.size():
		boilers[seat].scale = Vector3.ONE
		boilers[seat].visible = true
		readouts[seat].text = ""
		lamps[seat].light_energy = 1.5
	for player in players.values():
		if "animation_tree" in player and player.animation_tree:
			player.animation_tree.set("parameters/falling_blend/blend_amount", 0.0)
			player.falling_started = false
			player.visuals.position = Vector3.ZERO
	set_countdown_mesage_rpc("MANCHE %d/%d" % [_heat, HEATS], 0.9)
	play_sound("heat")

@rpc("authority", "call_local", "reliable")
func heat_end_rpc(winner_seats: Array):
	heat_running_visual = false
	for seat in winner_seats:
		if seat < readouts.size():
			readouts[seat].modulate = Color(0.5, 1.0, 0.4)
			readouts[seat].text = "★ " + readouts[seat].text

@rpc("authority", "call_local", "reliable")
func lock_rpc(seat: int, value: float):
	if seat >= readouts.size():
		return
	readouts[seat].modulate = Color(1.0, 0.85, 0.4)
	readouts[seat].text = "%d" % int(value)
	lamps[seat].light_energy = 1.5
	boilers[seat].scale = Vector3.ONE
	play_sound("lock")

@rpc("authority", "call_local", "reliable")
func burst_rpc(seat: int):
	if seat >= boilers.size():
		return
	play_sound("burst", 0.1)
	readouts[seat].modulate = Color(1.0, 0.25, 0.15)
	readouts[seat].text = "BOUM"
	lamps[seat].light_energy = 12.0
	var t := create_tween()
	t.tween_property(boilers[seat], "scale", Vector3(1.25, 0.85, 1.25), 0.08)
	t.tween_property(boilers[seat], "scale", Vector3(1.0, 1.0, 1.0), 0.3)
	t.tween_property(lamps[seat], "light_energy", 0.2, 0.6)

	var network_id: int = players.keys()[seat] if seat < players.size() else -1
	var player = players.get(network_id, null)
	if player and "visuals" in player:
		player.start_falling()
		var knock := create_tween()
		knock.tween_property(player.visuals, "position", Vector3(0.0, -0.4, 1.4), 0.35).set_ease(Tween.EASE_OUT)

	if multiplayer.is_server():
		EffectManager.spawn_rpc.rpc(&"mine_explosion", boilers[seat].global_position + Vector3(0, 2.0, 0.8))
		EffectManager.spawn_rpc.rpc(&"dustplume", boilers[seat].global_position + Vector3(0, 3.5, 0))

@rpc("authority", "call_local", "reliable")
func shake_rpc(amount: float):
	shake = min(shake + amount, 1.2)
