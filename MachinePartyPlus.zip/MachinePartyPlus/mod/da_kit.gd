extends RefCounted

## Machine Party+ art kit: dresses the mod's minigames in the game's own look.
## Materials come from the game's textures (loaded from the player's install, never shipped), filtered nearest
## like the original props; models are the mod's Blender glbs; post-processing reuses the game's vignette and
## posterization shaders with the values its minigames use.

const MOD_DIR = "user://mods/machine_party_unlocked/"

const TEX_METAL = "res://minigames/burn_recycle/models/burn recycle visuals6/burn recycle visuals6_metal sheet 1024.png"
const TEX_STEEL = "res://minigames/chisel_gauntlet_multiplayer/models/chisel gauntlet art2/chisel gauntlet art2_metal rough steel.png"
const TEX_RUST = "res://minigames/exploding_collar_race/models/collar race level mesh3/collar race level mesh3_TexturesCom_Rust_Pitted_512_albedo.png"
const TEX_PIPE = "res://minigames/burn_recycle/models/burn recycle visuals6/burn recycle visuals6_pipe3.png"
const TEX_FLOOR_HAZARD = "res://minigames/dvd_roomba/models/dvd roomba visuals1_dvd roomba floor5.png"
const TEX_FLOOR_MARKED = "res://minigames/chisel_gauntlet_multiplayer/models/chisel gauntlet art2/chisel gauntlet art2_chisel gauntlet floor6.png"
const TEX_CONCRETE = "res://models/disco dodge environment1/disco dodge environment1_concrete bake7.png"

const SHADER_VIGNETTE = "res://shaders/vignette.gdshader"
const SHADER_POSTERIZE = "res://shaders/posterization.gdshader"

const BACKDROP_SCENE = "res://minigames/junk_platform/models/junk platform visuals2/junk platform visuals2.glb"

static var cache: Dictionary = {}

static func texture(path: String) -> Texture2D:
	if not cache.has(path):
		cache[path] = load(path)
	return cache[path]

static func base_material(albedo_path: String, tint: Color = Color.WHITE, triplanar_scale: float = 0.5) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = texture(albedo_path)
	m.albedo_color = tint
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
	m.uv1_triplanar = true
	m.uv1_scale = Vector3.ONE * triplanar_scale
	m.roughness = 0.85
	m.metallic = 0.25
	return m

static func hazard_texture() -> Texture2D:
	if cache.has("hazard"):
		return cache["hazard"]
	var size: int = 64
	var image := Image.create_empty(size, size, false, Image.FORMAT_RGB8)
	var yellow := Color(0.86, 0.66, 0.08)
	var black := Color(0.07, 0.065, 0.06)
	for y in size:
		for x in size:
			image.set_pixel(x, y, yellow if ((x + y) / 16) % 2 == 0 else black)
	var tex := ImageTexture.create_from_image(image)
	cache["hazard"] = tex
	return tex

## Materials for the mp_<kind> slots of the Blender models.
static func kind_material(kind: String) -> Material:
	var key = "kind_" + kind
	if cache.has(key):
		return cache[key]

	var m: StandardMaterial3D
	match kind:
		"mp_metal":
			m = base_material(TEX_METAL, Color(0.95, 0.93, 0.88), 0.45)
		"mp_dark":
			m = base_material(TEX_STEEL, Color(0.38, 0.37, 0.36), 0.6)
		"mp_rod":
			m = base_material(TEX_PIPE, Color(1.05, 1.05, 1.0), 0.35)
			m.metallic = 0.6
			m.roughness = 0.45
		"mp_hazard":
			m = StandardMaterial3D.new()
			m.albedo_texture = hazard_texture()
			m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
			m.uv1_triplanar = true
			m.uv1_scale = Vector3.ONE * 0.9
			m.detail_enabled = true
			m.detail_albedo = texture(TEX_METAL)
			m.detail_blend_mode = BaseMaterial3D.BLEND_MODE_MUL
			m.detail_uv_layer = BaseMaterial3D.DETAIL_UV_1
			m.roughness = 0.8
		"mp_rubber":
			m = base_material(TEX_STEEL, Color(0.1, 0.1, 0.1), 0.8)
			m.metallic = 0.0
			m.roughness = 1.0
		"mp_light":
			m = StandardMaterial3D.new()
			m.albedo_color = Color(1.0, 0.3, 0.08)
			m.emission_enabled = true
			m.emission = Color(1.0, 0.25, 0.05)
			m.emission_energy_multiplier = 3.0
		_:
			m = base_material(TEX_METAL)

	cache[key] = m
	return m

## Loads one of the mod's glb models and swaps its placeholder materials for game-textured ones.
static func load_model(filename: String) -> Node3D:
	var document := GLTFDocument.new()
	var state := GLTFState.new()
	var err = document.append_from_file(MOD_DIR + "models/" + filename, state)
	if err != OK:
		push_error("[Machine Party+] cannot load model " + filename)
		return Node3D.new()
	var root: Node3D = document.generate_scene(state)
	dress(root)
	return root

static func dress(node: Node):
	if node is MeshInstance3D:
		var mesh: Mesh = node.mesh
		for i in mesh.get_surface_count():
			var source = mesh.surface_get_material(i)
			var kind: String = source.resource_name if source else ""
			node.set_surface_override_material(i, kind_material(kind))
		node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	for child in node.get_children():
		dress(child)

## The game's minigame look: same environment adjustments as Disco Dodge / Junk Platform.
static func environment() -> Environment:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.05, 0.055, 0.045)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.23, 0.28, 0.37)
	env.ambient_light_energy = 0.35
	env.adjustment_enabled = true
	env.adjustment_brightness = 1.14
	env.adjustment_contrast = 1.1
	env.adjustment_saturation = 0.6
	env.fog_enabled = true
	env.fog_light_color = Color(0.11, 0.12, 0.1)
	env.fog_density = 0.008
	return env

## Vignette + posterization overlays, as in the original minigames.
static func add_post_processing(parent: Node):
	var layer := CanvasLayer.new()
	layer.name = "post processing"
	layer.layer = -1
	parent.add_child(layer)

	var vignette := ShaderMaterial.new()
	vignette.shader = load(SHADER_VIGNETTE)
	vignette.set_shader_parameter("radius", 0.922)
	vignette.set_shader_parameter("softness", 0.38)
	vignette.set_shader_parameter("intensity", 2.0)
	vignette.set_shader_parameter("contrast", 1.572)
	vignette.set_shader_parameter("vignette_color", Color.BLACK)

	var posterize := ShaderMaterial.new()
	posterize.shader = load(SHADER_POSTERIZE)
	posterize.set_shader_parameter("SCREEN_WIDTH", 320.0)
	posterize.set_shader_parameter("RED_COMPONENT", 8.0)
	posterize.set_shader_parameter("GREEN_COMPONENT", 8.0)
	posterize.set_shader_parameter("BLUE_COMPONENT", 8.0)

	for material in [vignette, posterize]:
		var copy := BackBufferCopy.new()
		copy.copy_mode = BackBufferCopy.COPY_MODE_VIEWPORT
		layer.add_child(copy)
		var rect := ColorRect.new()
		rect.material = material
		rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		# BackBufferCopy is not a Control, so anchors do nothing: size it to the game's 960x540 viewport
		rect.position = Vector2(-10, -7)
		rect.size = Vector2(978, 555)
		copy.add_child(rect)

## Rusty towers and pipes of Junk Platform, sinking into the void around the arena.
static func add_backdrop(parent: Node, offset: Vector3, yaw_degrees: float = 0.0) -> Node3D:
	var scene: PackedScene = load(BACKDROP_SCENE)
	if scene == null:
		return null
	var backdrop: Node3D = scene.instantiate()
	backdrop.position = offset
	backdrop.rotation_degrees.y = yaw_degrees
	parent.add_child(backdrop)
	return backdrop
