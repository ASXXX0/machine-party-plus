extends Minigame

## LA BALAYEUSE: an industrial arm sweeps a round platform and flings whoever it touches.
## It speeds up, a second counter-rotating arm joins, the platform shrinks. Last one standing wins.
## Reuses the Disco Dodge player (move, shove with action_1, fall detection on collision layer 5).

const player_scene = preload("res://minigames/disco_dodge/components/player/disco_dodge_player.tscn")
const DA = preload("user://mods/machine_party_unlocked/da_kit.gd")

@export_category("Gameplay")
@export var start_radius: float = 10.0
@export var min_radius: float = 5.0
@export var shrink_start_time: float = 25.0
@export var shrink_rate: float = 0.08
@export var start_arm_speed: float = 0.9
@export var max_arm_speed: float = 3.2
@export var arm_acceleration: float = 0.035
@export var second_arm_time: float = 20.0
@export var arm_half_width: float = 0.75
@export var fling_strength: float = 14.0
@export var hit_cooldown: float = 0.7
@export var max_duration: float = 120.0

@export_category("Signal States")
@export var countdown_state: State

@export_category("Networked Nodes")
@export var players_node: Node3D
@export var player_spawn_positions_node: Node3D

@export_category("Components")
@export var multiplayer_synchronizer: MultiplayerSynchronizer
@export var camera: Camera3D
@export var platform_mesh: MeshInstance3D
@export var platform_ring: MeshInstance3D
@export var platform_collision: CollisionShape3D
@export var arms: Array[Node3D]
@export var arm_meshes: Array[MeshInstance3D]
@export var warning_light: OmniLight3D
@export var world_environment: WorldEnvironment
@export var pillar_mesh: MeshInstance3D

@export_category("Audio")
@export var speaker_ambience: AudioStreamPlayer
@export var speaker_hit: AudioStreamPlayer

var players: Dictionary[int, DiscoDodgePlayer]
var active_players: Dictionary[int, DiscoDodgePlayer]
var dead_players: Array[int]
var player_scores: Dictionary[int, int]
var player_count: int = 0
var finished: bool = false
var game_end: bool = false

var running: bool = false
var play_time: float = 0.0
var arm_angles: Array[float] = [0.0, PI]
var arm_speeds: Array[float] = [0.0, 0.0]
var arm_enabled: Array[bool] = [true, false]
var radius: float = 10.0
var hit_timers: Dictionary[int, float]
var sync_timer: float = 0.0

func _ready() -> void :

	if Engine.has_meta("mpplus_preview"):
		setup_visuals()
		arms[1].visible = true
		arms[1].rotation.y = PI * 0.6
		return

	super._ready()

	setup_visuals()

	if multiplayer.is_server():

		multiplayer_synchronizer.set_multiplayer_authority(multiplayer.get_unique_id())

		countdown_state.countdown_started.connect(_on_countdown_started)
		countdown_state.tick.connect(_on_countdown_tick)
		countdown_state.expired.connect(_on_countdown_expired)

	if GameManager.local_game:

		await get_tree().create_timer(1.0).timeout
		minigame_ready.emit(1)

func setup_visuals():

	camera.current = true
	world_environment.environment = DA.environment()
	DA.add_post_processing(self)
	DA.add_backdrop(self, Vector3(55.0, -8.0, -60.0), 25.0)
	DA.add_backdrop(self, Vector3(-30.0, -10.0, -75.0), -35.0)

	var floor_material: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_MARKED, Color(1.0, 0.97, 0.92), 0.5)
	floor_material.uv1_offset = Vector3.ONE * 0.5
	platform_mesh.material_override = floor_material
	platform_ring.material_override = DA.kind_material("mp_hazard")

	pillar_mesh.visible = false
	pillar_mesh.get_parent().add_child(DA.load_model("sweeper_hub.glb"))

	for i in arms.size():
		arm_meshes[i].visible = false
		arms[i].add_child(DA.load_model("sweeper_arm.glb"))

	radius = start_radius
	apply_radius(radius)
	for i in arms.size():
		arms[i].visible = arm_enabled[i]

func initialize(_round_number: int, _total_rounds: int, _scores: Dictionary = {}):
	super.initialize(_round_number, _total_rounds, _scores)

	spawn_players()

	state_machine.transition_to_rpc.rpc(&"Round", {"round": _round_number, "total": _total_rounds})

func cleanup():

	if is_multiplayer_authority():
		multiplayer_synchronizer.free()
		queue_free()

func fade_in_ambience():
	if speaker_ambience and not speaker_ambience.playing:
		speaker_ambience.play()

func all_players_loaded():
	super.all_players_loaded()

	if not multiplayer.is_server():
		return

	is_all_player_loaded = true
	minigame_ready.emit(multiplayer.get_unique_id())

func spawn_players():

	var player_spawn_positions = player_spawn_positions_node.get_children()
	player_spawn_positions.shuffle()

	player_count = PlayerManager.player_presences.size()

	var counter: int = 0
	for key in PlayerManager.player_presences.keys():

		var player_presence: PlayerPresence = PlayerManager.player_presences[key]

		var player_character = player_scene.instantiate()
		players_node.add_child(player_character, true)

		player_character.set_player_presence.rpc(player_presence.network_id)
		player_character.teleport_rpc.rpc(
			player_spawn_positions[counter % player_spawn_positions.size()].global_position
		)
		players[player_presence.network_id] = player_character
		active_players[player_presence.network_id] = player_character
		player_character.died.connect(_on_player_died)

		player_scores[player_presence.network_id] = 0

		counter += 1

	register_players_rpc.rpc(players.keys())

## Clients only receive spawned nodes; give them the same player tables so each peer can hit its own runner.
@rpc("authority", "call_local", "reliable")
func register_players_rpc(network_ids: Array):
	for network_id in network_ids:
		if players.has(network_id):
			continue
		for child in players_node.get_children():
			if child.player_presence and child.player_presence.network_id == network_id:
				players[network_id] = child
				active_players[network_id] = child



func _physics_process(delta: float) -> void :

	if not running:
		return

	play_time += delta

	if multiplayer.is_server():
		server_update(delta)

	for i in arms.size():
		if not arm_enabled[i]:
			continue
		arm_angles[i] = wrapf(arm_angles[i] + arm_speeds[i] * delta, - PI, PI)
		arms[i].rotation.y = arm_angles[i]

	check_local_hits(delta)

func server_update(delta: float):

	var speed: float = min(start_arm_speed + arm_acceleration * play_time, max_arm_speed)
	arm_speeds[0] = speed

	if play_time >= second_arm_time:
		if not arm_enabled[1]:
			enable_second_arm_rpc.rpc(wrapf(arm_angles[0] + PI, - PI, PI))
		arm_speeds[1] = - speed * 0.8

	if play_time >= shrink_start_time and radius > min_radius:
		radius = max(radius - shrink_rate * delta, min_radius)
		apply_radius(radius)

	sync_timer -= delta
	if sync_timer <= 0.0:
		sync_timer = 0.1
		sync_state_rpc.rpc(arm_angles, arm_speeds, radius)

	if play_time >= max_duration and not game_end:
		end_game()

## Each peer checks only the players it simulates (its own, or all of them in a local game).
func check_local_hits(delta: float):

	for network_id in hit_timers.keys():
		hit_timers[network_id] = max(hit_timers[network_id] - delta, 0.0)

	for network_id in active_players.keys():

		var player: DiscoDodgePlayer = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		if not player.is_physics_processing():
			continue
		if hit_timers.get(network_id, 0.0) > 0.0:
			continue

		var flat := Vector3(player.global_position.x, 0.0, player.global_position.z)
		var dist: float = flat.length()
		if dist > radius + 0.5 or dist < 0.8:
			continue
		# a well-timed jump clears the arm
		if player.global_position.y > 0.55:
			continue

		var player_angle: float = atan2(- flat.z, flat.x)

		for i in arms.size():
			if not arm_enabled[i]:
				continue

			var arm_dir := Vector3(cos(arm_angles[i]), 0.0, - sin(arm_angles[i]))
			var along: float = flat.dot(arm_dir)
			if along < 0.0:
				continue
			var across: float = abs(flat.cross(arm_dir).y)
			if across > arm_half_width:
				continue

			var spin_sign: float = sign(arm_speeds[i])
			var tangent := Vector3(- sin(arm_angles[i]), 0.0, - cos(arm_angles[i])) * spin_sign
			var fling_dir := (tangent + flat.normalized() * 0.6).normalized()
			var strength: float = fling_strength + abs(arm_speeds[i]) * 3.0

			hit_timers[network_id] = hit_cooldown
			player.shoved_rpc.rpc(flat - tangent, player.global_position, fling_dir)
			player.shove_velocity += fling_dir * strength
			flash_rpc.rpc(i)
			break

func apply_radius(_radius: float):
	platform_mesh.scale = Vector3(_radius, 1.0, _radius)
	platform_ring.scale = Vector3(_radius, 1.0, _radius)
	(platform_collision.shape as CylinderShape3D).radius = _radius

func calculate_score():

	if finished:
		return

	finished = true

	for i in dead_players.size():
		player_scores[dead_players[i]] = i

	for network_id in active_players.keys():
		player_scores[network_id] = player_count

	player_scores_finalized.emit(player_scores)

func end_game():

	if game_end:
		return

	game_end = true
	stop_rpc.rpc()

	await get_tree().create_timer(3.0).timeout

	calculate_score()

	await get_tree().create_timer(2.0).timeout
	set_minigame_sfx_linear_volume_rpc.rpc(0.0)
	state_machine.transition_to_rpc.rpc(&"Finish")
	set_effects_visibility_rpc.rpc(false)

func check_game_end_on_death():

	if game_end:
		return

	if active_players.size() > 1:
		return

	if player_count <= 1 and active_players.size() == 1:
		return

	end_game()



@rpc("authority", "call_local", "reliable")
func start_rpc():
	running = true
	play_time = 0.0

@rpc("authority", "call_local", "reliable")
func stop_rpc():
	running = false

@rpc("authority", "call_local", "reliable")
func enable_second_arm_rpc(_angle: float):
	arm_enabled[1] = true
	arm_angles[1] = _angle
	arms[1].visible = true
	flash_rpc(1)

@rpc("authority", "call_remote", "unreliable_ordered")
func sync_state_rpc(_angles: Array, _speeds: Array, _radius: float):
	for i in arms.size():
		arm_angles[i] = lerp_angle(arm_angles[i], _angles[i], 0.5)
		arm_speeds[i] = _speeds[i]
	radius = _radius
	apply_radius(radius)

@rpc("any_peer", "call_local", "unreliable")
func flash_rpc(_arm_index: int):
	if speaker_hit:
		speaker_hit.pitch_scale = randf_range(0.9, 1.15)
		speaker_hit.play()
	if not warning_light:
		return
	warning_light.light_energy = 12.0
	var t = create_tween()
	t.tween_property(warning_light, "light_energy", 1.5, 0.4)

@rpc("any_peer", "call_local", "reliable")
func remove_player_rpc(_network_id: int):

	var player_instance = players.get(_network_id, null)
	if player_instance:
		if multiplayer.is_server():
			players[_network_id].queue_free()
		players.erase(_network_id)
		active_players.erase(_network_id)

func player_disconnected(_network_id: int):
	super.player_disconnected(_network_id)

	if not multiplayer.is_server():
		return

	remove_player_rpc.rpc(_network_id)

	await get_tree().create_timer(1.0).timeout
	check_game_end_on_death()

@rpc("authority", "call_local", "reliable")
func player_died_rpc(_network_id: int):
	active_players.erase(_network_id)
	if not dead_players.has(_network_id):
		dead_players.append(_network_id)

func _on_player_died(_network_id: int):

	if not multiplayer.is_server():
		return

	player_died_rpc.rpc(_network_id)
	check_game_end_on_death()

func _on_countdown_expired():
	super._on_countdown_expired()

	for player in players.values():
		player.set_active_rpc.rpc(true)

	state_machine.transition_to_rpc.rpc(&"Play")
	start_rpc.rpc()
