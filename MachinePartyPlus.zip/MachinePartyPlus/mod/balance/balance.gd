extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LA BALANCE: a 12 x 12 m deck balances on a single column above a quarry. It leans toward wherever the weight
## is: the runners, and the cast-iron ballasts the machine drops on it. Anyone on a slope slides downhill.
## Shove the others to unbalance the deck; last one standing wins. The motor wobbles more and more over time.
##
## The server owns the tilt and the ballasts and syncs them at 20 Hz. Each peer slides the runners it simulates.

const HALF: float = 6.0
const PIVOT_Y: float = -1.7
const BALLAST_WEIGHT: float = 1.6
const BALLAST_HALF: float = 0.65
const MAX_BALLASTS: int = 3

var tilt_gain: float = 0.14
var tilt_rate: float = 0.2
var slide_start: float = 6.0
var slide_max: float = 12.0

var deck: AnimatableBody3D
var deck_lamps: Array[OmniLight3D] = []
var tilt: Vector2 = Vector2.ZERO
var target_tilt: Vector2 = Vector2.ZERO
var synced_tilt: Vector2 = Vector2.ZERO
var sync_timer: float = 0.0

# ballasts, by id: node, deck-local position (x, z), velocity, landed flag
var ballasts: Dictionary[int, Dictionary] = {}
var next_ballast_id: int = 0
var ballast_timer: float = 10.0
var hit_timers: Dictionary[int, float]

func spawn_points() -> Array[Vector3]:
	return [Vector3(-3, 0.2, -3), Vector3(3, 0.2, -3), Vector3(3, 0.2, 3), Vector3(-3, 0.2, 3), Vector3(0, 0.2, 0)]

func fall_height() -> float:
	return -8.0

func build_arena():

	max_duration = 110.0

	set_camera(Vector3(0.0, 12.5, 15.5), Vector3(0.0, -1.2, 0.0))

	add_sound("ambience", "res://audio/ambience/industrial-machine-cycle_loop.ogg", -8.0, true)
	add_sound("warn", "res://audio/sfx/burn_recycle/beep.ogg", -6.0)
	add_sound("drop", "res://audio/sfx/manufacture_gun_drop_gear.ogg", 0.0)
	add_sound("creak", "res://audio/unique/intermission/intermission servo2.ogg", -6.0)
	add_sound("hit", "res://audio/unique/disco dodge/dd fall scream impact.ogg", -4.0)

	# the quarry of Escalator Pit, the deck hanging over its pit
	var quarry_scene: PackedScene = load("res://minigames/escalator_pit/models/escalator pit art11/escalator pit art11.glb")
	if quarry_scene:
		var quarry: Node3D = quarry_scene.instantiate()
		quarry.position = Vector3(0.0, -22.0, -18.0)
		arena.add_child(quarry)
	var rock_scene: PackedScene = load("res://minigames/escalator_pit/models/escalator pit quarry rock1/escalator pit quarry rock1.glb")
	if rock_scene:
		var rock: Node3D = rock_scene.instantiate()
		rock.position = Vector3(0.0, -22.0, -18.0)
		arena.add_child(rock)

	var pivot: Node3D = DA.load_model("balance_pivot.glb")
	pivot.position = Vector3(0.0, 0.0, 0.0)
	arena.add_child(pivot)

	# the deck rotates around the ball joint; its collision and visuals sit 1.7 m above it
	deck = AnimatableBody3D.new()
	deck.name = "Deck"
	deck.sync_to_physics = true
	deck.position = Vector3(0.0, PIVOT_Y, 0.0)
	arena.add_child(deck)

	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(HALF * 2.0, 0.4, HALF * 2.0)
	shape.shape = box
	shape.position = Vector3(0.0, - PIVOT_Y - 0.2, 0.0)
	deck.add_child(shape)

	var top := MeshInstance3D.new()
	var top_mesh := BoxMesh.new()
	top_mesh.size = Vector3(HALF * 2.0 - 0.1, 0.3, HALF * 2.0 - 0.1)
	top.mesh = top_mesh
	top.material_override = DA.base_material(DA.TEX_FLOOR_HAZARD, Color(0.95, 0.93, 0.9), 1.0 / 6.0)
	top.position = Vector3(0.0, - PIVOT_Y - 0.15, 0.0)
	deck.add_child(top)

	var frame: Node3D = DA.load_model("balance_plate.glb")
	frame.position = Vector3(0.0, - PIVOT_Y, 0.0)
	deck.add_child(frame)

	for corner in [Vector3(-1, 0, -1), Vector3(1, 0, -1), Vector3(1, 0, 1), Vector3(-1, 0, 1)]:
		var lamp := OmniLight3D.new()
		lamp.position = corner * 5.7 + Vector3(0.0, - PIVOT_Y + 0.6, 0.0)
		lamp.light_color = Color(1.0, 0.55, 0.2)
		lamp.light_energy = 1.5
		lamp.omni_range = 4.0
		deck.add_child(lamp)
		deck_lamps.append(lamp)

	var key := OmniLight3D.new()
	key.position = Vector3(1.0, 10.0, 3.0)
	key.light_color = Color(0.56, 0.545, 0.485)
	key.light_energy = 60.0
	key.omni_range = 40.0
	key.shadow_enabled = true
	arena.add_child(key)
	var pit := OmniLight3D.new()
	pit.position = Vector3(0.0, -16.0, -4.0)
	pit.light_color = Color(0.9, 0.45, 0.25)
	pit.light_energy = 25.0
	pit.omni_range = 30.0
	arena.add_child(pit)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0.0, 20.0, 20.0)
	fill.light_color = Color(0.56, 0.545, 0.485)
	fill.light_energy = 22.0
	fill.omni_range = 400.0
	arena.add_child(fill)
	for side in [-1.0, 1.0]:
		var wall := OmniLight3D.new()
		wall.position = Vector3(side * 12.0, 4.0, -8.0)
		wall.light_color = Color(0.85, 0.7, 0.5)
		wall.light_energy = 18.0
		wall.omni_range = 22.0
		arena.add_child(wall)

	if Engine.has_meta("mpplus_preview"):
		tilt = Vector2(0.12, 0.08)
		apply_tilt()
		add_ballast(0, Vector2(2.5, -2.0))
		add_ballast(1, Vector2(-3.5, 3.0))
		for id in ballasts.keys():
			ballasts[id].node.position = Vector3(ballasts[id].pos.x, - PIVOT_Y, ballasts[id].pos.y)

func on_play_start_local():
	fade_in_ambience()

## Weight is in "edge units": one runner standing on the trim weighs 1.
func server_tick(delta: float):

	var moment := Vector2.ZERO
	for player in active_players.values():
		if is_instance_valid(player) and player.active:
			moment += Vector2(player.global_position.x, player.global_position.z) / HALF
	for b in ballasts.values():
		if b.landed:
			moment += b.pos / HALF * BALLAST_WEIGHT

	# the worn motor wobbles more and more
	var wobble: float = min(0.2 + play_time * 0.012, 1.1)
	moment += Vector2(sin(play_time * 0.7), cos(play_time * 0.53)) * wobble

	var max_tilt: float = min(0.24 + play_time * 0.002, 0.4)
	target_tilt = (moment * tilt_gain).limit_length(max_tilt)
	tilt = tilt.move_toward(target_tilt, tilt_rate * delta)

	update_ballasts_server(delta)

	ballast_timer -= delta
	if ballast_timer <= 0.0:
		ballast_timer = max(9.0 - play_time * 0.04, 5.0)
		if ballasts.size() < MAX_BALLASTS:
			var spot := Vector2(randf_range(-4.0, 4.0), randf_range(-4.0, 4.0))
			warn_ballast_rpc.rpc(next_ballast_id, spot)
			next_ballast_id += 1

	sync_timer -= delta
	if sync_timer <= 0.0:
		sync_timer = 0.05
		var states: Array = []
		for id in ballasts.keys():
			states.append([id, ballasts[id].pos])
		sync_rpc.rpc(tilt, states)

func update_ballasts_server(delta: float):

	var downhill := Vector2(sin(tilt.x), sin(tilt.y))
	for id in ballasts.keys():
		var b: Dictionary = ballasts[id]
		if not b.landed or b.falling:
			continue
		# static friction holds it on a gentle slope
		if downhill.length() > 0.07 or b.vel.length() > 0.2:
			b.vel += downhill * 9.0 * delta
		b.vel *= 1.0 - min(1.5 * delta, 1.0)
		b.pos += b.vel * delta
		if abs(b.pos.x) > HALF + 0.2 or abs(b.pos.y) > HALF + 0.2:
			ballast_off_rpc.rpc(id)

func _physics_process(delta: float) -> void :
	if replaying:
		return

	if not is_instance_valid(deck):
		return

	if running and not multiplayer.is_server():
		tilt = tilt.lerp(synced_tilt, min(delta * 12.0, 1.0))
	apply_tilt()

	for id in ballasts.keys():
		var b: Dictionary = ballasts[id]
		if b.landed and not b.falling:
			if not multiplayer.is_server():
				b.shown = b.shown.lerp(b.pos, min(delta * 12.0, 1.0))
			else:
				b.shown = b.pos
			b.node.position = Vector3(b.shown.x, - PIVOT_Y, b.shown.y)

	if running:
		slide_local_players(delta)

func apply_tilt():
	deck.rotation = Vector3(tilt.y, 0.0, - tilt.x)
	var lean: float = clamp(tilt.length() / 0.4, 0.0, 1.0)
	for lamp in deck_lamps:
		lamp.light_color = Color(1.0, 0.55, 0.2).lerp(Color(1.0, 0.08, 0.04), lean)
		lamp.light_energy = 1.5 + lean * 4.0

## Each peer slides only the runners it simulates (its own, or all of them in a local game).
func slide_local_players(delta: float):

	var slide: float = min(slide_start + play_time * 0.06, slide_max)
	var drift := Vector3(sin(tilt.x), 0.0, sin(tilt.y)) * slide

	for network_id in hit_timers.keys():
		hit_timers[network_id] = max(hit_timers[network_id] - delta, 0.0)

	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active or not player.is_physics_processing():
			continue

		if player.is_on_floor():
			player.move_and_collide(drift * delta)

		if hit_timers.get(network_id, 0.0) > 0.0:
			continue
		for b in ballasts.values():
			if not b.landed or b.falling or b.vel.length() < 1.2:
				continue
			var ballast_world: Vector3 = b.node.global_position
			var away := Vector3(player.global_position.x - ballast_world.x, 0.0, player.global_position.z - ballast_world.z)
			if away.length() > BALLAST_HALF + 0.6:
				continue
			var push := (Vector3(b.vel.x, 0.0, b.vel.y).normalized() + away.normalized()).normalized()
			hit_timers[network_id] = 0.8
			player.shoved_rpc.rpc(player.global_position - push, player.global_position, push)
			player.shove_velocity += push * (6.0 + b.vel.length() * 2.0)
			sound_rpc.rpc("hit")
			break

func add_ballast(id: int, spot: Vector2) -> Dictionary:
	var node: Node3D = DA.load_model("ballast.glb")
	deck.add_child(node)
	node.position = Vector3(spot.x, - PIVOT_Y + 9.0, spot.y)
	node.rotation.y = randf() * TAU
	var body := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(BALLAST_HALF * 2.0, 1.1, BALLAST_HALF * 2.0)
	shape.shape = box
	shape.position = Vector3(0.0, 0.55, 0.0)
	body.add_child(shape)
	node.add_child(body)
	var b := {"node": node, "pos": spot, "shown": spot, "vel": Vector2.ZERO, "landed": false, "falling": false, "marker": null}
	ballasts[id] = b
	return b



@rpc("authority", "call_remote", "unreliable_ordered")
func sync_rpc(_tilt: Vector2, states: Array):
	synced_tilt = _tilt
	for state in states:
		if ballasts.has(state[0]):
			ballasts[state[0]].pos = state[1]

@rpc("authority", "call_local", "reliable")
func warn_ballast_rpc(id: int, spot: Vector2):

	play_sound("warn")
	set_countdown_mesage_rpc("LEST !", 0.6)

	var marker := MeshInstance3D.new()
	var ring := TorusMesh.new()
	ring.inner_radius = 0.7
	ring.outer_radius = 0.95
	marker.mesh = ring
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1.0, 0.1, 0.05)
	marker.material_override = m
	marker.scale = Vector3(1.0, 0.1, 1.0)
	marker.position = Vector3(spot.x, - PIVOT_Y + 0.05, spot.y)
	deck.add_child(marker)
	var blink := marker.create_tween().set_loops(8)
	blink.tween_callback(func(): marker.visible = not marker.visible)
	blink.tween_interval(0.2)

	await get_tree().create_timer(1.6, false).timeout
	if not is_inside_tree():
		return
	marker.queue_free()

	var b: Dictionary = add_ballast(id, spot)
	var fall := create_tween()
	fall.tween_property(b.node, "position:y", - PIVOT_Y, 0.35).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	await fall.finished
	if not is_inside_tree():
		return
	b.landed = true
	play_sound("drop")
	shake = min(shake + 0.6, 1.2)

	# a ballast landing on someone throws them off its footprint
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active or not player.is_physics_processing():
			continue
		var away := Vector3(player.global_position.x - b.node.global_position.x, 0.0, player.global_position.z - b.node.global_position.z)
		if away.length() < BALLAST_HALF + 0.7:
			var push: Vector3 = away.normalized() if away.length() > 0.05 else Vector3.FORWARD
			player.shoved_rpc.rpc(player.global_position - push, player.global_position, push)
			player.shove_velocity += push * 14.0

@rpc("authority", "call_local", "reliable")
func ballast_off_rpc(id: int):
	if not ballasts.has(id):
		return
	var b: Dictionary = ballasts[id]
	b.falling = true
	play_sound("creak")
	var node: Node3D = b.node
	var world: Transform3D = node.global_transform
	deck.remove_child(node)
	arena.add_child(node)
	node.global_transform = world
	var t := create_tween()
	t.tween_property(node, "position:y", node.position.y - 30.0, 1.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	t.tween_callback(node.queue_free)
	ballasts.erase(id)

@rpc("any_peer", "call_local", "unreliable")
func sound_rpc(key: String):
	play_sound(key)
