extends RefCounted

## Compiles the patched game scripts from user://.../patches/ and puts them in the resource cache under
## their res:// path, so scenes loaded afterwards use them. Runs from Globals._init, before any minigame loads.

const PATCH_DIR = "user://mods/machine_party_unlocked/patches/"
const LOG_PATH = "user://mods/machine_party_unlocked/patcher.log"

static var scripts: Array[GDScript]

static func apply():

	var log_file = FileAccess.open(LOG_PATH, FileAccess.WRITE)
	var list = FileAccess.get_file_as_string(PATCH_DIR + "list.txt")

	for res_path in list.split("\n", false):

		res_path = res_path.strip_edges()
		var source = FileAccess.get_file_as_string(PATCH_DIR + res_path.trim_prefix("res://"))

		# an original already in the cache stays in use by whatever loaded it: the patch would not reach it
		var preloaded: bool = ResourceLoader.has_cached(res_path)

		var script := GDScript.new()
		script.source_code = source
		script.take_over_path(res_path)
		var err = script.reload()
		scripts.append(script)

		var line = "%s %s%s" % ["OK" if err == OK else "FAILED (%s)" % error_string(err), res_path, " (WARNING: original already loaded)" if preloaded else ""]
		print("[Machine Party Overtime] patch ", line)
		if log_file:
			log_file.store_line(line)
			log_file.flush()
