extends Minigame

## LA PRESSE: hydraulic presses slam down on a grid. Targeted tiles flash red first; whoever stands there
## is flattened. Waves get faster and bigger. Push others under a press or off the edge. Last one alive wins.
## Reuses the Disco Dodge player (move, shove with action_1, fall detection on collision layer 5).

const player_scene = preload("res://minigames/disco_dodge/components/player/disco_dodge_player.tscn")
const DA = preload("user://mods/machine_party_unlocked/da_kit.gd")

const PRESS_UP_Y: float = 11.0
const PRESS_HEIGHT: float = 2.5

@export_category("Grid")
@export var grid_size: int = 6
@export var cell_size: float = 3.0

@export_category("Waves")
@export var ramp_time: float = 70.0
@export var start_interval: float = 2.6
@export var min_interval: float = 0.9
@export var start_warn: float = 1.6
@export var min_warn: float = 0.75
@export var start_count: int = 4
@export var max_count: int = 22
@export var target_player_chance: float = 0.5
@export var max_duration: float = 120.0

@export_category("Signal States")
@export var countdown_state: State

@export_category("Networked Nodes")
@export var players_node: Node3D
@export var player_spawn_positions_node: Node3D

@export_category("Components")
@export var multiplayer_synchronizer: MultiplayerSynchronizer
@export var camera: Camera3D
@export var grid_node: Node3D
@export var world_environment: WorldEnvironment

@export_category("Audio")
@export var speaker_ambience: AudioStreamPlayer
@export var speaker_warn: AudioStreamPlayer
@export var speaker_slam: AudioStreamPlayer

var players: Dictionary[int, DiscoDodgePlayer]
var active_players: Dictionary[int, DiscoDodgePlayer]
var dead_players: Array[int]
var player_scores: Dictionary[int, int]
var player_count: int = 0
var finished: bool = false
var game_end: bool = false

var running: bool = false
var play_time: float = 0.0
var tile_materials: Array[StandardMaterial3D]
var presses: Array[Node3D]
var camera_origin: Vector3
var shake: float = 0.0

func _ready() -> void :

	if Engine.has_meta("mpplus_preview"):
		setup_visuals()
		return

	super._ready()

	setup_visuals()

	if multiplayer.is_server():

		multiplayer_synchronizer.set_multiplayer_authority(multiplayer.get_unique_id())

		countdown_state.countdown_started.connect(_on_countdown_started)
		countdown_state.tick.connect(_on_countdown_tick)
		countdown_state.expired.connect(_on_countdown_expired)

	if GameManager.local_game:

		await get_tree().create_timer(1.0).timeout
		minigame_ready.emit(1)

func initialize(_round_number: int, _total_rounds: int, _scores: Dictionary = {}):
	super.initialize(_round_number, _total_rounds, _scores)

	spawn_players()

	state_machine.transition_to_rpc.rpc(&"Round", {"round": _round_number, "total": _total_rounds})

func cleanup():

	if is_multiplayer_authority():
		multiplayer_synchronizer.free()
		queue_free()

func fade_in_ambience():
	if speaker_ambience and not speaker_ambience.playing:
		speaker_ambience.play()

func all_players_loaded():
	super.all_players_loaded()

	if not multiplayer.is_server():
		return

	is_all_player_loaded = true
	minigame_ready.emit(multiplayer.get_unique_id())

func spawn_players():

	var player_spawn_positions = player_spawn_positions_node.get_children()
	player_spawn_positions.shuffle()

	player_count = PlayerManager.player_presences.size()

	var counter: int = 0
	for key in PlayerManager.player_presences.keys():

		var player_presence: PlayerPresence = PlayerManager.player_presences[key]

		var player_character = player_scene.instantiate()
		players_node.add_child(player_character, true)

		player_character.set_player_presence.rpc(player_presence.network_id)
		player_character.teleport_rpc.rpc(
			player_spawn_positions[counter % player_spawn_positions.size()].global_position
		)
		players[player_presence.network_id] = player_character
		active_players[player_presence.network_id] = player_character
		player_character.died.connect(_on_player_died)

		player_scores[player_presence.network_id] = 0

		counter += 1

func setup_visuals():
	camera.current = true
	camera_origin = camera.position
	world_environment.environment = DA.environment()
	DA.add_post_processing(self)
	DA.add_backdrop(self, Vector3(60.0, -6.0, -62.0), 25.0)
	DA.add_backdrop(self, Vector3(-30.0, -10.0, -75.0), -35.0)
	$Arena/Ceiling.visible = false
	for frame in [$Arena/Frame]:
		frame.material_override = DA.base_material(DA.TEX_CONCRETE, Color(0.8, 0.8, 0.78), 0.12)
	build_grid()

## Same grid on every peer: tiles and presses are local visuals, only the cell indices travel over the network.
func build_grid():

	var tile_mesh := BoxMesh.new()
	tile_mesh.size = Vector3(cell_size - 0.12, 0.3, cell_size - 0.12)

	var tile_material: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_HAZARD, Color(1.0, 0.97, 0.9), 1.0 / (cell_size - 0.12))
	tile_material.uv1_offset = Vector3.ONE * 0.5

	for i in grid_size * grid_size:

		var center: Vector3 = cell_center(i)

		var material: StandardMaterial3D = tile_material.duplicate()
		var tile := MeshInstance3D.new()
		tile.mesh = tile_mesh
		tile.material_override = material
		tile.position = center + Vector3(0.0, -0.15, 0.0)
		grid_node.add_child(tile)
		tile_materials.append(material)

		var press: Node3D = DA.load_model("press_head.glb")
		press.position = center + Vector3(0.0, PRESS_UP_Y, 0.0)
		press.rotation_degrees.y = 90.0 * (i % 4)
		grid_node.add_child(press)
		presses.append(press)

func cell_center(index: int) -> Vector3:
	var half: float = grid_size * cell_size * 0.5
	var x: int = index % grid_size
	var z: int = index / grid_size
	return Vector3(- half + (x + 0.5) * cell_size, 0.0, - half + (z + 0.5) * cell_size)

func cell_at(_position: Vector3) -> int:
	var half: float = grid_size * cell_size * 0.5
	var x: int = floori((_position.x + half) / cell_size)
	var z: int = floori((_position.z + half) / cell_size)
	if x < 0 or z < 0 or x >= grid_size or z >= grid_size:
		return -1
	return z * grid_size + x

func _process(delta: float) -> void :

	if running:
		play_time += delta

	if shake > 0.0:
		shake = max(shake - delta * 2.5, 0.0)
		camera.position = camera_origin + Vector3(randf_range(-1, 1), randf_range(-1, 1), 0.0) * shake * 0.35
	else:
		camera.position = camera_origin



func run_waves():

	while running and not game_end and is_inside_tree():

		var t: float = clamp(play_time / ramp_time, 0.0, 1.0)
		var count: int = int(lerp(float(start_count), float(max_count), t))
		var warn: float = lerp(start_warn, min_warn, t)
		var interval: float = lerp(start_interval, min_interval, t)

		var cells: Array = range(grid_size * grid_size)
		cells.shuffle()
		cells = cells.slice(0, count)

		# aim some presses at players so nobody can idle in a corner
		for player in active_players.values():
			if randf() < target_player_chance:
				var cell: int = cell_at(player.global_position)
				if cell >= 0 and not cells.has(cell):
					cells.append(cell)

		warn_cells_rpc.rpc(cells, warn)
		await get_tree().create_timer(warn, false).timeout
		if game_end or not is_inside_tree():
			return

		slam_rpc.rpc(cells)
		crush_players_in(cells)

		await get_tree().create_timer(interval, false).timeout

		if play_time >= max_duration:
			end_game()
			return

func crush_players_in(cells: Array):

	for network_id in active_players.keys():
		var player: DiscoDodgePlayer = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		if cells.has(cell_at(player.global_position)):
			crush_player_rpc.rpc(network_id)

func calculate_score():

	if finished:
		return

	finished = true

	for i in dead_players.size():
		player_scores[dead_players[i]] = i

	for network_id in active_players.keys():
		player_scores[network_id] = player_count

	player_scores_finalized.emit(player_scores)

func end_game():

	if game_end:
		return

	game_end = true
	stop_rpc.rpc()

	await get_tree().create_timer(3.0).timeout

	calculate_score()

	await get_tree().create_timer(2.0).timeout
	set_minigame_sfx_linear_volume_rpc.rpc(0.0)
	state_machine.transition_to_rpc.rpc(&"Finish")
	set_effects_visibility_rpc.rpc(false)

func check_game_end_on_death():

	if game_end:
		return

	if active_players.size() > 1:
		return

	if player_count <= 1 and active_players.size() == 1:
		return

	end_game()



@rpc("authority", "call_local", "reliable")
func start_rpc():
	running = true
	play_time = 0.0
	if multiplayer.is_server():
		run_waves()

@rpc("authority", "call_local", "reliable")
func stop_rpc():
	running = false

@rpc("authority", "call_local", "reliable")
func warn_cells_rpc(cells: Array, warn_time: float):

	if speaker_warn:
		speaker_warn.pitch_scale = randf_range(0.95, 1.1)
		speaker_warn.play()

	for cell in cells:
		var material: StandardMaterial3D = tile_materials[cell]
		material.emission_enabled = true
		material.emission = Color(1.0, 0.08, 0.02)
		material.emission_energy_multiplier = 0.0
		var t = create_tween()
		t.set_loops(int(max(warn_time / 0.25, 1)))
		t.tween_property(material, "emission_energy_multiplier", 3.0, 0.125)
		t.tween_property(material, "emission_energy_multiplier", 0.8, 0.125)

		var press: Node3D = presses[cell]
		var lower = create_tween()
		lower.tween_property(press, "position:y", PRESS_UP_Y - 2.0, warn_time * 0.8
		).set_trans(Tween.TRANS_SINE
		).set_ease(Tween.EASE_OUT)

@rpc("authority", "call_local", "reliable")
func slam_rpc(cells: Array):

	if speaker_slam:
		speaker_slam.pitch_scale = randf_range(0.85, 1.0)
		speaker_slam.play()

	shake = min(shake + 0.4 + cells.size() * 0.03, 1.2)

	for cell in cells:
		var press: Node3D = presses[cell]
		var material: StandardMaterial3D = tile_materials[cell]

		var t = create_tween()
		t.tween_property(press, "position:y", PRESS_HEIGHT * 0.5, 0.1
		).set_trans(Tween.TRANS_EXPO
		).set_ease(Tween.EASE_IN)
		t.tween_callback( func():
			material.emission_enabled = false
		)
		t.tween_interval(0.45)
		t.tween_property(press, "position:y", PRESS_UP_Y, 0.7
		).set_trans(Tween.TRANS_SINE
		).set_ease(Tween.EASE_IN_OUT)

@rpc("authority", "call_local", "reliable")
func crush_player_rpc(_network_id: int):

	var player: DiscoDodgePlayer = players.get(_network_id, null)
	if not is_instance_valid(player) or not player.active:
		return

	player.active = false
	player.player_name_label.visible = false

	var t = create_tween()
	t.tween_property(player.visuals, "scale", Vector3(1.4, 0.06, 1.4), 0.08)

	if multiplayer.is_server():
		player.died.emit(_network_id)
		await get_tree().create_timer(1.5).timeout
		if is_instance_valid(player):
			player.kill_rpc.rpc()

@rpc("any_peer", "call_local", "reliable")
func remove_player_rpc(_network_id: int):

	var player_instance = players.get(_network_id, null)
	if player_instance:
		if multiplayer.is_server():
			players[_network_id].queue_free()
		players.erase(_network_id)
		active_players.erase(_network_id)

func player_disconnected(_network_id: int):
	super.player_disconnected(_network_id)

	if not multiplayer.is_server():
		return

	remove_player_rpc.rpc(_network_id)

	await get_tree().create_timer(1.0).timeout
	check_game_end_on_death()

@rpc("authority", "call_local", "reliable")
func player_died_rpc(_network_id: int):
	active_players.erase(_network_id)
	if not dead_players.has(_network_id):
		dead_players.append(_network_id)

func _on_player_died(_network_id: int):

	if not multiplayer.is_server():
		return

	player_died_rpc.rpc(_network_id)
	check_game_end_on_death()

func _on_countdown_expired():
	super._on_countdown_expired()

	if running:
		return

	for player in players.values():
		player.set_active_rpc.rpc(true)

	state_machine.transition_to_rpc.rpc(&"Play")
	start_rpc.rpc()
