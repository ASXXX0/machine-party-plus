extends Node

## Machine Party Overtime ghosts: in the mod's own minigames, a runner who falls comes back as a ghost orb floating over
## the arena. It moves with the usual controls and, every few seconds, ACTION 1 shoves the survivors under it.
##
## Added under the minigame root on every peer (same path everywhere). Each peer drives the ghosts of the players
## it controls and streams their position; the shove goes through the runner's own shoved_rpc, like a real shove.

const GHOST_SPEED: float = 7.0
const GHOST_HEIGHT: float = 2.6
const ARENA_RADIUS: float = 14.0
const PUSH_RADIUS: float = 2.4
const PUSH_COOLDOWN: float = 5.0

# network id -> {"node": Node3D, "local": bool, "device": int, "cooldown": float, "target": Vector3}
var ghosts: Dictionary = {}
var was_active: Dictionary = {}
var scan_timer: float = 0.0
var sync_timer: float = 0.0
var hint: Label

func _process(delta: float) -> void :

	# the end-of-game replay shows the living: no ghosts on screen
	if get_parent().get("replaying"):
		for ghost in ghosts.values():
			ghost.node.visible = false
		if hint:
			hint.get_parent().visible = false
		return

	scan_timer -= delta
	if scan_timer <= 0.0:
		scan_timer = 0.25
		watch_runners()

	sync_timer -= delta
	var send: bool = sync_timer <= 0.0
	if send:
		sync_timer = 1.0 / 15.0

	for network_id in ghosts.keys():
		var ghost: Dictionary = ghosts[network_id]
		var node: Node3D = ghost.node
		ghost.cooldown = max(ghost.cooldown - delta, 0.0)
		var ring: MeshInstance3D = node.get_node("Ring")
		ring.visible = ghost.local and ghost.cooldown <= 0.0

		if ghost.local:
			if not PauseMenu.active:
				var move := Vector3(
					DynamicInput.get_axis(ghost.device, "left", "right"), 0.0,
					DynamicInput.get_axis(ghost.device, "up", "down")
				)
				var flat := Vector3(node.position.x, 0.0, node.position.z) + move.limit_length(1.0) * GHOST_SPEED * delta
				flat = flat.limit_length(ARENA_RADIUS)
				node.position.x = flat.x
				node.position.z = flat.z
				if ghost.cooldown <= 0.0 and DynamicInput.is_action_just_pressed(ghost.device, "action_1"):
					ghost.cooldown = PUSH_COOLDOWN
					push_from(network_id, node.position)
			if send:
				ghost_position_rpc.rpc(network_id, node.position)
		else:
			node.position = node.position.lerp(ghost.target, min(delta * 12.0, 1.0))

		node.position.y = GHOST_HEIGHT + sin(Time.get_ticks_msec() / 400.0 + network_id) * 0.2

func runners() -> Array:
	# find_children() only filters native classes, so check the script class here
	return get_parent().find_children("*", "CharacterBody3D", true, false).filter(func(b): return b is DiscoDodgePlayer)

## Some minigames only emit `died` on the host (La Presse crushes), so watch the runners themselves:
## a local runner that was in play and is not any more has been eliminated.
func watch_runners():
	for body in runners():
		var network_id: int = body.player_presence.network_id if body.player_presence else -1
		if network_id == -1 or ghosts.has(network_id):
			continue
		if not (GameManager.local_game or network_id == multiplayer.get_unique_id()):
			continue
		if body.active:
			was_active[network_id] = true
		elif was_active.get(network_id, false):
			was_active[network_id] = false
			raise_ghost(network_id, body)

func raise_ghost(network_id: int, body: Node):

	var presence: PlayerPresence = body.player_presence
	# let the fall play out first
	await get_tree().create_timer(1.8, false).timeout
	if not is_inside_tree() or ghosts.has(network_id) or not is_instance_valid(body):
		return
	if body.active:
		return
	var flat := Vector3(body.global_position.x, 0.0, body.global_position.z).limit_length(ARENA_RADIUS * 0.6)
	spawn_ghost(network_id, Vector3(flat.x, GHOST_HEIGHT, flat.z), presence.network_name, true, presence.device_id)
	show_hint()

func spawn_ghost(network_id: int, position: Vector3, display_name: String, is_local: bool, device: int):

	var node := Node3D.new()
	node.name = "Ghost%d" % network_id
	node.position = position
	get_parent().add_child(node)

	var orb := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.45
	sphere.height = 0.9
	orb.mesh = sphere
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(0.55, 0.9, 1.0, 0.55)
	orb.material_override = m
	node.add_child(orb)

	var ring := MeshInstance3D.new()
	ring.name = "Ring"
	var torus := TorusMesh.new()
	torus.inner_radius = PUSH_RADIUS - 0.15
	torus.outer_radius = PUSH_RADIUS
	ring.mesh = torus
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rm.albedo_color = Color(0.55, 0.9, 1.0, 0.35)
	ring.material_override = rm
	ring.scale = Vector3(1.0, 0.05, 1.0)
	ring.position = Vector3(0.0, - GHOST_HEIGHT + 0.1, 0.0)
	node.add_child(ring)

	var glow := OmniLight3D.new()
	glow.light_color = Color(0.55, 0.9, 1.0)
	glow.light_energy = 2.0
	glow.omni_range = 4.0
	node.add_child(glow)

	var label := Label3D.new()
	label.text = display_name
	label.font_size = 40
	label.pixel_size = 0.006
	label.outline_size = 10
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.modulate = Color(0.7, 0.95, 1.0)
	label.position = Vector3(0.0, 0.8, 0.0)
	node.add_child(label)

	ghosts[network_id] = {"node": node, "local": is_local, "device": device, "cooldown": 1.0, "target": position}

func show_hint():
	if hint:
		return
	var layer := CanvasLayer.new()
	layer.layer = 90
	add_child(layer)
	hint = Label.new()
	hint.text = "TU ES UN FANTOME : deplace-toi et appuie sur ACTION 1 pour bousculer les survivants."
	hint.add_theme_font_size_override("font_size", 12)
	hint.add_theme_color_override("font_color", Color(0.7, 0.95, 1.0))
	hint.add_theme_color_override("font_outline_color", Color.BLACK)
	hint.add_theme_constant_override("outline_size", 4)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.position = Vector2(0, 500)
	hint.size = Vector2(960, 20)
	layer.add_child(hint)

## Shoves every runner still in play under the ghost, through their own shove RPC.
func push_from(network_id: int, ghost_position: Vector3):
	var hit: bool = false
	for body in runners():
		if not body.active:
			continue
		var away := Vector3(body.global_position.x - ghost_position.x, 0.0, body.global_position.z - ghost_position.z)
		if away.length() > PUSH_RADIUS:
			continue
		var dir: Vector3 = away.normalized() if away.length() > 0.1 else Vector3.FORWARD
		body.shoved_rpc.rpc(body.global_position - dir, body.global_position, dir)
		hit = true
	ghost_push_fx_rpc.rpc(network_id)
	if hit:
		var party = get_node_or_null("/root/MachinePartyMod/Party")
		if party:
			party.add_stat_remote.rpc_id(1, network_id, "ghost")



@rpc("any_peer", "call_remote", "unreliable_ordered")
func ghost_position_rpc(network_id: int, position: Vector3):
	if not ghosts.has(network_id):
		var display_name: String = "?"
		if PlayerManager.player_presences.has(network_id):
			display_name = PlayerManager.player_presences[network_id].network_name
		spawn_ghost(network_id, position, display_name, false, -1)
	ghosts[network_id].target = position

@rpc("any_peer", "call_local", "reliable")
func ghost_push_fx_rpc(network_id: int):
	if not ghosts.has(network_id):
		return
	var node: Node3D = ghosts[network_id].node
	var wave := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.3
	torus.outer_radius = 0.5
	wave.mesh = torus
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(0.7, 0.95, 1.0, 0.8)
	wave.material_override = m
	wave.position = node.position - Vector3(0.0, GHOST_HEIGHT - 0.2, 0.0)
	get_parent().add_child(wave)
	var t := wave.create_tween().set_parallel()
	t.tween_property(wave, "scale", Vector3(PUSH_RADIUS * 2.0, 0.2, PUSH_RADIUS * 2.0), 0.35)
	t.tween_property(m, "albedo_color:a", 0.0, 0.35)
	t.chain().tween_callback(wave.queue_free)
