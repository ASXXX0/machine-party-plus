extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## EN VEDETTE: a dark stage and one spotlight wandering over it. Every second you stand in the light ALONE earns
## a point; share it and nobody scores, so shove the others out. The light speeds up and shrinks as the show
## goes on. Most points when the curtain falls wins. Falling off the stage only costs you time: you climb back
## on at the edge.

const RADIUS: float = 9.0
const START_SPOT: float = 2.6
const END_SPOT: float = 1.5

var spot_position: Vector3 = Vector3.ZERO
var spot_target: Vector3 = Vector3.ZERO
var spot_radius: float = START_SPOT
var score_time: Dictionary = {}
var spot: SpotLight3D
var disc: MeshInstance3D
var sync_timer: float = 0.0
var star: int = -1
var star_label: Label3D

func spawn_points() -> Array[Vector3]:
	return [Vector3(-5, 0.1, -5), Vector3(5, 0.1, -5), Vector3(5, 0.1, 5), Vector3(-5, 0.1, 5), Vector3(0, 0.1, 6)]

func fall_height() -> float:
	# nobody is eliminated: falling sends you back on stage
	return -40.0

func build_arena():
	max_duration = 60.0
	set_camera(Vector3(0.0, 17.0, 15.0), Vector3(0.0, -1.0, 0.8))
	add_sound("ambience", "res://audio/unique/disco_bassline.ogg", -10.0, true)
	add_sound("point", "res://audio/unique/blip1.ogg", -10.0)
	add_sound("crowd", "res://audio/sfx/airplane ding.ogg", -6.0)

	add_backdrop_model("res://minigames/exploding_collar_race/models/collar race light fixture1/collar race light fixture1.glb", Vector3(-11.0, 3.0, -9.0))
	add_backdrop_model("res://minigames/exploding_collar_race/models/collar race light fixture1/collar race light fixture1.glb", Vector3(11.0, 3.0, -9.0))

	# the stage: a round wooden-dark deck with a gold rim
	var body := StaticBody3D.new()
	arena.add_child(body)
	var shape := CollisionShape3D.new()
	var cylinder := CylinderShape3D.new()
	cylinder.radius = RADIUS
	cylinder.height = 1.0
	shape.shape = cylinder
	shape.position.y = -0.5
	body.add_child(shape)
	var deck := MeshInstance3D.new()
	var deck_mesh := CylinderMesh.new()
	deck_mesh.top_radius = RADIUS
	deck_mesh.bottom_radius = RADIUS + 0.4
	deck_mesh.height = 1.0
	deck_mesh.radial_segments = 64
	deck.mesh = deck_mesh
	deck.material_override = DA.base_material(DA.TEX_FLOOR_MARKED, Color(0.55, 0.5, 0.48), 0.5)
	deck.position.y = -0.5
	arena.add_child(deck)
	var rim := MeshInstance3D.new()
	var rim_mesh := TorusMesh.new()
	rim_mesh.inner_radius = RADIUS - 0.2
	rim_mesh.outer_radius = RADIUS + 0.1
	rim.mesh = rim_mesh
	rim.material_override = DA.kind_material("mp_hazard")
	rim.scale = Vector3(1, 0.4, 1)
	arena.add_child(rim)
	# footlights along the front edge
	for k in 7:
		var angle: float = PI * 0.25 + k * PI * 0.5 / 6.0
		add_light(Vector3(cos(angle) * (RADIUS + 0.3), 0.4, sin(angle) * (RADIUS + 0.3)), Color(1.0, 0.6, 0.3), 0.8, 3.0)

	# a dim house light: the spot is the real light on stage
	add_key_lights(Vector3(0.0, 12.0, 4.0), 26.0, 10.0)

	spot = SpotLight3D.new()
	spot.position = Vector3(0.0, 14.0, 2.0)
	spot.light_color = Color(1.0, 0.95, 0.82)
	spot.light_energy = 60.0
	spot.spot_range = 30.0
	spot.shadow_enabled = true
	arena.add_child(spot)
	disc = MeshInstance3D.new()
	var disc_mesh := CylinderMesh.new()
	disc_mesh.top_radius = 1.0
	disc_mesh.bottom_radius = 1.0
	disc_mesh.height = 0.02
	disc.mesh = disc_mesh
	disc.material_override = unshaded(Color(1.0, 0.95, 0.7, 0.3))
	arena.add_child(disc)

	star_label = Label3D.new()
	star_label.text = "EN VEDETTE"
	star_label.font_size = 56
	star_label.pixel_size = 0.006
	star_label.outline_size = 12
	star_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	star_label.no_depth_test = true
	star_label.modulate = Color(1.0, 0.85, 0.3)
	star_label.visible = false
	arena.add_child(star_label)
	place_spot()

func place_spot():
	spot.look_at(spot_position, Vector3.UP)
	spot.spot_angle = rad_to_deg(atan(spot_radius / spot.position.distance_to(spot_position))) * 1.1
	disc.position = spot_position + Vector3(0, 0.02, 0)
	disc.scale = Vector3(spot_radius, 1.0, spot_radius)

func on_play_start_local():
	fade_in_ambience()
	build_hud(true)

func on_server_play_start():
	for network_id in players.keys():
		points[network_id] = 0
	points_rpc.rpc(points)
	pick_target()

func pick_target():
	var angle: float = randf() * TAU
	var dist: float = sqrt(randf()) * (RADIUS - 2.5)
	spot_target = Vector3(cos(angle) * dist, 0.0, sin(angle) * dist)

func server_tick(delta: float):
	var speed: float = 1.4 + play_time * 0.03
	spot_position = spot_position.move_toward(spot_target, speed * delta)
	if spot_position.distance_to(spot_target) < 0.2:
		pick_target()
	spot_radius = lerpf(START_SPOT, END_SPOT, clamp(play_time / max_duration, 0.0, 1.0))

	# who is in the light?
	var lit: Array = []
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		var flat := Vector2(player.global_position.x - spot_position.x, player.global_position.z - spot_position.z)
		if flat.length() < spot_radius and player.global_position.y > -1.0:
			lit.append(network_id)
	var new_star: int = lit[0] if lit.size() == 1 else -1
	if new_star != star:
		star = new_star
		star_rpc.rpc(star)
	if star != -1:
		score_time[star] = score_time.get(star, 0.0) + delta
		if score_time[star] >= 1.0:
			score_time[star] -= 1.0
			add_points(star)
			sfx_rpc.rpc("point")

	sync_timer -= delta
	if sync_timer <= 0.0:
		sync_timer = 0.05
		spot_rpc.rpc(spot_position, spot_radius)

@rpc("authority", "call_remote", "unreliable_ordered")
func spot_rpc(position: Vector3, radius: float):
	spot_position = position
	spot_radius = radius

@rpc("authority", "call_local", "reliable")
func star_rpc(network_id: int):
	star = network_id
	star_label.visible = network_id != -1
	disc.material_override = unshaded(Color(1.0, 0.85, 0.3, 0.3) if network_id != -1 else Color(1.0, 0.95, 0.7, 0.18))

func visual_tick(_delta: float):
	place_spot()
	if star != -1 and players.has(star) and is_instance_valid(players[star]):
		star_label.global_position = players[star].global_position + Vector3(0, 2.8, 0)
	if not running:
		return
	# off the stage: back on at the edge
	for player in local_runners():
		if player.global_position.y < -4.0:
			var flat := Vector3(player.global_position.x, 0.0, player.global_position.z)
			var back: Vector3 = flat.normalized() * (RADIUS - 1.0) if flat.length() > 0.1 else Vector3(0, 0, RADIUS - 1.0)
			player.global_position = back + Vector3(0, 0.3, 0)
			player.velocity = Vector3.ZERO
			player.shove_velocity = Vector3.ZERO

func compute_scores() -> Dictionary[int, int]:
	return rank_scores(points)

func check_game_end_on_death():
	pass
