extends Minigame

## Machine Party Overtime minigame base. Builds the standard minigame skeleton in code (state machine with the game's
## shared states, overlay, networked player spawner, camera, environment, fall plane), so a minigame scene is a
## single root node with its script. Subclasses override the hooks marked "hook".
##
## Flow (same as the game's own minigames): initialize -> Round -> PlayerMarker -> Countdown -> Play -> Finish.

const DA = preload("user://mods/machine_party_unlocked/da_kit.gd")
const REPLAY = preload("user://mods/machine_party_unlocked/common/replay.gd")

const PLAYER_SCENE_PATH = "res://minigames/disco_dodge/components/player/disco_dodge_player.tscn"
const OVERLAY_SCENE = "res://modules/minigame/components/overlay/minigame_overlay.tscn"
const STATES = {
	"Empty": "res://minigames/shared/states/empty_state.gd",
	"Round": "res://minigames/shared/states/round_state.gd",
	"PlayerMarker": "res://minigames/shared/states/player_marker_state.gd",
	"Countdown": "res://minigames/shared/states/countdown_state.gd",
	"Play": "res://minigames/disco_dodge/states/play_state.gd",
	"Finish": "res://minigames/disco_dodge/states/finish_state.gd",
}

var countdown_state: State
var networked: Node3D
var players_node: Node3D
var arena: Node3D
var camera: Camera3D
var world_environment: WorldEnvironment
var multiplayer_synchronizer: MultiplayerSynchronizer

var players: Dictionary[int, Node3D]
var active_players: Dictionary[int, Node3D]
var dead_players: Array[int]
var player_scores: Dictionary[int, int]
var player_count: int = 0
var running: bool = false
var game_end: bool = false
var finished: bool = false
var play_time: float = 0.0
var max_duration: float = 90.0

var camera_origin: Vector3
var replay: Node
# set while the end-of-game replay plays: the minigame's own rules and motion stop
var replaying: bool = false
var shake: float = 0.0
var audio: Dictionary[String, AudioStreamPlayer]

func _init() -> void :
	build_skeleton()

func build_skeleton():

	var state_machine_node := StateMachine.new()
	state_machine_node.name = "StateMachine"
	state_machine_node.debug_print = true
	state_machine_node.initial_state = NodePath("Empty")
	add_owned(self, state_machine_node)

	networked = Node3D.new()
	networked.name = "Networked"
	add_owned(self, networked)

	players_node = Node3D.new()
	players_node.name = "Players"

	for state_name in STATES.keys():
		var state := Node.new()
		state.name = state_name
		state.set_script(load(STATES[state_name]))
		if state_name == "PlayerMarker":
			state.players_node = players_node
		add_owned(state_machine_node, state)
	countdown_state = state_machine_node.get_node("Countdown")

	var spawner := MultiplayerSpawner.new()
	spawner.name = "PlayerSpawner"
	spawner.add_spawnable_scene(player_scene_path())
	spawner.spawn_limit = 5
	add_owned(networked, spawner)
	add_owned(networked, players_node)
	spawner.spawn_path = spawner.get_path_to(players_node)

	multiplayer_synchronizer = MultiplayerSynchronizer.new()
	multiplayer_synchronizer.name = "MultiplayerSynchronizer"
	add_owned(self, multiplayer_synchronizer)

	world_environment = WorldEnvironment.new()
	world_environment.name = "WorldEnvironment"
	add_owned(self, world_environment)

	arena = Node3D.new()
	arena.name = "Arena"
	add_owned(self, arena)

	camera = Camera3D.new()
	camera.name = "Camera3D"
	camera.fov = 67.8
	add_owned(self, camera)

	var fall_area := Area3D.new()
	fall_area.name = "FallArea"
	fall_area.collision_layer = 16
	fall_area.collision_mask = 16
	add_owned(self, fall_area)
	var fall_shape := CollisionShape3D.new()
	fall_shape.shape = WorldBoundaryShape3D.new()
	fall_shape.position = Vector3(0.0, fall_height(), 0.0)
	add_owned(fall_area, fall_shape)

	var overlay: Node = load(OVERLAY_SCENE).instantiate()
	overlay.name = "MinigameOverlay"
	add_owned(self, overlay)
	minigame_overlay = overlay

	var audio_node := Node.new()
	audio_node.name = "audio"
	add_owned(self, audio_node)

func add_owned(parent: Node, child: Node):
	parent.add_child(child)
	child.owner = self

## Adds a named one-shot or looping sound from the game's audio files.
func add_sound(key: String, path: String, volume_db: float = 0.0, loop: bool = false):
	var player := AudioStreamPlayer.new()
	player.name = key
	var stream = load(path)
	if loop and stream is AudioStreamOggVorbis:
		stream = stream.duplicate()
		stream.loop = true
	player.stream = stream
	player.volume_db = volume_db
	player.bus = &"MINIGAME_SFX"
	get_node("audio").add_child(player)
	audio[key] = player

func play_sound(key: String, pitch_jitter: float = 0.05):
	if not audio.has(key):
		return
	audio[key].pitch_scale = 1.0 + randf_range(- pitch_jitter, pitch_jitter)
	audio[key].play()

func set_camera(_position: Vector3, look_at_target: Vector3, fov: float = 67.8):
	camera.position = _position
	camera.fov = fov
	camera.look_at_from_position(_position, look_at_target, Vector3.UP)
	camera_origin = _position



## hook: player scene, spawn points, fall plane, visuals
func player_scene_path() -> String:
	return PLAYER_SCENE_PATH

func spawn_points() -> Array[Vector3]:
	return [Vector3(-3, 0.1, -3), Vector3(3, 0.1, -3), Vector3(3, 0.1, 3), Vector3(-3, 0.1, 3), Vector3(0, 0.1, 0)]

func spawn_yaw(_index: int) -> float:
	return 0.0

func fall_height() -> float:
	return -5.0

func build_arena():
	pass

## hook: called on every peer when play starts, and on the server for the rules
func on_play_start():
	for player in players.values():
		player.set_active_rpc.rpc(true)

func on_server_play_start():
	pass

## hook: per-frame rules on the server while running
func server_tick(_delta: float):
	pass

## hook: per-frame visuals on every peer
func visual_tick(_delta: float):
	pass

## hook: final scores (network id -> points); default ranks by elimination order
func compute_scores() -> Dictionary[int, int]:
	var scores: Dictionary[int, int]
	for network_id in players.keys():
		scores[network_id] = 0
	for i in dead_players.size():
		scores[dead_players[i]] = i
	for network_id in active_players.keys():
		scores[network_id] = player_count
	return scores



func _ready() -> void :

	if Engine.has_meta("mpplus_preview"):
		setup_visuals()
		return

	super._ready()

	setup_visuals()

	replay = REPLAY.new()
	replay.name = "Replay"
	add_child(replay)

	if multiplayer.is_server():

		multiplayer_synchronizer.set_multiplayer_authority(multiplayer.get_unique_id())

		countdown_state.countdown_started.connect(_on_countdown_started)
		countdown_state.tick.connect(_on_countdown_tick)
		countdown_state.expired.connect(_on_countdown_expired)

	if GameManager.local_game:

		await get_tree().create_timer(1.0).timeout
		minigame_ready.emit(1)

func setup_visuals():
	camera.current = true
	world_environment.environment = DA.environment()
	DA.add_post_processing(self)
	build_arena()
	camera_origin = camera.position

func initialize(_round_number: int, _total_rounds: int, _scores: Dictionary = {}):
	super.initialize(_round_number, _total_rounds, _scores)

	spawn_players()

	state_machine.transition_to_rpc.rpc(&"Round", {"round": _round_number, "total": _total_rounds})

func cleanup():

	if is_multiplayer_authority():
		multiplayer_synchronizer.free()
		queue_free()

func fade_in_ambience():
	if audio.has("ambience") and not audio["ambience"].playing:
		audio["ambience"].play()

func all_players_loaded():
	super.all_players_loaded()

	if not multiplayer.is_server():
		return

	is_all_player_loaded = true
	minigame_ready.emit(multiplayer.get_unique_id())

func spawn_players():

	var points: Array[Vector3] = spawn_points()
	player_count = PlayerManager.player_presences.size()

	var scene: PackedScene = load(player_scene_path())
	var counter: int = 0
	for key in PlayerManager.player_presences.keys():

		var player_presence: PlayerPresence = PlayerManager.player_presences[key]

		var player_character = scene.instantiate()
		players_node.add_child(player_character, true)

		player_character.set_player_presence.rpc(player_presence.network_id)
		player_character.teleport_rpc.rpc(points[counter % points.size()])
		face_player_rpc.rpc(player_presence.network_id, spawn_yaw(counter))

		players[player_presence.network_id] = player_character
		active_players[player_presence.network_id] = player_character
		if player_character.has_signal("died"):
			player_character.died.connect(_on_player_died)

		player_scores[player_presence.network_id] = 0

		counter += 1

	register_players_rpc.rpc(players.keys())

## Seat index of a player: the order players were spawned in, the same on every peer.
func seat_of(network_id: int) -> int:
	return players.keys().find(network_id)

func is_local_player(network_id: int) -> bool:
	return GameManager.local_game or network_id == multiplayer.get_unique_id()

func _process(delta: float) -> void :

	if replaying:
		return

	if running:
		play_time += delta
		if multiplayer.is_server():
			server_tick(delta)
			if play_time >= max_duration and not game_end:
				end_game()

	visual_tick(delta)
	update_hud_timer()

	if shake > 0.0:
		shake = max(shake - delta * 2.5, 0.0)
		camera.position = camera_origin + Vector3(randf_range(-1, 1), randf_range(-1, 1), 0.0) * shake * 0.3
	elif camera_origin != Vector3.ZERO:
		camera.position = camera_origin

func eliminate(network_id: int):
	if not multiplayer.is_server():
		return
	if not active_players.has(network_id):
		return
	player_died_rpc.rpc(network_id)
	check_game_end_on_death()

func check_game_end_on_death():

	if game_end:
		return

	if active_players.size() > 1:
		return

	if player_count <= 1 and active_players.size() == 1:
		return

	end_game()

func end_game():

	if game_end:
		return

	game_end = true
	stop_rpc.rpc()

	# let the last elimination's clip finish recording, then replay the best moment for everyone
	await get_tree().create_timer(1.3).timeout
	var clip: int = replay.best_clip() if replay else -1
	if clip != -1:
		replay_rpc.rpc(clip)
		await get_tree().create_timer(replay.duration() + 0.6).timeout
	else:
		await get_tree().create_timer(1.7).timeout

	if not finished:
		finished = true
		player_scores_finalized.emit(compute_scores())

	await get_tree().create_timer(2.0).timeout
	set_minigame_sfx_linear_volume_rpc.rpc(0.0)
	state_machine.transition_to_rpc.rpc(&"Finish")
	set_effects_visibility_rpc.rpc(false)



@rpc("authority", "call_local", "reliable")
func replay_rpc(network_id: int):
	if replay:
		replay.play(network_id)

@rpc("authority", "call_local", "reliable")
func register_players_rpc(network_ids: Array):
	for network_id in network_ids:
		if players.has(network_id):
			continue
		for child in players_node.get_children():
			if child.player_presence and child.player_presence.network_id == network_id:
				players[network_id] = child
				active_players[network_id] = child

@rpc("authority", "call_local", "reliable")
func face_player_rpc(network_id: int, yaw: float):
	await get_tree().process_frame
	for child in players_node.get_children():
		if child.player_presence and child.player_presence.network_id == network_id and "visuals" in child:
			child.visuals.rotation.y = yaw

@rpc("authority", "call_local", "reliable")
func start_rpc():
	running = true
	play_time = 0.0
	on_play_start_local()

## hook: visuals/state when play starts, every peer
func on_play_start_local():
	pass

@rpc("authority", "call_local", "reliable")
func stop_rpc():
	running = false

@rpc("authority", "call_local", "reliable")
func player_died_rpc(_network_id: int):
	active_players.erase(_network_id)
	if not dead_players.has(_network_id):
		dead_players.append(_network_id)

@rpc("any_peer", "call_local", "reliable")
func remove_player_rpc(_network_id: int):

	var player_instance = players.get(_network_id, null)
	if player_instance:
		if multiplayer.is_server():
			players[_network_id].queue_free()
		players.erase(_network_id)
		active_players.erase(_network_id)

func player_disconnected(_network_id: int):
	super.player_disconnected(_network_id)

	if not multiplayer.is_server():
		return

	remove_player_rpc.rpc(_network_id)

	await get_tree().create_timer(1.0).timeout
	check_game_end_on_death()

func _on_player_died(_network_id: int):
	eliminate(_network_id)

func _on_countdown_expired():
	super._on_countdown_expired()

	if running:
		return

	on_play_start()
	state_machine.transition_to_rpc.rpc(&"Play")
	start_rpc.rpc()
	on_server_play_start()




## ---------------- Shared helpers for the arenas ----------------

const SEAT_COLORS: Array[Color] = [
	Color(0.95, 0.3, 0.2), Color(0.25, 0.55, 1.0), Color(0.35, 0.85, 0.3), Color(1.0, 0.8, 0.15), Color(0.75, 0.35, 0.95)
]

var points: Dictionary = {}
var hud_layer: CanvasLayer
var hud_label: Label
var hud_timer_label: Label
var show_timer: bool = false

func seat_color(network_id: int) -> Color:
	var seat: int = seat_of(network_id)
	return SEAT_COLORS[seat % SEAT_COLORS.size()] if seat >= 0 else Color.WHITE

func player_name(network_id: int) -> String:
	if PlayerManager.player_presences.has(network_id):
		return PlayerManager.player_presences[network_id].network_name
	return "?"

## A box with the game's materials; collides unless told otherwise. Returns the mesh (its parent body if solid).
func add_box(size: Vector3, position: Vector3, material: Material, parent: Node = null, solid: bool = true) -> Node3D:
	var target: Node = parent if parent else arena
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.material_override = material
	if not solid:
		mesh.position = position
		target.add_child(mesh)
		return mesh
	var body := StaticBody3D.new()
	body.position = position
	target.add_child(body)
	var shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = size
	shape.shape = box_shape
	body.add_child(shape)
	body.add_child(mesh)
	return body

func add_light(position: Vector3, color: Color, energy: float, light_range: float, shadow: bool = false) -> OmniLight3D:
	var light := OmniLight3D.new()
	light.position = position
	light.light_color = color
	light.light_energy = energy
	light.omni_range = light_range
	light.shadow_enabled = shadow
	arena.add_child(light)
	return light

## The usual DA lighting: a shadowed key above the arena and a far fill toward the camera.
func add_key_lights(key_position: Vector3, key_energy: float = 70.0, fill_energy: float = 18.0):
	add_light(key_position, Color(0.56, 0.545, 0.485), key_energy, 45.0, true)
	add_light(Vector3(0.0, 20.0, 22.0), Color(0.56, 0.545, 0.485), fill_energy, 400.0)

## One of the game's own environment models as a backdrop.
func add_backdrop_model(path: String, position: Vector3, yaw_degrees: float = 0.0, scale: float = 1.0) -> Node3D:
	var scene: PackedScene = load(path)
	if scene == null:
		return null
	var model: Node3D = scene.instantiate()
	model.position = position
	model.rotation.y = deg_to_rad(yaw_degrees)
	model.scale = Vector3.ONE * scale
	arena.add_child(model)
	return model

func unshaded(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = color
	if color.a < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m

## A blinking red ring on the floor that removes itself.
func warn_ring(position: Vector3, radius: float, duration: float, color: Color = Color(1.0, 0.1, 0.05)):
	var marker := MeshInstance3D.new()
	var ring := TorusMesh.new()
	ring.inner_radius = max(radius - 0.2, 0.05)
	ring.outer_radius = radius
	marker.mesh = ring
	marker.material_override = unshaded(color)
	marker.scale = Vector3(1.0, 0.1, 1.0)
	marker.position = position + Vector3(0.0, 0.04, 0.0)
	arena.add_child(marker)
	var blink := marker.create_tween().set_loops(int(duration / 0.4) + 1)
	blink.tween_callback(func(): marker.visible = not marker.visible)
	blink.tween_interval(0.2)
	get_tree().create_timer(duration, false).timeout.connect(marker.queue_free)

## Runners this peer simulates (its own, or all of them in a local game), still in play.
func local_runners() -> Array:
	var result: Array = []
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if is_instance_valid(player) and player.active and player.is_physics_processing():
			result.append(player)
	return result

## Squash and remove a runner (crushed, burnt, zapped). Host only; every peer sees the squash.
func crush(network_id: int):
	if multiplayer.is_server():
		crush_rpc.rpc(network_id)

@rpc("authority", "call_local", "reliable")
func crush_rpc(network_id: int):
	var player = players.get(network_id, null)
	if not is_instance_valid(player) or not player.active:
		return
	player.active = false
	player.player_name_label.visible = false
	player.create_tween().tween_property(player.visuals, "scale", Vector3(1.4, 0.06, 1.4), 0.08)
	if multiplayer.is_server():
		player.died.emit(network_id)
		await get_tree().create_timer(1.5).timeout
		if is_instance_valid(player):
			player.kill_rpc.rpc()

## A runner asks the host to be removed (it fell in something only it can see precisely).
@rpc("any_peer", "call_local", "reliable")
func request_crush_rpc(network_id: int):
	crush(network_id)

## Pushes a runner as if shoved, on its own peer (call it where the runner is simulated).
func push_runner(player, direction: Vector3, strength: float):
	direction.y = 0.0
	if direction.length() < 0.01:
		direction = Vector3.FORWARD
	direction = direction.normalized()
	player.shoved_rpc.rpc(player.global_position - direction, player.global_position, direction)
	player.shove_velocity += direction * strength

## ---- points-based minigames: host keeps the points, every peer shows them ----

func add_points(network_id: int, amount: int = 1):
	if not multiplayer.is_server():
		return
	points[network_id] = points.get(network_id, 0) + amount
	points_rpc.rpc(points)

@rpc("authority", "call_local", "reliable")
func points_rpc(_points: Dictionary):
	points = _points
	update_hud()

## Placement scores from raw points, on the same scale as the game's own minigames: the leader(s) get the
## player count, everyone else the number of players strictly behind them (4 players: 4, 2, 1, 0).
func rank_scores(raw: Dictionary) -> Dictionary[int, int]:
	var scores: Dictionary[int, int]
	var top: int = 0
	for network_id in players.keys():
		top = max(top, raw.get(network_id, 0))
	for network_id in players.keys():
		var mine: int = raw.get(network_id, 0)
		if top > 0 and mine == top:
			scores[network_id] = player_count
			continue
		var behind: int = 0
		for other in players.keys():
			if raw.get(other, 0) < mine:
				behind += 1
		scores[network_id] = behind
	return scores

func build_hud(with_timer: bool):
	show_timer = with_timer
	hud_layer = CanvasLayer.new()
	hud_layer.layer = 5
	add_child(hud_layer)
	hud_label = Label.new()
	hud_label.position = Vector2(14, 12)
	hud_label.add_theme_font_size_override("font_size", 14)
	hud_label.add_theme_color_override("font_outline_color", Color.BLACK)
	hud_label.add_theme_constant_override("outline_size", 5)
	hud_layer.add_child(hud_label)
	hud_timer_label = Label.new()
	hud_timer_label.position = Vector2(430, 10)
	hud_timer_label.size = Vector2(100, 30)
	hud_timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_timer_label.add_theme_font_size_override("font_size", 22)
	hud_timer_label.add_theme_color_override("font_outline_color", Color.BLACK)
	hud_timer_label.add_theme_constant_override("outline_size", 6)
	hud_layer.add_child(hud_timer_label)
	update_hud()

func update_hud():
	if not hud_label:
		return
	var lines: Array[String] = []
	for network_id in players.keys():
		lines.append("%s : %d" % [player_name(network_id), points.get(network_id, 0)])
	hud_label.text = "\n".join(lines)

func update_hud_timer():
	if hud_timer_label and show_timer and running:
		hud_timer_label.text = str(maxi(ceili(max_duration - play_time), 0))

@rpc("any_peer", "call_local", "unreliable")
func sfx_rpc(key: String):
	play_sound(key)
