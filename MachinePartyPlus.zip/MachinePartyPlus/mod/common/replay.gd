extends Node

## Machine Party Overtime replays. Every peer records the last few seconds of its own minigame (runners and the moving
## parts of the arena, 30 times a second). Each elimination keeps a clip around it, scored by how fast the runner
## was going. When the minigame ends, the host picks the best clip and every peer plays its own recording of it
## in slow motion, the camera closing in on the victim.
##
## Lives under mp_base minigames; the minigame stops its own rules while `replaying` is set.

const RATE: float = 1.0 / 30.0
const BEFORE: float = 2.6
const AFTER: float = 1.0
const SPEED: float = 0.45
const SCAN_DEPTH: int = 3

var minigame: Node
var frames: Array = []
var clock: float = 0.0
var step: float = 0.0
var scan_timer: float = 0.0
var tracked: Array[Node3D] = []
var was_active: Dictionary = {}
var clips: Dictionary = {}

var playing: Array = []
var play_time: float = 0.0
var focus_id: int = -1
var focus_at: Vector3
var overlay: CanvasLayer
var camera_from: Transform3D
var camera_fov: float = 0.0

func _ready() -> void :
	minigame = get_parent()

func _process(delta: float) -> void :
	if not playing.is_empty():
		advance(delta)
		return
	if not minigame.running and not minigame.game_end:
		return
	clock += delta
	step += delta
	if step < RATE:
		return
	step = 0.0

	scan_timer -= RATE
	if scan_timer <= 0.0:
		scan_timer = 1.0
		scan(minigame.arena, 0)

	record()

## Moving parts of the arena: its descendants a few levels down (walls, presses, decks, balls...).
func scan(node: Node, depth: int):
	if depth > SCAN_DEPTH:
		return
	for child in node.get_children():
		if child is Node3D and not tracked.has(child):
			tracked.append(child)
		scan(child, depth + 1)

func record():
	var frame: Dictionary = {"t": clock, "runners": {}, "nodes": {}}
	for network_id in minigame.players.keys():
		var runner = minigame.players[network_id]
		if not is_instance_valid(runner):
			continue
		var visuals: Node3D = runner.visuals
		frame.runners[network_id] = [
			runner.global_position, visuals.rotation, visuals.position, visuals.scale, visuals.visible,
			runner.animation_tree.get("parameters/run_blend/blend_amount"),
			runner.animation_tree.get("parameters/falling_blend/blend_amount"),
		]
		# an elimination: the runner was in play and is not any more
		if runner.active:
			was_active[network_id] = true
		elif was_active.get(network_id, false):
			was_active[network_id] = false
			on_elimination(network_id)
	for node in tracked:
		if is_instance_valid(node):
			frame.nodes[node] = [node.transform, node.visible]
	frames.append(frame)
	while not frames.is_empty() and frames[0].t < clock - BEFORE - AFTER - 0.5:
		frames.pop_front()

func on_elimination(network_id: int):
	var event_time: float = clock
	var speed: float = runner_speed(network_id)
	await get_tree().create_timer(AFTER, false).timeout
	if not is_inside_tree():
		return
	var clip: Array = frames.filter(func(f): return f.t >= event_time - BEFORE and f.t <= event_time + AFTER)
	if clip.size() < 10:
		return
	# the last elimination of the game gets a bonus: it is the one that decided it
	# where it happened: the camera aims there and does not follow the body down into the void
	var focus_at: Vector3 = Vector3.ZERO
	for f in clip:
		if f.t <= event_time and f.runners.has(network_id):
			focus_at = f.runners[network_id][0]
	clips[network_id] = {"frames": clip, "score": speed + event_time * 0.02, "time": event_time, "focus": focus_at}

func runner_speed(network_id: int) -> float:
	var recent: Array = frames.filter(func(f): return f.t >= clock - 0.4 and f.runners.has(network_id))
	if recent.size() < 2:
		return 0.0
	var a: Vector3 = recent.front().runners[network_id][0]
	var b: Vector3 = recent.back().runners[network_id][0]
	return a.distance_to(b) / max(recent.back().t - recent.front().t, 0.01)

## Host: the clip worth replaying, or -1.
func best_clip() -> int:
	var best: int = -1
	var best_score: float = -1.0
	for network_id in clips.keys():
		if clips[network_id].score > best_score:
			best_score = clips[network_id].score
			best = network_id
	return best

func duration() -> float:
	return (BEFORE + AFTER) / SPEED



func play(network_id: int):
	if not clips.has(network_id):
		return
	playing = clips[network_id].frames
	focus_id = network_id
	focus_at = clips[network_id].focus
	play_time = playing.front().t
	minigame.replaying = true

	for runner in minigame.players.values():
		if is_instance_valid(runner):
			runner.active = false
			runner.set_physics_process(false)
			if runner.multiplayer_synchronizer and runner.is_multiplayer_authority():
				runner.multiplayer_synchronizer.public_visibility = false
	for child in minigame.get_children():
		if child is Node3D and child.name.begins_with("Ghost"):
			child.visible = false

	camera_from = minigame.camera.global_transform
	camera_fov = minigame.camera.fov
	build_overlay()

func advance(delta: float):
	play_time += delta * SPEED
	var index: int = 0
	while index < playing.size() - 2 and playing[index + 1].t < play_time:
		index += 1
	var a: Dictionary = playing[index]
	var b: Dictionary = playing[min(index + 1, playing.size() - 1)]
	var w: float = clamp((play_time - a.t) / max(b.t - a.t, 0.0001), 0.0, 1.0)

	for network_id in a.runners.keys():
		var runner = minigame.players.get(network_id, null)
		if not is_instance_valid(runner) or not b.runners.has(network_id):
			continue
		var ra: Array = a.runners[network_id]
		var rb: Array = b.runners[network_id]
		runner.global_position = ra[0].lerp(rb[0], w)
		runner.visuals.rotation = Vector3(lerp_angle(ra[1].x, rb[1].x, w), lerp_angle(ra[1].y, rb[1].y, w), lerp_angle(ra[1].z, rb[1].z, w))
		runner.visuals.position = ra[2].lerp(rb[2], w)
		runner.visuals.scale = ra[3].lerp(rb[3], w)
		runner.visuals.visible = ra[4]
		runner.animation_tree.set("parameters/run_blend/blend_amount", lerpf(ra[5], rb[5], w))
		runner.animation_tree.set("parameters/falling_blend/blend_amount", lerpf(ra[6], rb[6], w))

	for node in a.nodes.keys():
		if not is_instance_valid(node) or not b.nodes.has(node):
			continue
		node.transform = a.nodes[node][0].interpolate_with(b.nodes[node][0], w)
		node.visible = a.nodes[node][1]

	# the camera closes in on the victim
	var focus = minigame.players.get(focus_id, null)
	if is_instance_valid(focus):
		var target: Vector3 = focus.global_position
		# follow the victim around the spot, never more than a few metres away from it
		target = focus_at + (target - focus_at).limit_length(2.5)
		target.y = max(target.y, focus_at.y - 1.0) + 1.0
		var progress: float = clamp((play_time - playing.front().t) / (BEFORE + AFTER), 0.0, 1.0)
		var eye: Vector3 = camera_from.origin.lerp(target + (camera_from.origin - target).normalized() * 10.0, smoothstep(0.0, 0.6, progress))
		minigame.camera.global_position = eye
		minigame.camera.look_at(target, Vector3.UP)
		minigame.camera.fov = lerpf(camera_fov, 50.0, smoothstep(0.0, 0.6, progress))
		minigame.camera_origin = eye

	if play_time >= playing.back().t:
		playing = []
		if overlay:
			overlay.queue_free()

func build_overlay():
	overlay = CanvasLayer.new()
	overlay.layer = 20
	add_child(overlay)
	for top in [true, false]:
		var bar := ColorRect.new()
		bar.color = Color.BLACK
		bar.position = Vector2(-10, -10 if top else 490)
		bar.size = Vector2(980, 60)
		overlay.add_child(bar)
	var label := Label.new()
	label.text = "REPLAY"
	label.position = Vector2(24, 12)
	label.add_theme_font_size_override("font_size", 22)
	label.add_theme_color_override("font_color", Color(1.0, 0.25, 0.15))
	overlay.add_child(label)
	var who := Label.new()
	who.text = minigame.player_name(focus_id) + " s'envole"
	who.position = Vector2(24, 500)
	who.add_theme_font_size_override("font_size", 16)
	who.add_theme_color_override("font_color", Color(0.95, 0.92, 0.85))
	overlay.add_child(who)
	var blink := label.create_tween().set_loops()
	blink.tween_property(label, "modulate:a", 0.2, 0.4)
	blink.tween_property(label, "modulate:a", 1.0, 0.4)
