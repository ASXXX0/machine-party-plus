extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LA FINALE: the last minigame of a custom or arcade party, points doubled. A round stage where everything comes
## back at once: two sweeper arms turn at the centre (jump over them), presses slam marked spots, and after a while
## the edge of the stage falls away. Last one standing wins.
##
## The server runs the arms and the presses; each peer checks arm hits for the runners it simulates (like
## LA BALAYEUSE), the server checks the press crushes.

const START_RADIUS: float = 11.0
const END_RADIUS: float = 6.0
const SHRINK_START: float = 45.0
const ARM_HALF_WIDTH: float = 0.75
const PRESS_RADIUS: float = 1.4
const PRESS_UP_Y: float = 12.0

var radius: float = START_RADIUS
var arm_angles: Array[float] = [0.0, PI]
var arm_speed: float = 0.7
var arms: Array[Node3D] = []
var floor_mesh: MeshInstance3D
var ring_mesh: MeshInstance3D
var floor_shape: CylinderShape3D
var sync_timer: float = 0.0
var press_timer: float = 6.0
var hit_timers: Dictionary[int, float]
var press_pool: Array[Node3D] = []

func spawn_points() -> Array[Vector3]:
	return [Vector3(-7, 0.1, 3), Vector3(7, 0.1, 3), Vector3(0, 0.1, 8), Vector3(-5, 0.1, -6), Vector3(5, 0.1, -6)]

func build_arena():

	max_duration = 120.0

	# if the playlist already had the finale, the party must not add a second one at the end
	var node: Node = get_parent()
	while node:
		if "session_minigame_list" in node:
			node.set_meta("mpplus_finale_played", true)
			break
		node = node.get_parent()

	set_camera(Vector3(0.0, 17.0, 19.0), Vector3(0.0, -1.0, 0.5))

	add_sound("ambience", "res://audio/ambience/industrial-machine-cycle_loop.ogg", -6.0, true)
	add_sound("warn", "res://audio/sfx/burn_recycle/beep.ogg", -6.0)
	add_sound("slam", "res://audio/sfx/manufacture_gun_drop_gear.ogg", 0.0)
	add_sound("hit", "res://audio/unique/disco dodge/dd fall scream impact.ogg", -4.0)
	add_sound("crumble", "res://audio/sfx/bad_explosion.ogg", -6.0)

	# the collar race hangar, a stage it never had
	var hall_scene: PackedScene = load("res://minigames/exploding_collar_race/models/collar race level mesh3/collar race level mesh3.glb")
	if hall_scene:
		var hall: Node3D = hall_scene.instantiate()
		hall.position = Vector3(0.0, -13.0, -30.0)
		arena.add_child(hall)

	var body := StaticBody3D.new()
	arena.add_child(body)
	var shape := CollisionShape3D.new()
	floor_shape = CylinderShape3D.new()
	floor_shape.radius = START_RADIUS
	floor_shape.height = 1.0
	shape.shape = floor_shape
	shape.position = Vector3(0.0, -0.5, 0.0)
	body.add_child(shape)

	floor_mesh = MeshInstance3D.new()
	var disc := CylinderMesh.new()
	disc.top_radius = 1.0
	disc.bottom_radius = 1.0
	disc.height = 1.0
	disc.radial_segments = 48
	floor_mesh.mesh = disc
	var floor_material: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_MARKED, Color(1.0, 0.95, 0.9), 0.5)
	floor_material.uv1_offset = Vector3.ONE * 0.5
	floor_mesh.material_override = floor_material
	floor_mesh.position = Vector3(0.0, -0.5, 0.0)
	arena.add_child(floor_mesh)

	ring_mesh = MeshInstance3D.new()
	var ring := CylinderMesh.new()
	ring.top_radius = 1.0
	ring.bottom_radius = 1.0
	ring.height = 1.0
	ring.radial_segments = 48
	ring_mesh.mesh = ring
	ring_mesh.material_override = DA.kind_material("mp_hazard")
	ring_mesh.position = Vector3(0.0, -0.53, 0.0)
	arena.add_child(ring_mesh)
	apply_radius()

	var hub: Node3D = DA.load_model("sweeper_hub.glb")
	arena.add_child(hub)
	for i in 2:
		var arm_root := Node3D.new()
		arena.add_child(arm_root)
		arm_root.add_child(DA.load_model("sweeper_arm.glb"))
		arms.append(arm_root)

	var key := OmniLight3D.new()
	key.position = Vector3(0.0, 11.0, 4.0)
	key.light_color = Color(0.56, 0.545, 0.485)
	key.light_energy = 80.0
	key.omni_range = 45.0
	key.shadow_enabled = true
	arena.add_child(key)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0.0, 22.0, 24.0)
	fill.light_color = Color(0.56, 0.545, 0.485)
	fill.light_energy = 20.0
	fill.omni_range = 400.0
	arena.add_child(fill)
	for side in [-1.0, 1.0]:
		var rim := OmniLight3D.new()
		rim.position = Vector3(side * 16.0, 6.0, -10.0)
		rim.light_color = Color(1.0, 0.5, 0.2)
		rim.light_energy = 25.0
		rim.omni_range = 26.0
		arena.add_child(rim)

	update_arms()

func apply_radius():
	floor_mesh.scale = Vector3(radius, 1.0, radius)
	ring_mesh.scale = Vector3(radius + 0.35, 1.0, radius + 0.35)
	floor_shape.radius = radius

func update_arms():
	for i in arms.size():
		arms[i].rotation.y = arm_angles[i]

func on_play_start_local():
	fade_in_ambience()
	set_countdown_mesage_rpc("POINTS DOUBLES !", 1.2)

## Points are doubled: the party's final word.
func compute_scores() -> Dictionary[int, int]:
	var scores: Dictionary[int, int] = super.compute_scores()
	for network_id in scores.keys():
		scores[network_id] *= 2
	return scores

func server_tick(delta: float):

	arm_speed = min(0.7 + play_time * 0.025, 2.6)

	if play_time > SHRINK_START and radius > END_RADIUS:
		var before: int = int(radius)
		radius = max(radius - 0.12 * delta, END_RADIUS)
		if int(radius) != before:
			sound_rpc.rpc("crumble")

	press_timer -= delta
	if press_timer <= 0.0:
		press_timer = max(3.6 - play_time * 0.02, 2.0)
		var count: int = clampi(2 + int(play_time / 25.0), 2, 5)
		var spots: Array = []
		for i in count:
			var angle: float = randf() * TAU
			var dist: float = sqrt(randf()) * (radius - 1.0)
			spots.append(Vector3(cos(angle) * dist, 0.0, sin(angle) * dist))
		slam_sequence(spots)

	sync_timer -= delta
	if sync_timer <= 0.0:
		sync_timer = 0.1
		sync_rpc.rpc(arm_angles, arm_speed, radius)

func visual_tick(delta: float):
	if not running:
		return
	arm_angles[0] = wrapf(arm_angles[0] + arm_speed * delta, - PI, PI)
	arm_angles[1] = wrapf(arm_angles[0] + PI, - PI, PI)
	update_arms()
	apply_radius()
	check_arm_hits(delta)

func check_arm_hits(delta: float):

	for network_id in hit_timers.keys():
		hit_timers[network_id] = max(hit_timers[network_id] - delta, 0.0)

	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active or not player.is_physics_processing():
			continue
		if hit_timers.get(network_id, 0.0) > 0.0:
			continue
		# a well-timed jump clears the arms
		if player.global_position.y > 0.55:
			continue
		var flat := Vector3(player.global_position.x, 0.0, player.global_position.z)
		if flat.length() < 0.8 or flat.length() > 9.8:
			continue
		for angle in arm_angles:
			var arm_dir := Vector3(cos(angle), 0.0, - sin(angle))
			if flat.dot(arm_dir) < 0.0 or abs(flat.cross(arm_dir).y) > ARM_HALF_WIDTH:
				continue
			var tangent := Vector3(- sin(angle), 0.0, - cos(angle))
			var fling := (tangent + flat.normalized() * 0.6).normalized()
			hit_timers[network_id] = 0.7
			player.shoved_rpc.rpc(flat - tangent, player.global_position, fling)
			player.shove_velocity += fling * (13.0 + arm_speed * 3.0)
			sound_rpc.rpc("hit")
			break

func slam_sequence(spots: Array):
	warn_rpc.rpc(spots)
	await get_tree().create_timer(1.5, false).timeout
	if game_end or not is_inside_tree():
		return
	slam_rpc.rpc(spots)
	await get_tree().create_timer(0.12, false).timeout
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		for spot in spots:
			var flat := Vector3(player.global_position.x - spot.x, 0.0, player.global_position.z - spot.z)
			if flat.length() < PRESS_RADIUS and player.global_position.y < 1.6:
				crush(network_id)
				break



@rpc("authority", "call_remote", "unreliable_ordered")
func sync_rpc(_angles: Array, _speed: float, _radius: float):
	arm_angles[0] = lerp_angle(arm_angles[0], _angles[0], 0.5)
	arm_angles[1] = wrapf(arm_angles[0] + PI, - PI, PI)
	arm_speed = _speed
	radius = _radius

@rpc("authority", "call_local", "reliable")
func warn_rpc(spots: Array):
	play_sound("warn")
	for spot in spots:
		var marker := MeshInstance3D.new()
		var ring := TorusMesh.new()
		ring.inner_radius = PRESS_RADIUS - 0.2
		ring.outer_radius = PRESS_RADIUS
		marker.mesh = ring
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.albedo_color = Color(1.0, 0.1, 0.05)
		marker.material_override = m
		marker.scale = Vector3(1.0, 0.1, 1.0)
		marker.position = spot + Vector3(0.0, 0.03, 0.0)
		arena.add_child(marker)
		var blink := marker.create_tween().set_loops(7)
		blink.tween_callback(func(): marker.visible = not marker.visible)
		blink.tween_interval(0.2)
		get_tree().create_timer(1.6, false).timeout.connect(marker.queue_free)

		var press: Node3D = take_press()
		press.position = spot + Vector3(0.0, PRESS_UP_Y + 6.0, 0.0)
		press.visible = true
		var lower := press.create_tween()
		lower.tween_property(press, "position:y", PRESS_UP_Y, 1.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

func take_press() -> Node3D:
	for press in press_pool:
		if not press.visible:
			return press
	var press: Node3D = DA.load_model("press_head.glb")
	arena.add_child(press)
	press_pool.append(press)
	return press

@rpc("authority", "call_local", "reliable")
func slam_rpc(spots: Array):
	play_sound("slam")
	shake = min(shake + 0.5, 1.2)
	for spot in spots:
		for press in press_pool:
			if not press.visible or Vector2(press.position.x - spot.x, press.position.z - spot.z).length() > 0.05:
				continue
			var t := press.create_tween()
			t.tween_property(press, "position:y", 1.25, 0.1).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
			t.tween_interval(0.5)
			t.tween_property(press, "position:y", PRESS_UP_Y + 8.0, 0.7).set_trans(Tween.TRANS_SINE)
			t.tween_callback(func(): press.visible = false)
			break

@rpc("any_peer", "call_local", "unreliable")
func sound_rpc(key: String):
	play_sound(key)
