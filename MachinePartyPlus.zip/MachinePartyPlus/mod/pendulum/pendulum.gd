extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LES PENDULES: a narrow catwalk between two loading docks, four wrecking balls swinging across it. Each dock
## has a big button: touch the one on the far side to score, then run back for the other one. A ball that hits
## you throws you off the catwalk; you climb back on your starting dock a moment later. The balls speed up.
## Most points when the clock runs out wins.
##
## The swing is a pure function of the play time, so every peer moves the balls on its own clock.

const BRIDGE_HALF: float = 9.0
const BRIDGE_WIDTH: float = 2.6
const DOCK: Vector3 = Vector3(3.6, 0.6, 5.0)
const PIVOT_Y: float = 8.0
const ROPE: float = 6.6
const BALL_RADIUS: float = 0.85
const BALL_X: Array[float] = [-6.0, -2.0, 2.0, 6.0]
const PHASES: Array[float] = [0.0, 1.7, 3.1, 4.6]

var balls: Array[Node3D] = []
var ropes: Array[MeshInstance3D] = []
var buttons: Array[Node3D] = []
# network id -> side it must reach next (-1 left dock, 1 right dock)
var target_side: Dictionary = {}
var arrows: Dictionary = {}
var hit_timers: Dictionary = {}

func spawn_points() -> Array[Vector3]:
	return [Vector3(-11.0, 0.1, -1.6), Vector3(-11.0, 0.1, 0.0), Vector3(-11.0, 0.1, 1.6), Vector3(-12.2, 0.1, -0.8), Vector3(-12.2, 0.1, 0.8)]

func spawn_yaw(_index: int) -> float:
	return - PI * 0.5

func fall_height() -> float:
	# nobody is eliminated here: falling sends you back to your dock
	return -40.0

func build_arena():

	max_duration = 75.0
	set_camera(Vector3(0.0, 15.0, 19.5), Vector3(0.0, -0.5, 0.0))

	add_sound("ambience", "res://audio/unique/chisel gauntlet/machine ambience.ogg", -8.0, true)
	add_sound("whoosh", "res://audio/sfx/escalator_pit_wind.ogg", -10.0)
	add_sound("hit", "res://audio/unique/disco dodge/dd fall scream impact.ogg", -2.0)
	add_sound("button", "res://audio/unique/chisel gauntlet/press_button_submit.ogg", 0.0)

	# the catwalk crosses the atrium high above the Knife at the Office floors
	add_backdrop_model("res://minigames/knife_at_the_office/models/kato office art1/kato office art1.glb", Vector3(0.0, -18.0, 0.0))

	var deck: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_HAZARD, Color(0.95, 0.93, 0.9), 0.3)
	add_box(Vector3(BRIDGE_HALF * 2.0, 0.4, BRIDGE_WIDTH), Vector3(0.0, -0.2, 0.0), deck)
	for side in [-1.0, 1.0]:
		add_box(Vector3(BRIDGE_HALF * 2.0, 0.08, 0.08), Vector3(0.0, 0.0, side * BRIDGE_WIDTH * 0.5), DA.kind_material("mp_hazard"), null, false)
		var dock_center := Vector3(side * (BRIDGE_HALF + DOCK.x * 0.5), - DOCK.y * 0.5, 0.0)
		add_box(DOCK, dock_center, DA.base_material(DA.TEX_FLOOR_MARKED, Color(1.0, 0.95, 0.9), 0.5))
		# fences around the docks: the only way to the other side is the catwalk
		add_box(Vector3(0.25, 1.0, DOCK.z), Vector3(side * (BRIDGE_HALF + DOCK.x + 0.12), 0.5, 0.0), DA.kind_material("mp_hazard"))
		for z_side in [-1.0, 1.0]:
			add_box(Vector3(DOCK.x, 1.0, 0.25), Vector3(dock_center.x, 0.5, z_side * (DOCK.z * 0.5 + 0.12)), DA.kind_material("mp_hazard"))
		var button := Node3D.new()
		button.position = Vector3(side * (BRIDGE_HALF + DOCK.x - 0.9), 0.0, 0.0)
		arena.add_child(button)
		var plate := MeshInstance3D.new()
		var plate_mesh := CylinderMesh.new()
		plate_mesh.top_radius = 0.75
		plate_mesh.bottom_radius = 0.85
		plate_mesh.height = 0.2
		plate.mesh = plate_mesh
		plate.material_override = DA.kind_material("mp_light")
		plate.position.y = 0.1
		button.add_child(plate)
		var lamp := OmniLight3D.new()
		lamp.light_color = Color(1.0, 0.4, 0.1)
		lamp.light_energy = 3.0
		lamp.omni_range = 4.0
		lamp.position.y = 1.2
		button.add_child(lamp)
		buttons.append(button)

	# the gantry the balls hang from
	add_box(Vector3(BRIDGE_HALF * 2.0 - 2.0, 0.5, 0.6), Vector3(0.0, PIVOT_Y + 0.25, 0.0), DA.kind_material("mp_hazard"), null, false)
	for side in [-1.0, 1.0]:
		add_box(Vector3(0.6, PIVOT_Y + 8.0, 0.6), Vector3(side * (BRIDGE_HALF - 1.0), PIVOT_Y - 4.0, 0.0), DA.kind_material("mp_dark"), null, false)

	for i in BALL_X.size():
		var ball := Node3D.new()
		arena.add_child(ball)
		var sphere := MeshInstance3D.new()
		var sphere_mesh := SphereMesh.new()
		sphere_mesh.radius = BALL_RADIUS
		sphere_mesh.height = BALL_RADIUS * 2.0
		sphere.mesh = sphere_mesh
		sphere.material_override = DA.kind_material("mp_dark")
		ball.add_child(sphere)
		var band := MeshInstance3D.new()
		var band_mesh := TorusMesh.new()
		band_mesh.inner_radius = BALL_RADIUS - 0.05
		band_mesh.outer_radius = BALL_RADIUS + 0.08
		band.mesh = band_mesh
		band.material_override = DA.kind_material("mp_hazard")
		ball.add_child(band)
		balls.append(ball)
		var rope := MeshInstance3D.new()
		var rope_mesh := CylinderMesh.new()
		rope_mesh.top_radius = 0.06
		rope_mesh.bottom_radius = 0.06
		rope_mesh.height = 1.0
		rope.mesh = rope_mesh
		rope.material_override = DA.kind_material("mp_rubber")
		arena.add_child(rope)
		ropes.append(rope)
	place_balls(0.8)

	add_key_lights(Vector3(0.0, 13.0, 3.0), 100.0, 30.0)
	add_light(Vector3(0.0, -8.0, -10.0), Color(0.56, 0.545, 0.485), 40.0, 40.0)
	add_light(Vector3(0.0, -6.0, 0.0), Color(1.0, 0.4, 0.15), 15.0, 20.0)

func swing_angle(i: int, t: float) -> float:
	var speed: float = 1.6 + min(t * 0.012, 0.9)
	var amplitude: float = deg_to_rad(52.0)
	return amplitude * sin(t * speed + PHASES[i])

func ball_position(i: int, t: float) -> Vector3:
	var a: float = swing_angle(i, t)
	return Vector3(BALL_X[i], PIVOT_Y - ROPE * cos(a), ROPE * sin(a))

func place_balls(t: float):
	for i in balls.size():
		var pos: Vector3 = ball_position(i, t)
		balls[i].position = pos
		balls[i].rotation.x = swing_angle(i, t)
		var pivot := Vector3(BALL_X[i], PIVOT_Y, 0.0)
		ropes[i].position = (pivot + pos) * 0.5
		ropes[i].scale = Vector3(1.0, ROPE - BALL_RADIUS * 0.5, 1.0)
		ropes[i].rotation.x = - swing_angle(i, t)

func on_play_start_local():
	fade_in_ambience()
	build_hud(true)
	for network_id in players.keys():
		target_side[network_id] = 1
		var arrow := Label3D.new()
		arrow.text = ">>"
		arrow.font_size = 64
		arrow.pixel_size = 0.006
		arrow.outline_size = 12
		arrow.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		arrow.no_depth_test = true
		arrow.modulate = seat_color(network_id)
		arrow.position = Vector3(0.0, 2.6, 0.0)
		players[network_id].add_child(arrow)
		arrows[network_id] = arrow

func server_tick(_delta: float):
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		var side: int = target_side.get(network_id, 1)
		var button: Vector3 = buttons[0 if side < 0 else 1].position
		if Vector2(player.global_position.x - button.x, player.global_position.z - button.z).length() < 1.0:
			add_points(network_id)
			sfx_rpc.rpc("button")
			side_rpc.rpc(network_id, - side)

@rpc("authority", "call_local", "reliable")
func side_rpc(network_id: int, side: int):
	target_side[network_id] = side
	if arrows.has(network_id):
		arrows[network_id].text = ">>" if side > 0 else "<<"

func visual_tick(delta: float):

	place_balls(play_time if running else 0.8)

	if not running:
		return

	for player in local_runners():
		var network_id: int = player.player_presence.network_id
		# off the catwalk: back to the dock you are heading away from
		if player.global_position.y < -4.0:
			var side: int = target_side.get(network_id, 1)
			player.global_position = Vector3(- side * (BRIDGE_HALF + DOCK.x * 0.5), 0.3, randf_range(-1.5, 1.5))
			player.velocity = Vector3.ZERO
			player.shove_velocity = Vector3.ZERO
			continue
		hit_timers[network_id] = max(hit_timers.get(network_id, 0.0) - delta, 0.0)
		if hit_timers[network_id] > 0.0:
			continue
		for i in balls.size():
			var ball: Vector3 = balls[i].position
			var to_player: Vector3 = player.global_position + Vector3(0.0, 0.9, 0.0) - ball
			if to_player.length() < BALL_RADIUS + 0.55:
				hit_timers[network_id] = 1.0
				sfx_rpc.rpc("hit")
				# thrown along the swing
				var swing_dir: float = sign(cos(play_time * (1.6 + min(play_time * 0.012, 0.9)) + PHASES[i]))
				push_runner(player, Vector3(0.0, 0.0, swing_dir), 18.0)
				break

func compute_scores() -> Dictionary[int, int]:
	return rank_scores(points)

func check_game_end_on_death():
	pass
