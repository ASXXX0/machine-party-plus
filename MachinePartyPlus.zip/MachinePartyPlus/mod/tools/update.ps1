﻿# Machine Party+ : mise à jour lancée depuis le jeu.
# Attend la fermeture du jeu, télécharge la nouvelle version (vérifiée par SHA-256), lance son installateur,
# puis relance le jeu par Steam.

param(
	[Parameter(Mandatory = $true)][string]$ZipUrl,
	[Parameter(Mandatory = $true)][string]$Sha256,
	[string]$GameDir = "",
	[int]$WaitPid = 0
)

$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "Machine Party+ : mise à jour"

function Fail([string]$message) {
	Write-Host ""
	Write-Host "ERREUR : $message" -ForegroundColor Red
	Read-Host "Appuie sur Entrée pour fermer"
	exit 1
}

Write-Host ""
Write-Host "=== Machine Party+ : mise à jour ===" -ForegroundColor Cyan
if ($WaitPid -gt 0) {
	Write-Host "Attente de la fermeture du jeu..."
	try { Wait-Process -Id $WaitPid -Timeout 30 -ErrorAction SilentlyContinue } catch {}
}

$work = Join-Path $env:TEMP "MachinePartyPlus\update"
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory -Force -Path $work | Out-Null
$zip = Join-Path $work "package.zip"

Write-Host "Téléchargement de la nouvelle version..."
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = "SilentlyContinue"
try { Invoke-WebRequest -Uri $ZipUrl -OutFile $zip -UseBasicParsing }
catch { Fail "téléchargement impossible : $($_.Exception.Message)" }
if ((Get-FileHash $zip -Algorithm SHA256).Hash -ne $Sha256.ToUpper()) {
	Fail "le fichier téléchargé ne correspond pas à la version publiée (SHA-256)."
}

Expand-Archive -Path $zip -DestinationPath $work -Force
$installer = Get-ChildItem -Path $work -Recurse -Filter "install.ps1" | Select-Object -First 1
if (-not $installer) { Fail "install.ps1 introuvable dans la nouvelle version." }

& $installer.FullName -GameDir $GameDir -NoPause
if ($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne $null) { exit $LASTEXITCODE }

Write-Host "Relance du jeu..." -ForegroundColor Green
Start-Process "steam://rungameid/4108000"
Start-Sleep -Seconds 3
