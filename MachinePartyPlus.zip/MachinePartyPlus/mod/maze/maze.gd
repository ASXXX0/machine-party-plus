extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LABYRINTHE MOBILE: a maze of steel partitions in the server room. Every few seconds some partitions sink into
## the floor and others rise, so the way out keeps changing. One of the four gates is open (green); the first
## out scores 3, the second 2, the third 1. Then everyone is brought back to the middle, the maze reshuffles and
## another gate opens. Four rounds; most points wins.
##
## The maze is built from a seed every peer gets, the host decides which partitions move.

const N: int = 9
const CELL: float = 1.8
const WALL_H: float = 1.5
const ROUNDS: int = 4
const ROUND_TIME: float = 28.0
const GATES: Array[Vector2i] = [Vector2i(4, -1), Vector2i(9, 4), Vector2i(4, 9), Vector2i(-1, 4)]

var walls: Dictionary = {}
var raised: Dictionary = {}
var gate_doors: Array[Node3D] = []
var gate_lamps: Array[OmniLight3D] = []
var open_gate: int = -1
var maze_round: int = 0
var round_timer: float = 0.0
var shift_timer: float = 4.0
var out_players: Array = []
var mat_wall: Material
var mat_top: Material

func spawn_points() -> Array[Vector3]:
	return [cell_pos(Vector2i(4, 4)) + Vector3(-0.4, 0.1, -0.4), cell_pos(Vector2i(4, 4)) + Vector3(0.4, 0.1, -0.4),
		cell_pos(Vector2i(4, 4)) + Vector3(0.4, 0.1, 0.4), cell_pos(Vector2i(4, 4)) + Vector3(-0.4, 0.1, 0.4), cell_pos(Vector2i(4, 4)) + Vector3(0, 0.1, 0)]

func cell_pos(cell: Vector2i) -> Vector3:
	var offset: float = (N - 1) * CELL * 0.5
	return Vector3(cell.x * CELL - offset, 0.0, cell.y * CELL - offset)

## Edge keys: "h:c:r" is the wall on the north side of cell (c, r) (r = N is the south border);
## "v:c:r" is the wall on the west side of cell (c, r) (c = N is the east border).
func build_arena():

	max_duration = ROUNDS * ROUND_TIME + 10.0
	set_camera(Vector3(0.0, 21.0, 9.5), Vector3(0.0, -1.0, 0.8))

	add_sound("ambience", "res://audio/unique/chisel gauntlet/tv_background_hum.ogg", -6.0, true)
	add_sound("shift", "res://audio/unique/intermission/intermission servo3.ogg", -4.0)
	add_sound("gate", "res://audio/sfx/airplane ding.ogg", -2.0)
	add_sound("out", "res://audio/sfx/manufacture_gun_correct_item_inserted.ogg", -2.0)

	var rack_scene: PackedScene = load("res://minigames/intermission_new/models/intermission server rack temp1/intermission server rack temp1.glb")
	if rack_scene:
		for k in 8:
			var rack: Node3D = rack_scene.instantiate()
			var angle: float = k * TAU / 8.0
			rack.position = Vector3(cos(angle), 0.0, sin(angle)) * 14.0 + Vector3(0.0, -0.1, 0.0)
			rack.rotation.y = - angle + PI * 0.5
			arena.add_child(rack)

	mat_wall = DA.kind_material("mp_metal")
	mat_top = DA.kind_material("mp_hazard")
	var size: float = N * CELL
	add_box(Vector3(size + 6.0, 0.6, size + 6.0), Vector3(0.0, -0.3, 0.0), DA.base_material(DA.TEX_FLOOR_MARKED, Color(0.9, 0.9, 0.92), 0.5))

	for r in N + 1:
		for c in N:
			make_wall("h:%d:%d" % [c, r], cell_pos(Vector2i(c, r)) - Vector3(0.0, 0.0, CELL * 0.5), true)
	for r in N:
		for c in N + 1:
			make_wall("v:%d:%d" % [c, r], cell_pos(Vector2i(c, r)) - Vector3(CELL * 0.5, 0.0, 0.0), false)

	for i in GATES.size():
		var lamp := OmniLight3D.new()
		lamp.position = gate_position(i) + Vector3(0.0, 2.2, 0.0)
		lamp.light_color = Color(1.0, 0.2, 0.1)
		lamp.light_energy = 3.0
		lamp.omni_range = 4.0
		arena.add_child(lamp)
		gate_lamps.append(lamp)

	add_key_lights(Vector3(0.0, 13.0, 1.0), 70.0, 18.0)
	build_maze(9171)

func gate_key(i: int) -> String:
	match i:
		0: return "h:4:0"
		1: return "v:9:4"
		2: return "h:4:9"
		_: return "v:0:4"

func gate_position(i: int) -> Vector3:
	return walls[gate_key(i)].position

func make_wall(key: String, position: Vector3, horizontal: bool):
	var body := StaticBody3D.new()
	body.position = position
	arena.add_child(body)
	var size := Vector3(CELL + 0.2, WALL_H, 0.25) if horizontal else Vector3(0.25, WALL_H, CELL + 0.2)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	shape.position.y = WALL_H * 0.5
	body.add_child(shape)
	var mesh := MeshInstance3D.new()
	var box_mesh := BoxMesh.new()
	box_mesh.size = size
	mesh.mesh = box_mesh
	mesh.material_override = mat_wall
	mesh.position.y = WALL_H * 0.5
	body.add_child(mesh)
	var top := MeshInstance3D.new()
	var top_mesh := BoxMesh.new()
	top_mesh.size = Vector3(size.x + 0.02, 0.12, size.z + 0.02)
	top.mesh = top_mesh
	top.material_override = mat_top
	top.position.y = WALL_H
	body.add_child(top)
	walls[key] = body
	raised[key] = true

func is_border(key: String) -> bool:
	var parts: PackedStringArray = key.split(":")
	var c: int = int(parts[1])
	var r: int = int(parts[2])
	return (parts[0] == "h" and (r == 0 or r == N)) or (parts[0] == "v" and (c == 0 or c == N))

## A perfect maze (randomized depth-first), then a few extra openings so there are loops.
func build_maze(seed_value: int):
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var visited: Dictionary = {}
	var stack: Array[Vector2i] = [Vector2i(4, 4)]
	visited[Vector2i(4, 4)] = true
	var wanted: Dictionary = {}
	for key in walls.keys():
		wanted[key] = true
	while not stack.is_empty():
		var cell: Vector2i = stack.back()
		var options: Array = []
		for step in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var next: Vector2i = cell + step
			if next.x >= 0 and next.x < N and next.y >= 0 and next.y < N and not visited.has(next):
				options.append(next)
		if options.is_empty():
			stack.pop_back()
			continue
		var next: Vector2i = options[rng.randi() % options.size()]
		wanted[edge_between(cell, next)] = false
		visited[next] = true
		stack.append(next)
	for key in wanted.keys():
		if not is_border(key) and wanted[key] and rng.randf() < 0.22:
			wanted[key] = false
	for key in wanted.keys():
		set_wall(key, wanted[key], false)

func edge_between(a: Vector2i, b: Vector2i) -> String:
	if a.x != b.x:
		return "v:%d:%d" % [max(a.x, b.x), a.y]
	return "h:%d:%d" % [a.x, max(a.y, b.y)]

func set_wall(key: String, up: bool, animate: bool):
	if raised.get(key, false) == up and animate:
		return
	raised[key] = up
	var body: StaticBody3D = walls[key]
	(body.get_child(0) as CollisionShape3D).set_deferred("disabled", not up)
	var target: float = 0.0 if up else - WALL_H - 0.15
	if animate:
		body.create_tween().tween_property(body, "position:y", target, 0.6).set_trans(Tween.TRANS_SINE)
	else:
		body.position.y = target

func on_play_start_local():
	fade_in_ambience()
	build_hud(true)

func on_server_play_start():
	start_round()

func start_round():
	maze_round += 1
	if maze_round > ROUNDS:
		end_game()
		return
	out_players.clear()
	round_timer = ROUND_TIME
	var points_at: Array = spawn_points()
	var k: int = 0
	for network_id in players.keys():
		var player = players[network_id]
		if not is_instance_valid(player):
			continue
		player.teleport_rpc.rpc(points_at[k % points_at.size()])
		player.set_active_rpc.rpc(true)
		k += 1
	round_rpc.rpc(maze_round, randi(), randi() % GATES.size())

@rpc("authority", "call_local", "reliable")
func round_rpc(number: int, seed_value: int, gate: int):
	play_sound("gate")
	set_countdown_mesage_rpc("MANCHE %d / %d" % [number, ROUNDS], 1.0)
	build_maze(seed_value)
	open_gate = gate
	for i in GATES.size():
		var open: bool = i == gate
		set_wall(gate_key(i), not open, true)
		gate_lamps[i].light_color = Color(0.2, 1.0, 0.3) if open else Color(1.0, 0.2, 0.1)
		gate_lamps[i].light_energy = 6.0 if open else 2.0

func server_tick(delta: float):

	if maze_round < 1 or maze_round > ROUNDS:
		return

	round_timer -= delta
	shift_timer -= delta
	if shift_timer <= 0.0:
		shift_timer = max(4.5 - maze_round * 0.5, 2.5)
		var interior: Array = walls.keys().filter(func(k): return not is_border(k))
		var keys: Array = []
		var ups: Array = []
		for i in 8:
			var key: String = interior.pick_random()
			# never wall someone in place: skip partitions with a runner right next to them
			if near_runner(walls[key].position):
				continue
			keys.append(key)
			ups.append(not raised[key])
		shift_rpc.rpc(keys, ups)

	var size: float = N * CELL * 0.5
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active or out_players.has(network_id):
			continue
		var p: Vector3 = player.global_position
		if abs(p.x) > size + 0.3 or abs(p.z) > size + 0.3:
			out_players.append(network_id)
			add_points(network_id, max(3 - (out_players.size() - 1), 0))
			sfx_rpc.rpc("out")

	if round_timer <= 0.0 or out_players.size() >= active_players.size():
		start_round()

func near_runner(position: Vector3) -> bool:
	for player in active_players.values():
		if is_instance_valid(player) and Vector2(player.global_position.x - position.x, player.global_position.z - position.z).length() < 1.0:
			return true
	return false

@rpc("authority", "call_local", "reliable")
func shift_rpc(keys: Array, ups: Array):
	play_sound("shift")
	for i in keys.size():
		set_wall(keys[i], ups[i], true)

func compute_scores() -> Dictionary[int, int]:
	return rank_scores(points)

func check_game_end_on_death():
	pass
