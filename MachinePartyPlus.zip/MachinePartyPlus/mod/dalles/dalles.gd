extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## DALLES ELECTRIQUES: the floor is a grid of power panels. In waves, panels flash amber, then go live for a moment:
## whoever stands on a live panel is fried. Keep moving. The waves get bigger and the warning shorter, and late
## in the game some panels stay live for good. Last one standing wins.

const N: int = 8
const TILE: float = 1.8

var panels: Array[MeshInstance3D] = []
var materials: Array[StandardMaterial3D] = []
var state: PackedInt32Array = PackedInt32Array()
var wave_timer: float = 2.5
var dead_panels: Array = []

enum Plate { OFF, WARN, LIVE, DEAD }

func spawn_points() -> Array[Vector3]:
	return [panel_center(9), panel_center(14), panel_center(49), panel_center(54), panel_center(27)]

func panel_center(index: int) -> Vector3:
	var offset: float = (N - 1) * TILE * 0.5
	return Vector3((index % N) * TILE - offset, 0.1, (index / N) * TILE - offset)

func panel_at(position: Vector3) -> int:
	var offset: float = (N - 1) * TILE * 0.5
	var col: int = roundi((position.x + offset) / TILE)
	var row: int = roundi((position.z + offset) / TILE)
	if col < 0 or col >= N or row < 0 or row >= N:
		return -1
	return row * N + col

func build_arena():
	max_duration = 120.0
	set_camera(Vector3(0.0, 15.5, 12.5), Vector3(0.0, -0.8, 0.6))
	add_sound("ambience", "res://audio/unique/chisel gauntlet/tv_background_hum.ogg", -6.0, true)
	add_sound("warn", "res://audio/sfx/burn_recycle/beep.ogg", -8.0)
	add_sound("live", "res://audio/sfx/collar_activate.ogg", -2.0)
	add_sound("zap", "res://audio/sfx/bad_explosion.ogg", -4.0)
	add_backdrop_model("res://minigames/intermission_new/models/intermission server rack temp1/intermission server rack temp1.glb", Vector3(-11.0, -0.2, -9.0), 30.0)
	add_backdrop_model("res://minigames/intermission_new/models/intermission server rack temp1/intermission server rack temp1.glb", Vector3(11.0, -0.2, -9.0), -30.0)

	var size: float = N * TILE
	add_box(Vector3(size + 0.6, 0.6, size + 0.6), Vector3(0, -0.32, 0), DA.kind_material("mp_dark"))
	var panel_mesh := BoxMesh.new()
	panel_mesh.size = Vector3(TILE - 0.12, 0.08, TILE - 0.12)
	state.resize(N * N)
	state.fill(Plate.OFF)
	for index in N * N:
		var panel := MeshInstance3D.new()
		panel.mesh = panel_mesh
		var m: StandardMaterial3D = DA.base_material(DA.TEX_STEEL, Color(0.75, 0.75, 0.78), 0.6)
		m.emission_enabled = true
		m.emission = Color.BLACK
		panel.material_override = m
		panel.position = panel_center(index) - Vector3(0, 0.06, 0)
		arena.add_child(panel)
		panels.append(panel)
		materials.append(m)
		# the copper studs that make it read as a power panel
		for corner in [Vector3(-1, 0, -1), Vector3(1, 0, -1), Vector3(1, 0, 1), Vector3(-1, 0, 1)]:
			var stud := MeshInstance3D.new()
			var stud_mesh := CylinderMesh.new()
			stud_mesh.top_radius = 0.07
			stud_mesh.bottom_radius = 0.07
			stud_mesh.height = 0.05
			stud.mesh = stud_mesh
			stud.material_override = DA.kind_material("mp_rod")
			stud.position = panel.position + corner * (TILE * 0.5 - 0.22) + Vector3(0, 0.05, 0)
			arena.add_child(stud)
	add_key_lights(Vector3(0.0, 12.0, 2.0), 70.0, 18.0)

	if Engine.has_meta("mpplus_preview"):
		for index in N * N:
			set_panel(index, [Plate.OFF, Plate.WARN, Plate.LIVE][index % 3])

func set_panel(index: int, value: int):
	state[index] = value
	var m: StandardMaterial3D = materials[index]
	match value:
		Plate.OFF:
			m.emission = Color.BLACK
			m.albedo_color = Color(0.75, 0.75, 0.78)
		Plate.WARN:
			m.emission = Color(1.0, 0.55, 0.05)
			m.emission_energy_multiplier = 1.2
		Plate.LIVE, Plate.DEAD:
			m.emission = Color(0.35, 0.7, 1.0)
			m.emission_energy_multiplier = 2.5
			m.albedo_color = Color(0.4, 0.6, 1.0)

func on_play_start_local():
	fade_in_ambience()

func server_tick(delta: float):
	# burnt-out panels stay live
	for network_id in active_players.keys():
		var player = active_players[network_id]
		if is_instance_valid(player) and player.active and player.global_position.y < 0.6:
			var index: int = panel_at(player.global_position)
			if index >= 0 and state[index] == Plate.DEAD:
				sfx_rpc.rpc("zap")
				crush(network_id)
	wave_timer -= delta
	if wave_timer > 0.0:
		return
	var warn_time: float = max(1.3 - play_time * 0.008, 0.6)
	var share: float = min(0.25 + play_time * 0.006, 0.6)
	var picked: Array = []
	for index in N * N:
		if state[index] == Plate.DEAD:
			continue
		# panels under someone are a little more likely: nobody gets to stand still
		var chance: float = share
		for player in active_players.values():
			if is_instance_valid(player) and panel_at(player.global_position) == index:
				chance += 0.25
		if randf() < chance:
			picked.append(index)
	# late game: a panel burns out for good
	var burnout: int = -1
	if play_time > 40.0 and randf() < 0.6:
		var candidates: Array = range(N * N).filter(func(i): return state[i] != Plate.DEAD)
		if candidates.size() > 10:
			burnout = candidates.pick_random()
	wave(picked, warn_time, burnout)
	wave_timer = warn_time + 1.4 + max(1.2 - play_time * 0.01, 0.4)

func wave(picked: Array, warn_time: float, burnout: int):
	warn_rpc.rpc(picked)
	await get_tree().create_timer(warn_time, false).timeout
	if game_end or not is_inside_tree():
		return
	live_rpc.rpc(picked, burnout)
	# fried: anyone on a live panel
	for check in 3:
		for network_id in active_players.keys():
			var player = active_players[network_id]
			if not is_instance_valid(player) or not player.active or player.global_position.y > 0.6:
				continue
			var index: int = panel_at(player.global_position)
			if index >= 0 and (picked.has(index) or state[index] == Plate.DEAD):
				sfx_rpc.rpc("zap")
				crush(network_id)
		await get_tree().create_timer(0.35, false).timeout
		if game_end or not is_inside_tree():
			return
	off_rpc.rpc(picked)

@rpc("authority", "call_local", "reliable")
func warn_rpc(picked: Array):
	play_sound("warn")
	for index in picked:
		if state[index] != Plate.DEAD:
			set_panel(index, Plate.WARN)

@rpc("authority", "call_local", "reliable")
func live_rpc(picked: Array, burnout: int):
	play_sound("live")
	shake = min(shake + 0.25, 1.0)
	for index in picked:
		if state[index] != Plate.DEAD:
			set_panel(index, Plate.LIVE)
	if burnout >= 0:
		set_panel(burnout, Plate.DEAD)

@rpc("authority", "call_local", "reliable")
func off_rpc(picked: Array):
	for index in picked:
		if state[index] == Plate.LIVE:
			set_panel(index, Plate.OFF)

func visual_tick(_delta: float):
	# live panels crackle
	var flicker: float = 2.0 + sin(Time.get_ticks_msec() / 30.0) * 0.8
	for index in N * N:
		if state[index] == Plate.LIVE or state[index] == Plate.DEAD:
			materials[index].emission_energy_multiplier = flicker
