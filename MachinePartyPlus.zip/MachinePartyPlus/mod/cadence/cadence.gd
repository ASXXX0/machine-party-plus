extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## CADENCE: rhythm on the line. Gear blanks ride each player's conveyor into a stamping press; hit the button
## as a blank passes under the stamp. Perfect = 2, good = 1. Stamping on nothing jams your press. The line
## speeds up; best score after the shift wins. Every lane gets the same blanks (one seed from the server);
## each owner judges its own timing locally and announces hits, like a rhythm game.

const SHIFT_TIME: float = 45.0
const LANE_SPACING: float = 3.2
const BELT_SPEED: float = 4.5
const STAMP_Z: float = 2.0
const SPAWN_Z: float = -6.0
const PERFECT: float = 0.07
const GOOD: float = 0.17
const JAM_TIME: float = 1.2
const POOL_SIZE: int = 8

var part_times: Array[float] = []
var lane_count: int = 0
var lane_points: Array[int] = []
var stamped: Array[Dictionary] = []
var jammed_until: Array[float] = []

var lanes: Array[Node3D] = []
var pools: Array[Array] = []
var heads: Array[Node3D] = []
var score_labels: Array[Label3D] = []
var judge_labels: Array[Label3D] = []
var lamps: Array[OmniLight3D] = []
var belt_materials: Array[StandardMaterial3D] = []
var part_template: Node3D

func lane_x(seat: int) -> float:
	return (seat - (lane_count - 1) * 0.5) * LANE_SPACING

func spawn_points() -> Array[Vector3]:
	var count: int = max(PlayerManager.player_presences.size(), 1)
	lane_count = count
	var points: Array[Vector3] = []
	for seat in count:
		points.append(Vector3(lane_x(seat) + 1.1, 0.05, STAMP_Z + 0.6))
	return points

func spawn_yaw(_index: int) -> float:
	return deg_to_rad(60.0)

func build_arena():

	max_duration = SHIFT_TIME + 6.0
	lane_count = max(PlayerManager.player_presences.size(), 4 if Engine.has_meta("mpplus_preview") else 1)

	set_camera(Vector3(0.0, 7.5, 11.0), Vector3(0.0, 0.6, -1.0))

	add_sound("ambience", "res://audio/ambience/manufacture_gun_ambience.ogg", -8.0, true)
	add_sound("stamp", "res://audio/sfx/manufacture_gun_drop_gear.ogg", -2.0)
	add_sound("perfect", "res://audio/sfx/manufacture_gun_correct_item_inserted.ogg", -4.0)
	add_sound("jam", "res://audio/sfx/manufacture_gun_wrong_insert_error.ogg", -2.0)
	add_sound("whistle", "res://audio/sfx/airplane ding.ogg", -2.0)

	# the brick workshop of Firearm Factory around the line
	var hall_scene: PackedScene = load("res://minigames/manufacture_gun/models/manufacture gun artwork pass2/manufacture gun artwork pass2.glb")
	if hall_scene:
		var hall: Node3D = hall_scene.instantiate()
		hall.position = Vector3(-38.0, 0.0, -16.0)
		arena.add_child(hall)

	var floor_body := StaticBody3D.new()
	arena.add_child(floor_body)
	var floor_shape := CollisionShape3D.new()
	var floor_box := BoxShape3D.new()
	floor_box.size = Vector3(40, 1, 30)
	floor_shape.shape = floor_box
	floor_shape.position = Vector3(0, -0.5, 0)
	floor_body.add_child(floor_shape)

	var floor_mesh := MeshInstance3D.new()
	var floor_plane := PlaneMesh.new()
	floor_plane.size = Vector2(30, 24)
	floor_mesh.mesh = floor_plane
	floor_mesh.material_override = DA.base_material(DA.TEX_STEEL, Color(0.75, 0.73, 0.7), 0.2)
	floor_mesh.position = Vector3(0, 0.005, 0)
	arena.add_child(floor_mesh)

	part_template = DA.load_model("part.glb")

	for seat in lane_count:
		var lane := Node3D.new()
		lane.position = Vector3(lane_x(seat), 0, 0)
		arena.add_child(lane)
		lanes.append(lane)

		var conveyor: Node3D = DA.load_model("conveyor.glb")
		lane.add_child(conveyor)
		var belt: StandardMaterial3D = DA.base_material(
			"res://minigames/burn_recycle/models/burn recycle visuals6/burn recycle visuals6_conveyor belt2.png", Color(0.8, 0.8, 0.8), 0.5)
		belt_materials.append(belt)
		set_belt_material(conveyor, belt)

		var frame: Node3D = DA.load_model("stamper_frame.glb")
		frame.position = Vector3(0, 0, STAMP_Z)
		lane.add_child(frame)
		var head: Node3D = DA.load_model("stamper_head.glb")
		head.position = Vector3(0, 3.0, STAMP_Z)
		lane.add_child(head)
		heads.append(head)

		var pool: Array = []
		for k in POOL_SIZE:
			var part: Node3D = part_template.duplicate()
			part.visible = false
			lane.add_child(part)
			pool.append(part)
		pools.append(pool)

		var score := Label3D.new()
		score.text = "0"
		score.font_size = 120
		score.pixel_size = 0.008
		score.outline_size = 20
		score.modulate = Color(1.0, 0.85, 0.4)
		score.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		score.position = Vector3(0, 4.6, STAMP_Z)
		lane.add_child(score)
		score_labels.append(score)

		var judge := Label3D.new()
		judge.text = ""
		judge.font_size = 72
		judge.pixel_size = 0.007
		judge.outline_size = 14
		judge.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		judge.position = Vector3(0, 2.4, STAMP_Z + 0.8)
		lane.add_child(judge)
		judge_labels.append(judge)

		var lamp := OmniLight3D.new()
		lamp.position = Vector3(-0.9, 3.0, STAMP_Z)
		lamp.light_color = Color(1.0, 0.5, 0.2)
		lamp.light_energy = 2.0
		lamp.omni_range = 4.5
		lane.add_child(lamp)
		lamps.append(lamp)

		lane_points.append(0)
		stamped.append({})
		jammed_until.append(-1.0)

	var key := OmniLight3D.new()
	key.position = Vector3(0, 7, 2)
	key.light_color = Color(0.6, 0.56, 0.48)
	key.light_energy = 60.0
	key.omni_range = 35.0
	key.shadow_enabled = true
	arena.add_child(key)
	var hall_light := OmniLight3D.new()
	hall_light.position = Vector3(0, 7, -14)
	hall_light.light_color = Color(0.75, 0.6, 0.45)
	hall_light.light_energy = 35.0
	hall_light.omni_range = 30.0
	arena.add_child(hall_light)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 10, 18)
	fill.light_color = Color(0.56, 0.545, 0.485)
	fill.light_energy = 12.0
	fill.omni_range = 400.0
	arena.add_child(fill)

func set_belt_material(node: Node, belt: StandardMaterial3D):
	if node is MeshInstance3D:
		for i in node.mesh.get_surface_count():
			var source = node.mesh.surface_get_material(i)
			if source and source.resource_name == "mp_belt":
				node.set_surface_override_material(i, belt)
	for child in node.get_children():
		set_belt_material(child, belt)

## Same schedule on every peer: arrival times at the stamp, intervals shrinking from 1.3 s to 0.5 s.
func make_schedule(seed_value: int):
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	part_times.clear()
	var t: float = 2.0
	while t < SHIFT_TIME:
		part_times.append(t)
		var progress: float = t / SHIFT_TIME
		var interval: float = lerp(1.3, 0.5, progress)
		# now and then a quick double
		if rng.randf() < 0.18 + progress * 0.2:
			interval *= 0.5
		t += interval * rng.randf_range(0.85, 1.25)



func on_play_start():
	pass

func on_server_play_start():
	schedule_rpc.rpc(randi())

@rpc("authority", "call_local", "reliable")
func schedule_rpc(seed_value: int):
	make_schedule(seed_value)
	play_sound("whistle")

func visual_tick(delta: float):

	if part_times.is_empty():
		return

	var t: float = play_time

	# local judging for my own lane
	var my_seat: int = seat_of(multiplayer.get_unique_id())
	if running and my_seat >= 0 and my_seat < lanes.size() and not PauseMenu.active:
		if Input.is_action_just_pressed("action_1"):
			judge_press(my_seat, t)

	for seat in lanes.size():
		belt_materials[seat].uv1_offset.z = - t * BELT_SPEED * belt_materials[seat].uv1_scale.z
		var pool: Array = pools[seat]
		var used: int = 0
		for i in part_times.size():
			var dt: float = part_times[i] - t
			var z: float = STAMP_Z - dt * BELT_SPEED
			if z < SPAWN_Z or z > 6.2:
				continue
			if used >= pool.size():
				break
			var part: Node3D = pool[used]
			used += 1
			part.visible = true
			part.position = Vector3(0, 0.9, z)
			part.scale = Vector3(1.0, 0.45, 1.0) if stamped[seat].has(i) else Vector3.ONE
		for k in range(used, pool.size()):
			pool[k].visible = false

		var jammed: bool = jammed_until[seat] > t
		lamps[seat].light_color = Color(1.0, 0.1, 0.05) if jammed else Color(1.0, 0.5, 0.2)

func judge_press(seat: int, t: float):

	if jammed_until[seat] > t:
		return

	var best: int = -1
	var best_offset: float = INF
	for i in part_times.size():
		var offset: float = abs(part_times[i] - t)
		if offset < best_offset and not stamped[seat].has(i):
			best_offset = offset
			best = i
		if part_times[i] > t + 1.0:
			break

	if best >= 0 and best_offset <= GOOD:
		var points: int = 2 if best_offset <= PERFECT else 1
		stamp_rpc.rpc(seat, best, points)
	else:
		jam_rpc.rpc(seat)

func compute_scores() -> Dictionary[int, int]:
	var ids: Array = players.keys()
	var order: Array = range(min(ids.size(), lane_points.size()))
	order.sort_custom( func(a, b): return lane_points[a] > lane_points[b])
	var scores: Dictionary[int, int]
	for rank in order.size():
		var seat: int = order[rank]
		scores[ids[seat]] = player_count if rank == 0 else max(player_count - 1 - rank, 0)
	return scores

func server_tick(_delta: float):
	if play_time >= SHIFT_TIME + 1.5 and not game_end:
		end_game()



@rpc("any_peer", "call_local", "reliable")
func stamp_rpc(seat: int, part_index: int, points: int):
	if seat < 0 or seat >= lanes.size() or stamped[seat].has(part_index):
		return
	# only the lane's owner may stamp it
	var sender: int = multiplayer.get_remote_sender_id()
	if sender != 0 and seat != seat_of(sender) and not GameManager.local_game:
		return
	stamped[seat][part_index] = true
	lane_points[seat] += points
	score_labels[seat].text = str(lane_points[seat])
	animate_stamp(seat)
	judge_labels[seat].text = "PARFAIT" if points == 2 else "BIEN"
	judge_labels[seat].modulate = Color(0.45, 1.0, 0.4) if points == 2 else Color(1.0, 0.9, 0.45)
	play_sound("perfect" if points == 2 else "stamp")
	fade_judge(seat)

@rpc("any_peer", "call_local", "reliable")
func jam_rpc(seat: int):
	if seat < 0 or seat >= lanes.size():
		return
	jammed_until[seat] = play_time + JAM_TIME
	animate_stamp(seat)
	judge_labels[seat].text = "BOURRAGE"
	judge_labels[seat].modulate = Color(1.0, 0.25, 0.2)
	play_sound("jam")
	fade_judge(seat)

func animate_stamp(seat: int):
	var head: Node3D = heads[seat]
	var t := create_tween()
	t.tween_property(head, "position:y", 2.02, 0.05).set_ease(Tween.EASE_IN)
	t.tween_property(head, "position:y", 3.0, 0.18).set_ease(Tween.EASE_OUT)

func fade_judge(seat: int):
	var label: Label3D = judge_labels[seat]
	label.scale = Vector3.ONE * 1.3
	var t := create_tween()
	t.tween_property(label, "scale", Vector3.ONE, 0.15)
	t.tween_interval(0.35)
	t.tween_callback( func(): label.text = "")
