extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## SOUFFLERIE: a round test deck with four industrial fans around it. A fan's lamps blink, then it blows for a
## few seconds and the wind drags everyone away from it, toward the open edge. Steel screens orbit the deck
## slowly: stand in a screen's lee and the wind can't reach you. Later on two fans blow at once, harder.
## Last one standing wins.

const RADIUS: float = 8.5
const FAN_DISTANCE: float = 12.0
const SCREEN_ORBIT: float = 4.6
const SCREEN_WIDTH: float = 3.0
const WARN_TIME: float = 1.6
const BLOW_TIME: float = 2.6

var fans: Array[Node3D] = []
var fan_lamps: Array[OmniLight3D] = []
var blades: Array[Node3D] = []
var screens: Array[Node3D] = []
var screen_angle: float = 0.0
var blowing: Array[int] = []
var wind_strength: float = 0.0
var cycle_timer: float = 3.0
var gusts: Array[GPUParticles3D] = []

func spawn_points() -> Array[Vector3]:
	return [Vector3(-2, 0.1, -2), Vector3(2, 0.1, -2), Vector3(2, 0.1, 2), Vector3(-2, 0.1, 2), Vector3(0, 0.1, 0)]

func fan_direction(i: int) -> Vector3:
	var angle: float = i * PI * 0.5 + PI * 0.25
	return Vector3(cos(angle), 0.0, sin(angle))

func build_arena():

	max_duration = 110.0
	set_camera(Vector3(0.0, 18.0, 14.0), Vector3(0.0, -1.0, 0.5))

	add_sound("ambience", "res://audio/unique/chisel gauntlet/machine ambience.ogg", -8.0, true)
	add_sound("warn", "res://audio/sfx/ekg_beep.ogg", -8.0)
	add_sound("wind", "res://audio/sfx/escalator_pit_wind.ogg", 0.0, true)


	var body := StaticBody3D.new()
	arena.add_child(body)
	var shape := CollisionShape3D.new()
	var cylinder := CylinderShape3D.new()
	cylinder.radius = RADIUS
	cylinder.height = 0.6
	shape.shape = cylinder
	shape.position.y = -0.3
	body.add_child(shape)
	var deck := MeshInstance3D.new()
	var deck_mesh := CylinderMesh.new()
	deck_mesh.top_radius = RADIUS
	deck_mesh.bottom_radius = RADIUS
	deck_mesh.height = 0.6
	deck_mesh.radial_segments = 48
	deck.mesh = deck_mesh
	var deck_material: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_MARKED, Color(1.0, 0.95, 0.9), 0.5)
	deck_material.uv1_offset = Vector3.ONE * 0.5
	deck.material_override = deck_material
	deck.position.y = -0.3
	arena.add_child(deck)
	var ring := MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = RADIUS - 0.25
	ring_mesh.outer_radius = RADIUS + 0.1
	ring.mesh = ring_mesh
	ring.material_override = DA.kind_material("mp_hazard")
	ring.scale = Vector3(1.0, 0.4, 1.0)
	arena.add_child(ring)

	for i in 4:
		var direction: Vector3 = fan_direction(i)
		var fan := Node3D.new()
		fan.position = direction * FAN_DISTANCE + Vector3(0.0, 1.8, 0.0)
		arena.add_child(fan)
		fan.look_at(Vector3(0.0, 1.8, 0.0), Vector3.UP)
		# the housing: a short drum with a grille, facing the deck
		var drum := MeshInstance3D.new()
		var drum_mesh := CylinderMesh.new()
		drum_mesh.top_radius = 2.2
		drum_mesh.bottom_radius = 2.2
		drum_mesh.height = 1.2
		drum.mesh = drum_mesh
		drum.material_override = DA.kind_material("mp_dark")
		drum.rotation.x = PI * 0.5
		fan.add_child(drum)
		var rim := MeshInstance3D.new()
		var rim_mesh := TorusMesh.new()
		rim_mesh.inner_radius = 2.05
		rim_mesh.outer_radius = 2.35
		rim.mesh = rim_mesh
		rim.material_override = DA.kind_material("mp_hazard")
		rim.rotation.x = PI * 0.5
		rim.position.z = -0.62
		fan.add_child(rim)
		var blade_root := Node3D.new()
		blade_root.position.z = -0.4
		fan.add_child(blade_root)
		for k in 4:
			var blade := MeshInstance3D.new()
			var blade_mesh := BoxMesh.new()
			blade_mesh.size = Vector3(0.5, 3.6, 0.08)
			blade.mesh = blade_mesh
			blade.material_override = DA.kind_material("mp_metal")
			blade.rotation.z = k * PI * 0.25
			blade_root.add_child(blade)
		blades.append(blade_root)
		var stand := MeshInstance3D.new()
		var stand_mesh := BoxMesh.new()
		stand_mesh.size = Vector3(0.6, 2.2, 0.6)
		stand.mesh = stand_mesh
		stand.material_override = DA.kind_material("mp_dark")
		stand.position = Vector3(0.0, -1.9, 0.3)
		fan.add_child(stand)
		var lamp := OmniLight3D.new()
		lamp.position = Vector3(0.0, 2.6, -0.4)
		lamp.light_color = Color(1.0, 0.6, 0.2)
		lamp.light_energy = 0.0
		lamp.omni_range = 9.0
		fan.add_child(lamp)
		fan_lamps.append(lamp)
		fans.append(fan)

		var gust := GPUParticles3D.new()
		gust.amount = 60
		gust.lifetime = 1.0
		gust.emitting = false
		var process := ParticleProcessMaterial.new()
		process.direction = - direction
		process.spread = 8.0
		process.initial_velocity_min = 14.0
		process.initial_velocity_max = 18.0
		process.gravity = Vector3.ZERO
		process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
		process.emission_box_extents = Vector3(2.0, 1.0, 2.0)
		gust.process_material = process
		var streak := QuadMesh.new()
		streak.size = Vector2(0.08, 0.7)
		streak.material = unshaded(Color(0.9, 0.95, 1.0, 0.5))
		(streak.material as StandardMaterial3D).billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		gust.draw_pass_1 = streak
		gust.position = direction * (FAN_DISTANCE - 1.0) + Vector3(0.0, 1.0, 0.0)
		arena.add_child(gust)
		gusts.append(gust)

	for k in 4:
		var screen := Node3D.new()
		arena.add_child(screen)
		add_box(Vector3(SCREEN_WIDTH, 2.0, 0.3), Vector3(0.0, 1.0, 0.0), DA.kind_material("mp_metal"), screen)
		add_box(Vector3(SCREEN_WIDTH + 0.05, 0.25, 0.32), Vector3(0.0, 2.0, 0.0), DA.kind_material("mp_hazard"), screen, false)
		screens.append(screen)
	place_screens()

	add_key_lights(Vector3(0.0, 12.0, 3.0), 90.0, 26.0)
	add_light(Vector3(0.0, 6.0, -18.0), Color(0.56, 0.545, 0.485), 30.0, 30.0)

func place_screens():
	for k in screens.size():
		var angle: float = screen_angle + k * TAU / screens.size()
		screens[k].position = Vector3(cos(angle), 0.0, sin(angle)) * SCREEN_ORBIT
		# the panel's width runs along the orbit, so it faces outward toward the fans
		screens[k].rotation.y = PI * 0.5 - angle

func on_play_start_local():
	fade_in_ambience()

func server_tick(delta: float):

	cycle_timer -= delta
	if cycle_timer > 0.0:
		return
	var count: int = 1 if play_time < 40.0 else 2
	var picks: Array = [0, 1, 2, 3]
	picks.shuffle()
	# stronger than walking (4): out in the open you get blown away, the screens are the only safety
	var strength: float = min(5.2 + play_time * 0.03, 8.0)
	gust_rpc.rpc(picks.slice(0, count), strength)
	cycle_timer = WARN_TIME + BLOW_TIME + max(3.0 - play_time * 0.02, 1.2)

@rpc("authority", "call_local", "reliable")
func gust_rpc(which: Array, strength: float):
	play_sound("warn")
	for i in which:
		var t := fan_lamps[i].create_tween().set_loops(4)
		t.tween_property(fan_lamps[i], "light_energy", 8.0, 0.2)
		t.tween_property(fan_lamps[i], "light_energy", 0.0, 0.2)
	await get_tree().create_timer(WARN_TIME, false).timeout
	if not is_inside_tree():
		return
	blowing.assign(which)
	wind_strength = strength
	audio["wind"].play()
	for i in which:
		gusts[i].emitting = true
		fan_lamps[i].light_energy = 6.0
	await get_tree().create_timer(BLOW_TIME, false).timeout
	if not is_inside_tree():
		return
	for i in which:
		gusts[i].emitting = false
		fan_lamps[i].light_energy = 0.0
	blowing.clear()
	audio["wind"].stop()

func visual_tick(delta: float):

	screen_angle += delta * 0.25
	place_screens()

	for i in blades.size():
		blades[i].rotation.z += delta * (20.0 if blowing.has(i) else 1.5)

	if not running or blowing.is_empty():
		return

	for player in local_runners():
		if not player.is_on_floor():
			continue
		var push := Vector3.ZERO
		for i in blowing:
			if not sheltered(i, player.global_position):
				push += - fan_direction(i)
		if push.length() > 0.0:
			player.move_and_collide(push.normalized() * wind_strength * delta)

## Behind a screen, seen from the fan: the screen blocks the line between them.
func sheltered(i: int, position: Vector3) -> bool:
	var fan := Vector2(fan_direction(i).x, fan_direction(i).z) * FAN_DISTANCE
	var me := Vector2(position.x, position.z)
	for k in screens.size():
		var angle: float = screen_angle + k * TAU / screens.size()
		var center := Vector2(cos(angle), sin(angle)) * SCREEN_ORBIT
		var tangent := Vector2(- sin(angle), cos(angle))
		# intersect the fan-to-runner segment with the screen's segment
		var a: Vector2 = center - tangent * SCREEN_WIDTH * 0.5
		var b: Vector2 = center + tangent * SCREEN_WIDTH * 0.5
		if Geometry2D.segment_intersects_segment(fan, me, a, b) != null:
			return true
	return false
