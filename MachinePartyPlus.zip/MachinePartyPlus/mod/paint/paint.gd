extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## PEINTURE: the office floor is a grid of tiles; every tile you walk over takes your colour. A paint roller
## three tiles wide crosses the floor every few seconds (its lane flashes red first), wiping its lane back to
## grey and flattening anyone in its way (they get back up after a moment). Paint buckets splash a 5 x 5 patch in your colour.
## Most tiles when the clock runs out wins.

const SIZE: int = 14
const TILE: float = 1.0
const ROLLER_SPEED: float = 7.0

var owners: PackedInt32Array = PackedInt32Array()
var tiles: Array[MeshInstance3D] = []
var materials: Dictionary = {}
var dirty: Dictionary = {}
var flush_timer: float = 0.0
var roller_timer: float = 6.0
var roller: Node3D
var roller_axis: int = -1
var roller_line: int = 0
var roller_pos: float = 0.0
var roller_dir: float = 1.0
var bucket: Node3D
var bucket_cell: int = -1
var bucket_timer: float = 9.0
var flattened: Dictionary = {}

func spawn_points() -> Array[Vector3]:
	return [Vector3(-5, 0.1, -5), Vector3(5, 0.1, -5), Vector3(5, 0.1, 5), Vector3(-5, 0.1, 5), Vector3(0, 0.1, 0)]

func build_arena():

	max_duration = 60.0
	set_camera(Vector3(0.0, 14.0, 10.5), Vector3(0.0, -0.5, 0.6))

	add_sound("ambience", "res://audio/unique/dvd roomba/dvd roomba ambience.ogg", -8.0, true)
	add_sound("roller", "res://audio/unique/intermission/intermission servo2.ogg", -2.0)
	add_sound("splash", "res://audio/sfx/manufacture_gun_drop_gear.ogg", -2.0)
	add_sound("flat", "res://audio/unique/disco dodge/dd fall scream impact.ogg", -4.0)

	# the green pea dining room, behind the painted floor
	add_backdrop_model("res://minigames/green_pea/models/pea dinner scene4/pea dinner scene4.glb", Vector3(0.0, -0.02, -16.0))

	var half: float = SIZE * TILE * 0.5
	add_box(Vector3(SIZE * TILE + 0.4, 0.6, SIZE * TILE + 0.4), Vector3(0.0, -0.3, 0.0), DA.kind_material("mp_dark"))
	for side in [-1.0, 1.0]:
		add_box(Vector3(0.3, 1.0, SIZE * TILE + 0.9), Vector3(side * (half + 0.35), 0.5, 0.0), DA.kind_material("mp_hazard"))
		add_box(Vector3(SIZE * TILE + 0.9, 1.0, 0.3), Vector3(0.0, 0.5, side * (half + 0.35)), DA.kind_material("mp_hazard"))

	materials[0] = DA.base_material(DA.TEX_FLOOR_MARKED, Color(0.85, 0.85, 0.85), 0.5)
	owners.resize(SIZE * SIZE)
	owners.fill(0)
	var tile_mesh := BoxMesh.new()
	tile_mesh.size = Vector3(TILE * 0.96, 0.06, TILE * 0.96)
	for index in SIZE * SIZE:
		var tile := MeshInstance3D.new()
		tile.mesh = tile_mesh
		tile.position = cell_center(index) + Vector3(0.0, 0.03, 0.0)
		tile.material_override = materials[0]
		arena.add_child(tile)
		tiles.append(tile)

	roller = Node3D.new()
	var drum := MeshInstance3D.new()
	var drum_mesh := CylinderMesh.new()
	drum_mesh.top_radius = 0.55
	drum_mesh.bottom_radius = 0.55
	drum_mesh.height = TILE * 3.0
	drum.mesh = drum_mesh
	drum.material_override = DA.kind_material("mp_rubber")
	drum.rotation.z = PI * 0.5
	drum.position.y = 0.55
	roller.add_child(drum)
	for side in [-1.0, 1.0]:
		var arm := MeshInstance3D.new()
		var arm_mesh := BoxMesh.new()
		arm_mesh.size = Vector3(0.25, 1.8, 0.25)
		arm.mesh = arm_mesh
		arm.material_override = DA.kind_material("mp_hazard")
		arm.position = Vector3(side * (TILE * 1.5 + 0.15), 1.1, 0.0)
		roller.add_child(arm)
	var beam := MeshInstance3D.new()
	var beam_mesh := BoxMesh.new()
	beam_mesh.size = Vector3(TILE * 3.0 + 0.6, 0.3, 0.3)
	beam.mesh = beam_mesh
	beam.material_override = DA.kind_material("mp_dark")
	beam.position.y = 2.0
	roller.add_child(beam)
	roller.visible = false
	arena.add_child(roller)

	bucket = DA.load_model("boiler.glb")
	bucket.scale = Vector3.ONE * 0.3
	bucket.visible = false
	arena.add_child(bucket)

	add_key_lights(Vector3(0.0, 12.0, 2.0), 95.0, 28.0)

	if Engine.has_meta("mpplus_preview"):
		var rng := RandomNumberGenerator.new()
		rng.seed = 3
		for index in SIZE * SIZE:
			if rng.randf() < 0.55:
				set_tile(index, [11, 22, 33][rng.randi() % 3])

func cell_center(index: int) -> Vector3:
	var half: float = SIZE * TILE * 0.5
	return Vector3(- half + (index % SIZE + 0.5) * TILE, 0.0, - half + (index / SIZE + 0.5) * TILE)

func cell_at(position: Vector3) -> int:
	var half: float = SIZE * TILE * 0.5
	var col: int = int(floor((position.x + half) / TILE))
	var row: int = int(floor((position.z + half) / TILE))
	if col < 0 or col >= SIZE or row < 0 or row >= SIZE:
		return -1
	return row * SIZE + col

func material_for(network_id: int) -> Material:
	if not materials.has(network_id):
		var color: Color = seat_color(network_id) if seat_of(network_id) >= 0 else SEAT_COLORS[network_id % SEAT_COLORS.size()]
		var m: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_MARKED, color, 0.5)
		# the game's grading desaturates a lot: a little glow keeps the colours readable
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 0.45
		materials[network_id] = m
	return materials[network_id]

func set_tile(index: int, network_id: int):
	owners[index] = network_id
	tiles[index].material_override = material_for(network_id) if network_id != 0 else materials[0]

func on_play_start_local():
	fade_in_ambience()
	build_hud(true)

func server_tick(delta: float):

	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active or flattened.has(network_id):
			continue
		var index: int = cell_at(player.global_position)
		if index >= 0 and owners[index] != network_id:
			paint(index, network_id)
		if bucket_cell >= 0 and index == bucket_cell:
			splash(bucket_cell, network_id)

	roller_timer -= delta
	if roller_timer <= 0.0 and roller_axis == -1:
		roller_timer = max(5.0 - play_time * 0.04, 2.8)
		start_roller_rpc.rpc(randi() % 2, randi_range(2, SIZE - 3), 1.0 if randf() < 0.5 else -1.0)

	bucket_timer -= delta
	if bucket_timer <= 0.0 and bucket_cell == -1:
		bucket_timer = 10.0
		bucket_cell = randi() % (SIZE * SIZE)
		bucket_rpc.rpc(bucket_cell)

	flush_timer -= delta
	if flush_timer <= 0.0 and not dirty.is_empty():
		flush_timer = 0.1
		tiles_rpc.rpc(dirty.keys(), dirty.values())
		dirty.clear()
		recount()

func paint(index: int, network_id: int):
	owners[index] = network_id
	dirty[index] = network_id

func splash(center: int, network_id: int):
	bucket_cell = -1
	bucket_rpc.rpc(-1)
	sfx_rpc.rpc("splash")
	var col: int = center % SIZE
	var row: int = center / SIZE
	for r in range(row - 2, row + 3):
		for c in range(col - 2, col + 3):
			if r >= 0 and r < SIZE and c >= 0 and c < SIZE:
				paint(r * SIZE + c, network_id)

func recount():
	var counts: Dictionary = {}
	for owner_id in owners:
		if owner_id != 0:
			counts[owner_id] = counts.get(owner_id, 0) + 1
	points = counts
	points_rpc.rpc(points)

@rpc("authority", "call_local", "reliable")
func tiles_rpc(indices: Array, network_ids: Array):
	for i in indices.size():
		set_tile(indices[i], network_ids[i])

@rpc("authority", "call_local", "reliable")
func bucket_rpc(cell: int):
	bucket.visible = cell >= 0
	if cell >= 0:
		bucket.position = cell_center(cell)

@rpc("authority", "call_local", "reliable")
func start_roller_rpc(axis: int, line: int, direction: float):
	play_sound("roller")
	roller_axis = axis
	roller_line = line
	roller_dir = direction
	roller_pos = - roller_dir * (SIZE * TILE * 0.5 + 1.5)
	roller.visible = true
	# axis 0: the roller runs along z over columns line-1..line+1; axis 1: along x over those rows
	roller.rotation.y = 0.0 if axis == 0 else PI * 0.5
	var lane_center: float = cell_center(line).x if axis == 0 else cell_center(line * SIZE).z
	var marker := MeshInstance3D.new()
	var quad := BoxMesh.new()
	quad.size = Vector3(TILE * 3.0, 0.02, SIZE * TILE) if axis == 0 else Vector3(SIZE * TILE, 0.02, TILE * 3.0)
	marker.mesh = quad
	marker.material_override = unshaded(Color(1.0, 0.15, 0.1, 0.4))
	marker.position = Vector3(lane_center, 0.08, 0.0) if axis == 0 else Vector3(0.0, 0.08, lane_center)
	arena.add_child(marker)
	get_tree().create_timer(1.2, false).timeout.connect(marker.queue_free)

func visual_tick(delta: float):

	bucket.rotation.y += delta * 1.5

	if roller_axis == -1:
		return
	roller_pos += roller_dir * ROLLER_SPEED * delta
	var half: float = SIZE * TILE * 0.5
	var lane_center: float = cell_center(roller_line).x if roller_axis == 0 else cell_center(roller_line * SIZE).z
	if roller_axis == 0:
		roller.position = Vector3(lane_center, 0.0, roller_pos)
	else:
		roller.position = Vector3(roller_pos, 0.0, lane_center)
	(roller.get_child(0) as Node3D).rotation.x += delta * 10.0 * roller_dir

	# the roller wipes its 3-tile lane as it rolls over it
	if multiplayer.is_server():
		var step: int = int(floor((roller_pos + half) / TILE))
		if step >= 0 and step < SIZE:
			for lane in range(roller_line - 1, roller_line + 2):
				var index: int = (step * SIZE + lane) if roller_axis == 0 else (lane * SIZE + step)
				if owners[index] != 0:
					paint(index, 0)

	for player in local_runners():
		var along: float = player.global_position.z if roller_axis == 0 else player.global_position.x
		var across: float = player.global_position.x if roller_axis == 0 else player.global_position.z
		if abs(along - roller_pos) < 0.7 and abs(across - lane_center) < TILE * 1.5 + 0.3 and not player.has_meta("flat_until"):
			flatten(player)

	if abs(roller_pos) > half + 2.0:
		roller_axis = -1
		roller.visible = false

## Squashed flat for two seconds: no painting, and the roller pushes you along.
func flatten(player):
	sfx_rpc.rpc("flat")
	player.set_meta("flat_until", true)
	push_runner(player, Vector3(0.0, 0.0, roller_dir) if roller_axis == 0 else Vector3(roller_dir, 0.0, 0.0), 9.0)
	flat_rpc.rpc(player.player_presence.network_id, true)
	await get_tree().create_timer(2.0, false).timeout
	if is_instance_valid(player):
		player.remove_meta("flat_until")
		flat_rpc.rpc(player.player_presence.network_id, false)

@rpc("any_peer", "call_local", "reliable")
func flat_rpc(network_id: int, flat: bool):
	var player = players.get(network_id, null)
	if not is_instance_valid(player):
		return
	if flat:
		flattened[network_id] = true
		player.create_tween().tween_property(player.visuals, "scale", Vector3(1.3, 0.15, 1.3), 0.08)
	else:
		flattened.erase(network_id)
		player.create_tween().tween_property(player.visuals, "scale", Vector3.ONE, 0.25).set_trans(Tween.TRANS_BACK)

func compute_scores() -> Dictionary[int, int]:
	return rank_scores(points)
