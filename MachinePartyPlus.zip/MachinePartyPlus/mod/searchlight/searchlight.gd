extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## PROJECTEUR: a night yard full of crates, watched by searchlights on towers. Fuses appear around the yard;
## grab them for points. A searchlight that sees you for half a second zaps you, unless a crate stands between
## you and its tower: the crate's real shadow is a safe spot. More lights, faster sweeps as the clock runs down.
## Most fuses wins; being zapped keeps your fuses but ends your run.

const HALF: float = 9.0
const SPOT_RADIUS: float = 2.4
const SEEN_TIME: float = 0.5
const TOWERS: Array[Vector3] = [Vector3(-12.0, 9.0, -12.0), Vector3(12.0, 9.0, -12.0), Vector3(0.0, 10.0, 13.0)]
const CRATES: Array[Vector3] = [
	Vector3(-5.0, 0, -4.0), Vector3(4.5, 0, -5.0), Vector3(0.0, 0, 0.0), Vector3(-6.0, 0, 4.0),
	Vector3(5.5, 0, 3.5), Vector3(-1.5, 0, -7.0), Vector3(2.0, 0, 6.5), Vector3(-2.5, 0, 3.0), Vector3(7.0, 0, -1.0)
]
const CRATE_SIZE: Vector3 = Vector3(1.6, 1.6, 1.6)

var lights: Array[SpotLight3D] = []
var spot_discs: Array[MeshInstance3D] = []
var spot_targets: Array[Vector3] = []
var spot_phase: Array[float] = []
var active_lights: int = 1
var seen: Dictionary = {}
var fuse_node: Node3D
var fuse_position: Vector3 = Vector3.INF
var sync_timer: float = 0.0

func spawn_points() -> Array[Vector3]:
	return [Vector3(-3, 0.1, 6), Vector3(3, 0.1, 6), Vector3(-7, 0.1, 7), Vector3(7, 0.1, 7), Vector3(0, 0.1, 8)]

func build_arena():

	max_duration = 75.0
	set_camera(Vector3(0.0, 19.0, 15.0), Vector3(0.0, -1.0, 0.5))

	add_sound("ambience", "res://audio/unique/duck hunt/duck hunt ambience.ogg", -6.0, true)
	add_sound("alarm", "res://audio/sfx/escalator_pit_fail_alert.ogg", -2.0)
	add_sound("zap", "res://audio/sfx/bad_explosion.ogg", -4.0)
	add_sound("fuse", "res://audio/sfx/manufacture_gun_correct_item_inserted.ogg", -2.0)
	add_sound("warn", "res://audio/sfx/flashlight_on.ogg", -2.0)

	# beyond the fence, the dark shapes of the Duck Hunt covers
	add_backdrop_model("res://minigames/duck_hunt/models/duck hunt covers revised1/duck hunt covers revised1.glb", Vector3(0.0, -0.4, -22.0))

	var ground: StandardMaterial3D = DA.base_material(DA.TEX_CONCRETE, Color(0.75, 0.75, 0.78), 0.25)
	add_box(Vector3(HALF * 2.0 + 1.0, 0.6, HALF * 2.0 + 1.0), Vector3(0.0, -0.3, 0.0), ground)
	for side in [-1.0, 1.0]:
		add_box(Vector3(0.3, 1.2, HALF * 2.0 + 1.0), Vector3(side * (HALF + 0.65), 0.6, 0.0), DA.kind_material("mp_hazard"))
		add_box(Vector3(HALF * 2.0 + 1.6, 1.2, 0.3), Vector3(0.0, 0.6, side * (HALF + 0.65)), DA.kind_material("mp_hazard"))

	var crate_material: StandardMaterial3D = DA.base_material(DA.TEX_RUST, Color(0.9, 0.8, 0.65), 0.6)
	for crate in CRATES:
		add_box(CRATE_SIZE, crate + Vector3(0.0, CRATE_SIZE.y * 0.5, 0.0), crate_material)

	# night: only a faint moon and the towers' own lamps
	add_light(Vector3(0.0, 15.0, 5.0), Color(0.42, 0.48, 0.65), 40.0, 45.0, true)
	add_light(Vector3(0.0, 20.0, 22.0), Color(0.35, 0.4, 0.55), 14.0, 400.0)
	for i in TOWERS.size():
		var mast := add_box(Vector3(0.6, TOWERS[i].y, 0.6), Vector3(TOWERS[i].x, TOWERS[i].y * 0.5, TOWERS[i].z), DA.kind_material("mp_dark"), null, false)
		var lamp: Node3D = DA.load_model("stamper_head.glb")
		lamp.position = TOWERS[i] + Vector3(0.0, 0.6, 0.0)
		arena.add_child(lamp)

		var light := SpotLight3D.new()
		light.position = TOWERS[i]
		light.light_color = Color(1.0, 0.95, 0.8)
		light.light_energy = 90.0
		light.spot_range = 40.0
		light.shadow_enabled = true
		light.spot_attenuation = 0.4
		arena.add_child(light)
		lights.append(light)

		var disc := MeshInstance3D.new()
		var cylinder := CylinderMesh.new()
		cylinder.top_radius = SPOT_RADIUS
		cylinder.bottom_radius = SPOT_RADIUS
		cylinder.height = 0.02
		disc.mesh = cylinder
		disc.material_override = unshaded(Color(1.0, 0.95, 0.6, 0.22))
		arena.add_child(disc)
		spot_discs.append(disc)

		spot_targets.append(Vector3(0.0, 0.0, -3.0 + i * 3.0))
		spot_phase.append(i * 2.1)
		set_light_on(i, i < active_lights)
		aim(i, spot_targets[i])

	fuse_node = Node3D.new()
	var fuse := MeshInstance3D.new()
	var body := CylinderMesh.new()
	body.top_radius = 0.18
	body.bottom_radius = 0.18
	body.height = 0.6
	fuse.mesh = body
	fuse.material_override = DA.kind_material("mp_light")
	fuse.position.y = 0.5
	fuse_node.add_child(fuse)
	var glow := OmniLight3D.new()
	glow.light_color = Color(1.0, 0.5, 0.15)
	glow.light_energy = 2.5
	glow.omni_range = 3.0
	glow.position.y = 0.8
	fuse_node.add_child(glow)
	fuse_node.visible = false
	arena.add_child(fuse_node)

	if Engine.has_meta("mpplus_preview"):
		active_lights = 3
		for i in lights.size():
			set_light_on(i, true)
		place_fuse_rpc(Vector3(3.0, 0.0, -2.5))

func set_light_on(i: int, on: bool):
	lights[i].visible = on
	spot_discs[i].visible = on

func aim(i: int, target: Vector3):
	var light: SpotLight3D = lights[i]
	var distance: float = light.position.distance_to(target)
	light.look_at(target, Vector3.UP)
	light.spot_angle = rad_to_deg(atan(SPOT_RADIUS / distance)) * 1.15
	spot_discs[i].position = target + Vector3(0.0, 0.02, 0.0)

func on_play_start_local():
	fade_in_ambience()
	build_hud(true)

func on_server_play_start():
	new_fuse()

## Lissajous sweeps over the yard, one per light, speeding up.
func sweep_target(i: int) -> Vector3:
	var speed: float = 0.35 + play_time * 0.006
	var t: float = play_time * speed + spot_phase[i]
	return Vector3(sin(t * (1.0 + i * 0.3)) * (HALF - 1.5), 0.0, sin(t * 0.7 + i) * (HALF - 1.5))

func server_tick(delta: float):

	var wanted: int = clampi(1 + int(play_time / 20.0), 1, TOWERS.size())
	if wanted != active_lights:
		lights_rpc.rpc(wanted)

	for i in active_lights:
		spot_targets[i] = sweep_target(i)

	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		var lit: bool = false
		for i in active_lights:
			if in_light(i, player.global_position):
				lit = true
				break
		if lit:
			if seen.get(network_id, 0.0) == 0.0:
				sfx_rpc.rpc("warn")
			seen[network_id] = seen.get(network_id, 0.0) + delta
			if seen[network_id] >= SEEN_TIME:
				seen[network_id] = 0.0
				sfx_rpc.rpc("zap")
				crush(network_id)
		else:
			seen[network_id] = 0.0

		if fuse_position != Vector3.INF and Vector2(player.global_position.x - fuse_position.x, player.global_position.z - fuse_position.z).length() < 0.9:
			add_points(network_id)
			sfx_rpc.rpc("fuse")
			new_fuse()

	sync_timer -= delta
	if sync_timer <= 0.0:
		sync_timer = 0.05
		spots_rpc.rpc(spot_targets)

## In the spot, and no crate between the runner and the tower (a crate's shadow is safe).
func in_light(i: int, position: Vector3) -> bool:
	var flat := Vector2(position.x - spot_targets[i].x, position.z - spot_targets[i].z)
	if flat.length() > SPOT_RADIUS:
		return false
	var from := Vector2(TOWERS[i].x, TOWERS[i].z)
	var to := Vector2(position.x, position.z)
	for crate in CRATES:
		if segment_hits_box(from, to, Vector2(crate.x, crate.z), CRATE_SIZE.x * 0.5 + 0.1):
			# only a shadow if the crate is taller than the light's line at that point
			return false
	return true

func segment_hits_box(a: Vector2, b: Vector2, center: Vector2, half: float) -> bool:
	var t0: float = 0.0
	var t1: float = 1.0
	var d: Vector2 = b - a
	for axis in 2:
		var lo: float = center[axis] - half
		var hi: float = center[axis] + half
		if abs(d[axis]) < 0.0001:
			if a[axis] < lo or a[axis] > hi:
				return false
			continue
		var ta: float = (lo - a[axis]) / d[axis]
		var tb: float = (hi - a[axis]) / d[axis]
		t0 = max(t0, min(ta, tb))
		t1 = min(t1, max(ta, tb))
		if t0 > t1:
			return false
	# the runner's own spot does not count as cover
	return t1 < 0.97

func new_fuse():
	for attempt in 20:
		var spot := Vector3(randf_range(-HALF + 1.0, HALF - 1.0), 0.0, randf_range(-HALF + 1.0, HALF - 1.0))
		var clear: bool = true
		for crate in CRATES:
			if Vector2(spot.x - crate.x, spot.z - crate.z).length() < 1.6:
				clear = false
		if clear:
			fuse_position = spot
			place_fuse_rpc.rpc(spot)
			return

@rpc("authority", "call_local", "reliable")
func place_fuse_rpc(spot: Vector3):
	fuse_node.position = spot
	fuse_node.visible = true

@rpc("authority", "call_local", "reliable")
func lights_rpc(count: int):
	active_lights = count
	play_sound("alarm")
	for i in lights.size():
		set_light_on(i, i < count)

@rpc("authority", "call_remote", "unreliable_ordered")
func spots_rpc(targets: Array):
	for i in targets.size():
		spot_targets[i] = targets[i]

func visual_tick(delta: float):
	for i in lights.size():
		if lights[i].visible:
			aim(i, spot_targets[i])
	if fuse_node.visible:
		fuse_node.rotation.y += delta * 2.0

## Fuses decide; being zapped only stops you collecting more.
func compute_scores() -> Dictionary[int, int]:
	return rank_scores(points)

func check_game_end_on_death():
	if game_end:
		return
	if active_players.is_empty():
		end_game()
