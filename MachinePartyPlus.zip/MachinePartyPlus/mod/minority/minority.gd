extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## MINORITE: three freight lifts at the bottom of a concrete silo. Each turn you have a few seconds to stand on
## one; then the machine drops the most crowded lift, and the central floor opens under anyone left on it.
## Ties at the top drop together, unless every occupied lift is tied: then one of them, at random.
## Counts stay hidden until the drop. Falling uses the player's own fall check (collision layer 5 at y -5).

const LIFT_CENTERS: Array[Vector3] = [Vector3(-6.5, 0.0, 0.0), Vector3(0.0, 0.0, -6.5), Vector3(6.5, 0.0, 0.0)]
const LIFT_HALF: float = 2.0
const LETTERS: Array[String] = ["A", "B", "C"]
const FIRST_CHOICE_TIME: float = 7.0
const MIN_CHOICE_TIME: float = 3.5

var turn: int = 0

var lifts: Array[Node3D] = []
var lift_shapes: Array[CollisionShape3D] = []
var lift_signs: Array[Label3D] = []
var lift_lamps: Array[OmniLight3D] = []
var floor_shape: CollisionShape3D
var floor_mesh: MeshInstance3D
var hatch_meshes: Array[MeshInstance3D] = []

func spawn_points() -> Array[Vector3]:
	return [Vector3(-1.5, 0.1, -1.5), Vector3(1.5, 0.1, -1.5), Vector3(1.5, 0.1, 1.5), Vector3(-1.5, 0.1, 1.5), Vector3(0, 0.1, 0)]

func build_arena():

	max_duration = 150.0

	set_camera(Vector3(0.0, 16.0, 13.0), Vector3(0.0, 0.0, -1.8))

	add_sound("ambience", "res://audio/unique/chisel gauntlet/machine ambience.ogg", -8.0, true)
	add_sound("tick", "res://audio/sfx/burn_recycle/beep.ogg", -6.0)
	add_sound("alarm", "res://audio/sfx/escalator_pit_fail_alert.ogg", -2.0)
	add_sound("fall", "res://audio/unique/disco dodge/dd fall scream.ogg", -2.0)
	add_sound("lift", "res://audio/unique/intermission/intermission servo3.ogg", -4.0)

	# the concrete silo of Chisel Gauntlet, arena hanging in its shaft
	var silo_scene: PackedScene = load("res://minigames/chisel_gauntlet_multiplayer/models/chisel gauntlet art2/chisel gauntlet art2.glb")
	if silo_scene:
		var silo: Node3D = silo_scene.instantiate()
		silo.position = Vector3(0.0, -14.0, -2.0)
		arena.add_child(silo)
		# the hanging jumbotron of Chisel Gauntlet would hide lift B
		hide_named(silo, "jumbotron")

	# central floor (the trapdoor) made of two hatch leaves
	var floor_body := StaticBody3D.new()
	arena.add_child(floor_body)
	floor_shape = CollisionShape3D.new()
	var floor_box := BoxShape3D.new()
	floor_box.size = Vector3(9.0, 0.4, 9.0)
	floor_shape.shape = floor_box
	floor_shape.position = Vector3(0, -0.2, 0)
	floor_body.add_child(floor_shape)
	for side in [-1, 1]:
		var leaf := MeshInstance3D.new()
		var leaf_mesh := BoxMesh.new()
		leaf_mesh.size = Vector3(4.48, 0.4, 9.0)
		leaf.mesh = leaf_mesh
		leaf.material_override = DA.base_material(DA.TEX_FLOOR_MARKED, Color(0.9, 0.88, 0.84), 1.0 / 9.0)
		leaf.position = Vector3(side * 2.25, -0.2, 0)
		arena.add_child(leaf)
		hatch_meshes.append(leaf)

	for i in LIFT_CENTERS.size():
		var lift_root := Node3D.new()
		lift_root.position = LIFT_CENTERS[i]
		arena.add_child(lift_root)
		var model: Node3D = DA.load_model("lift.glb")
		# lifts face the center: their sign/back rail sits on the outer side
		model.rotation.y = [PI * 0.5, 0.0, - PI * 0.5][i]
		lift_root.add_child(model)

		var body := StaticBody3D.new()
		lift_root.add_child(body)
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = Vector3(LIFT_HALF * 2.0, 0.35, LIFT_HALF * 2.0)
		shape.shape = box
		shape.position = Vector3(0, -0.175, 0)
		body.add_child(shape)
		lift_shapes.append(shape)

		var sign := Label3D.new()
		sign.text = LETTERS[i]
		sign.font_size = 160
		sign.pixel_size = 0.008
		sign.outline_size = 24
		sign.modulate = Color(1.0, 0.8, 0.3)
		sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		sign.position = Vector3(0, 4.3, 0)
		lift_root.add_child(sign)
		lift_signs.append(sign)

		var lamp := OmniLight3D.new()
		lamp.position = Vector3(0, 3.2, 0)
		lamp.light_color = Color(1.0, 0.6, 0.25)
		lamp.light_energy = 3.0
		lamp.omni_range = 6.0
		lift_root.add_child(lamp)
		lift_lamps.append(lamp)
		lifts.append(lift_root)

	var key := OmniLight3D.new()
	key.position = Vector3(0, 9, 1)
	key.light_color = Color(0.56, 0.545, 0.485)
	key.light_energy = 70.0
	key.omni_range = 40.0
	key.shadow_enabled = true
	arena.add_child(key)
	var shaft := OmniLight3D.new()
	shaft.position = Vector3(0, -10, -2)
	shaft.light_color = Color(0.5, 0.55, 0.6)
	shaft.light_energy = 20.0
	shaft.omni_range = 30.0
	arena.add_child(shaft)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 18, 18)
	fill.light_color = Color(0.56, 0.545, 0.485)
	fill.light_energy = 12.0
	fill.omni_range = 400.0
	arena.add_child(fill)



func hide_named(node: Node, fragment: String):
	if node is Node3D and node.name.to_lower().contains(fragment):
		node.visible = false
		return
	for child in node.get_children():
		hide_named(child, fragment)

func on_server_play_start():
	run_turns()

func run_turns():

	while running and not game_end and is_inside_tree():

		turn += 1
		var choice_time: float = max(FIRST_CHOICE_TIME - (turn - 1) * 0.8, MIN_CHOICE_TIME)
		choose_rpc.rpc(turn)

		var left: float = choice_time
		while left > 0.0:
			var secs: int = ceili(left)
			if secs <= 3:
				set_countdown_mesage_rpc.rpc(str(secs), 0.5)
				sound_rpc.rpc("tick")
			await get_tree().create_timer(min(1.0, left), false).timeout
			left -= 1.0
			if game_end or not is_inside_tree():
				return

		# count who stands on which lift (server sees every runner's synced position)
		var counts: Array[int] = [0, 0, 0]
		for player in active_players.values():
			var lift: int = lift_under(player.global_position)
			if lift >= 0:
				counts[lift] += 1

		var drop: Array[int] = pick_drops(counts)
		reveal_rpc.rpc(counts, drop)

		await get_tree().create_timer(1.2, false).timeout
		drop_rpc.rpc(drop)
		await get_tree().create_timer(3.0, false).timeout
		if game_end or not is_inside_tree():
			return
		restore_rpc.rpc()
		await get_tree().create_timer(2.0, false).timeout

func lift_under(_position: Vector3) -> int:
	for i in LIFT_CENTERS.size():
		var local: Vector3 = _position - LIFT_CENTERS[i]
		if abs(local.x) <= LIFT_HALF and abs(local.z) <= LIFT_HALF:
			return i
	return -1

func pick_drops(counts: Array[int]) -> Array[int]:
	var occupied: Array[int] = []
	var top: int = 0
	for i in counts.size():
		if counts[i] > 0:
			occupied.append(i)
			top = max(top, counts[i])

	if occupied.is_empty():
		return []

	# alone in the game: one lift at random is rigged
	if player_count <= 1:
		return [randi() % counts.size()]

	var tied: Array[int] = []
	for i in occupied:
		if counts[i] == top:
			tied.append(i)

	if tied.size() == occupied.size():
		return [tied.pick_random()]
	return tied



@rpc("authority", "call_local", "reliable")
func choose_rpc(_turn: int):
	for i in lift_signs.size():
		lift_signs[i].text = LETTERS[i]
		lift_signs[i].modulate = Color(1.0, 0.8, 0.3)
		lift_lamps[i].light_color = Color(1.0, 0.6, 0.25)
	set_countdown_mesage_rpc("CHOISIS !", 0.8)

@rpc("authority", "call_local", "reliable")
func reveal_rpc(counts: Array, drop: Array):
	play_sound("alarm")
	for i in lift_signs.size():
		lift_signs[i].text = "%s : %d" % [LETTERS[i], counts[i]]
		if drop.has(i):
			lift_signs[i].modulate = Color(1.0, 0.2, 0.15)
			lift_lamps[i].light_color = Color(1.0, 0.1, 0.05)
			lift_lamps[i].light_energy = 9.0

@rpc("authority", "call_local", "reliable")
func drop_rpc(drop: Array):
	play_sound("fall")
	shake = min(shake + 0.7, 1.2)

	# the central floor always opens: standing nowhere is not a choice
	floor_shape.set_deferred("disabled", true)
	for side in hatch_meshes.size():
		var leaf: MeshInstance3D = hatch_meshes[side]
		var t := create_tween()
		t.tween_property(leaf, "rotation:z", (-1.0 if side == 0 else 1.0) * deg_to_rad(80.0), 0.35).set_ease(Tween.EASE_IN)

	for i in drop:
		lift_shapes[i].set_deferred("disabled", true)
		var t := create_tween()
		t.tween_property(lifts[i], "position:y", -30.0, 1.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)

@rpc("authority", "call_local", "reliable")
func restore_rpc():
	play_sound("lift")
	floor_shape.set_deferred("disabled", false)
	for leaf in hatch_meshes:
		create_tween().tween_property(leaf, "rotation:z", 0.0, 0.6)
	for i in lifts.size():
		lift_shapes[i].set_deferred("disabled", false)
		lift_lamps[i].light_energy = 3.0
		if lifts[i].position.y < 0.0:
			lifts[i].position.y = -12.0
			create_tween().tween_property(lifts[i], "position:y", 0.0, 1.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

@rpc("authority", "call_local", "reliable")
func sound_rpc(key: String):
	play_sound(key)
