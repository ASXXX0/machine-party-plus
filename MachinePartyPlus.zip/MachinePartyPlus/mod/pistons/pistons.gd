extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LES VERINS: the floor is a grid of hydraulic pistons. In waves, a pattern of them charges up (glows and
## shakes), then fires: anyone standing on a firing piston is launched high in a random direction, usually off
## the deck. Be in the air when it fires (jump at the right moment) and the piston passes harmlessly under you.
## Patterns get bigger and faster. Last one standing wins.

const N: int = 7
const TILE: float = 1.7
const FIRE_HEIGHT: float = 1.6

var tiles: Array[AnimatableBody3D] = []
var tile_materials: Array[StandardMaterial3D] = []
var tile_heights: Array[float] = []
var charging: Array = []
var charge_left: float = 0.0
var wave_timer: float = 2.5

func spawn_points() -> Array[Vector3]:
	return [tile_center(8), tile_center(12), tile_center(36), tile_center(40), tile_center(24)]

func tile_center(index: int) -> Vector3:
	var offset: float = (N - 1) * TILE * 0.5
	return Vector3((index % N) * TILE - offset, 0.1, (index / N) * TILE - offset)

func build_arena():

	max_duration = 120.0
	set_camera(Vector3(0.0, 16.0, 13.0), Vector3(0.0, -0.5, 0.8))

	add_sound("ambience", "res://audio/unique/disco dodge/dd ambience.ogg", -10.0, true)
	add_sound("charge", "res://audio/unique/disco dodge/dd piston arrive2.ogg", -4.0)
	add_sound("fire", "res://audio/unique/disco dodge/dd piston impact7.ogg", 0.0)
	add_sound("launch", "res://audio/unique/disco dodge/dd fall scream.ogg", -4.0)

	add_backdrop_model("res://minigames/dvd_roomba/models/dvd roomba visuals1.glb", Vector3(0.0, -7.0, -6.0))

	# the machine room under the deck
	add_box(Vector3(N * TILE + 1.0, 0.5, N * TILE + 1.0), Vector3(0.0, -3.0, 0.0), DA.kind_material("mp_dark"), null, false)

	var tile_mesh := BoxMesh.new()
	tile_mesh.size = Vector3(TILE - 0.08, 0.5, TILE - 0.08)
	var rod_mesh := CylinderMesh.new()
	rod_mesh.top_radius = 0.22
	rod_mesh.bottom_radius = 0.22
	rod_mesh.height = 3.0
	for index in N * N:
		var body := AnimatableBody3D.new()
		body.sync_to_physics = true
		body.position = tile_center(index) - Vector3(0.0, 0.1, 0.0)
		arena.add_child(body)
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = Vector3(TILE - 0.08, 0.5, TILE - 0.08)
		shape.shape = box
		shape.position.y = -0.25
		body.add_child(shape)
		var top := MeshInstance3D.new()
		top.mesh = tile_mesh
		var m: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_HAZARD, Color(0.95, 0.93, 0.9), 0.5)
		m.emission = Color(1.0, 0.45, 0.05)
		top.material_override = m
		top.position.y = -0.25
		body.add_child(top)
		var rod := MeshInstance3D.new()
		rod.mesh = rod_mesh
		rod.material_override = DA.kind_material("mp_rod")
		rod.position.y = -2.0
		body.add_child(rod)
		tiles.append(body)
		tile_materials.append(m)
		tile_heights.append(0.0)

	add_key_lights(Vector3(0.0, 12.0, 2.0), 70.0, 18.0)
	add_light(Vector3(0.0, -2.0, 0.0), Color(1.0, 0.5, 0.2), 12.0, 14.0)

	if Engine.has_meta("mpplus_preview"):
		charge_rpc(make_pattern(1), 9.0)

func on_play_start_local():
	fade_in_ambience()

## Random scatter, rows, columns, a checkerboard or rings, more of them as time goes.
func make_pattern(stage: int) -> Array:
	var picked: Array = []
	match randi() % (3 if stage == 0 else 5):
		0, 1:
			var share: float = min(0.25 + play_time * 0.004, 0.55)
			for index in N * N:
				if randf() < share:
					picked.append(index)
		2:
			var parity: int = randi() % 2
			for index in N * N:
				if (index % N + index / N) % 2 == parity:
					picked.append(index)
		3:
			var rows: Array = range(N)
			rows.shuffle()
			var columns: bool = randi() % 2 == 0
			for r in rows.slice(0, 2 + stage):
				for c in N:
					picked.append(c * N + r if columns else r * N + c)
		4:
			var ring: int = randi() % 4
			for index in N * N:
				var d: int = max(abs(index % N - 3), abs(index / N - 3))
				if d == ring or d == (ring + 2) % 4:
					picked.append(index)
	return picked

func server_tick(delta: float):
	if charge_left > 0.0:
		return
	wave_timer -= delta
	if wave_timer <= 0.0:
		var stage: int = 0 if play_time < 20.0 else (1 if play_time < 50.0 else 2)
		var charge_time: float = max(1.5 - play_time * 0.008, 0.75)
		charge_rpc.rpc(make_pattern(stage), charge_time)
		wave_timer = charge_time + max(2.2 - play_time * 0.012, 0.9)

@rpc("authority", "call_local", "reliable")
func charge_rpc(pattern: Array, charge_time: float):
	play_sound("charge")
	charging = pattern
	charge_left = charge_time
	for index in pattern:
		tile_materials[index].emission_enabled = true

func visual_tick(delta: float):

	if charge_left > 0.0:
		charge_left -= delta
		var energy: float = 1.0 + sin(Time.get_ticks_msec() / 40.0) * 0.8
		for index in charging:
			tile_materials[index].emission_energy_multiplier = energy
			(tiles[index].get_child(1) as Node3D).position.x = randf_range(-0.04, 0.04)
		if charge_left <= 0.0:
			fire(charging)

func fire(pattern: Array):
	play_sound("fire")
	shake = min(shake + 0.4, 1.2)
	for index in pattern:
		tile_materials[index].emission_enabled = false
		(tiles[index].get_child(1) as Node3D).position.x = 0.0
		var t := create_tween()
		t.tween_method(func(h): tile_heights[index] = h, 0.0, FIRE_HEIGHT, 0.1).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
		t.tween_interval(0.35)
		t.tween_method(func(h): tile_heights[index] = h, FIRE_HEIGHT, 0.0, 0.6).set_trans(Tween.TRANS_SINE)

	if not running:
		return
	# whoever stands on a firing piston is launched; whoever is in the air is fine
	for player in local_runners():
		var index: int = tile_at(player.global_position)
		if index >= 0 and pattern.has(index) and player.is_on_floor():
			sfx_rpc.rpc("launch")
			var angle: float = randf() * TAU
			# the shove resets velocity, so the lift comes after it
			push_runner(player, Vector3(cos(angle), 0.0, sin(angle)), 9.0)
			player.velocity.y = 12.0

func tile_at(position: Vector3) -> int:
	var offset: float = (N - 1) * TILE * 0.5
	var col: int = roundi((position.x + offset) / TILE)
	var row: int = roundi((position.z + offset) / TILE)
	if col < 0 or col >= N or row < 0 or row >= N:
		return -1
	return row * N + col

func _physics_process(_delta: float) -> void :
	if replaying:
		return
	for index in tiles.size():
		tiles[index].position.y = tile_heights[index]
