extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## CABLE SOUS TENSION: hot potato with a live cable. One runner carries the crackling cable; touching someone passes it on
## (a short grace stops an instant pass back). The fuse length is hidden; the beeps speed up near the end and
## whoever holds the cable when it blows is fried. Then a new cable goes to a random survivor, until one is left.
## Three arenas, drawn by the host: a fenced square, a round deck with pillars, a round deck with a sweeping arm.

const HOLDER_BOOST: float = 1.12
const PASS_DISTANCE: float = 1.15
const PASS_GRACE: float = 0.9

var layout: int = -1
var holder: int = -1
var fuse: float = 0.0
var fuse_total: float = 0.0
var grace: float = 0.0
var beep_timer: float = 0.0
var beep_interval: float = 1.0
var cable: Node3D
var spark: OmniLight3D
var arm: Node3D
var arm_angle: float = 0.0
var hit_timers: Dictionary = {}
var base_speed: Dictionary = {}

func spawn_points() -> Array[Vector3]:
	return [Vector3(-4, 0.1, -4), Vector3(4, 0.1, -4), Vector3(4, 0.1, 4), Vector3(-4, 0.1, 4), Vector3(0, 0.1, -5)]

func build_arena():
	max_duration = 150.0
	set_camera(Vector3(0.0, 17.0, 14.0), Vector3(0.0, -1.0, 0.8))
	add_sound("ambience", "res://audio/unique/chisel gauntlet/machine ambience.ogg", -8.0, true)
	add_sound("crackle", "res://audio/sfx/collar_activate.ogg", -6.0)
	add_sound("beep", "res://audio/sfx/ekg_beep.ogg", -6.0)
	add_sound("pass", "res://audio/unique/disco dodge/dd shove.ogg", -2.0)
	add_sound("blow", "res://audio/sfx/bad_explosion.ogg", 0.0)
	add_backdrop_model("res://minigames/exploding_collar_race/models/collar race van texture fix2/collar race van texture fix2.glb", Vector3(-15.0, -1.0, -12.0), 35.0)
	add_key_lights(Vector3(0.0, 12.0, 3.0), 90.0, 24.0)

	# the cable: a coil of glowing wire that rides on the holder's head
	cable = Node3D.new()
	var coil := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.28
	torus.outer_radius = 0.42
	coil.mesh = torus
	coil.material_override = DA.kind_material("mp_light")
	cable.add_child(coil)
	var plug := MeshInstance3D.new()
	var plug_mesh := BoxMesh.new()
	plug_mesh.size = Vector3(0.18, 0.18, 0.4)
	plug.mesh = plug_mesh
	plug.material_override = DA.kind_material("mp_hazard")
	plug.position = Vector3(0.38, 0.1, 0.0)
	cable.add_child(plug)
	spark = OmniLight3D.new()
	spark.light_color = Color(0.5, 0.8, 1.0)
	spark.light_energy = 3.0
	spark.omni_range = 4.0
	cable.add_child(spark)
	cable.visible = false
	arena.add_child(cable)

	if Engine.has_meta("mpplus_preview"):
		build_layout(2)
		cable.visible = true
		cable.position = Vector3(0, 2.6, 0)

func initialize(_round_number: int, _total_rounds: int, _scores: Dictionary = {}):
	layout_rpc.rpc(randi() % 3)
	super.initialize(_round_number, _total_rounds, _scores)

@rpc("authority", "call_local", "reliable")
func layout_rpc(index: int):
	build_layout(index)

func build_layout(index: int):
	if layout != -1:
		return
	layout = index
	var floor_material: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_MARKED, Color(1.0, 0.95, 0.9), 0.5)
	floor_material.uv1_offset = Vector3.ONE * 0.5
	match index:
		0:
			# the fenced square: no edge to fall from, only the cable
			add_box(Vector3(14.0, 0.6, 14.0), Vector3(0, -0.3, 0), floor_material)
			for side in [-1.0, 1.0]:
				add_box(Vector3(0.3, 1.0, 14.0), Vector3(side * 7.15, 0.5, 0), DA.kind_material("mp_hazard"))
				add_box(Vector3(14.6, 1.0, 0.3), Vector3(0, 0.5, side * 7.15), DA.kind_material("mp_hazard"))
			for p in [Vector3(-2.5, 0, 0), Vector3(2.5, 0, 0)]:
				add_box(Vector3(1.2, 1.2, 1.2), p + Vector3(0, 0.6, 0), DA.kind_material("mp_metal"))
		_:
			# a round deck, open edges
			var body := StaticBody3D.new()
			arena.add_child(body)
			var shape := CollisionShape3D.new()
			var cylinder := CylinderShape3D.new()
			cylinder.radius = 8.0
			cylinder.height = 0.6
			shape.shape = cylinder
			shape.position.y = -0.3
			body.add_child(shape)
			var deck := MeshInstance3D.new()
			var deck_mesh := CylinderMesh.new()
			deck_mesh.top_radius = 8.0
			deck_mesh.bottom_radius = 8.0
			deck_mesh.height = 0.6
			deck_mesh.radial_segments = 48
			deck.mesh = deck_mesh
			deck.material_override = floor_material
			deck.position.y = -0.3
			arena.add_child(deck)
			var ring := MeshInstance3D.new()
			var ring_mesh := TorusMesh.new()
			ring_mesh.inner_radius = 7.8
			ring_mesh.outer_radius = 8.1
			ring.mesh = ring_mesh
			ring.material_override = DA.kind_material("mp_hazard")
			ring.scale = Vector3(1, 0.4, 1)
			arena.add_child(ring)
			if index == 1:
				for k in 5:
					var angle: float = k * TAU / 5.0
					var pillar := MeshInstance3D.new()
					var pillar_mesh := CylinderMesh.new()
					pillar_mesh.top_radius = 0.55
					pillar_mesh.bottom_radius = 0.55
					pillar_mesh.height = 2.5
					pillar.mesh = pillar_mesh
					pillar.material_override = DA.kind_material("mp_metal")
					var pillar_body := StaticBody3D.new()
					pillar_body.position = Vector3(cos(angle), 0, sin(angle)) * 4.0 + Vector3(0, 1.25, 0)
					arena.add_child(pillar_body)
					var pillar_shape := CollisionShape3D.new()
					var pillar_cylinder := CylinderShape3D.new()
					pillar_cylinder.radius = 0.55
					pillar_cylinder.height = 2.5
					pillar_shape.shape = pillar_cylinder
					pillar_body.add_child(pillar_shape)
					pillar_body.add_child(pillar)
			else:
				arena.add_child(DA.load_model("sweeper_hub.glb"))
				arm = Node3D.new()
				arm.add_child(DA.load_model("sweeper_arm.glb"))
				# the sweeper arm is built for a 10 m deck
				arm.scale = Vector3(0.8, 1.0, 0.8)
				arena.add_child(arm)

func on_play_start_local():
	fade_in_ambience()

func on_server_play_start():
	new_cable()

## A fresh cable for a random survivor, with a hidden fuse.
func new_cable():
	var alive: Array = active_players.keys()
	if alive.size() < 1 or game_end:
		return
	fuse_total = randf_range(11.0, 19.0) - min(play_time * 0.03, 4.0)
	fuse = fuse_total
	pace_rpc.rpc(1.0)
	give_rpc.rpc(alive.pick_random(), true)

@rpc("authority", "call_local", "reliable")
func give_rpc(network_id: int, fresh: bool):
	# the holder runs a little faster
	if holder != -1 and players.has(holder) and base_speed.has(holder):
		players[holder].speed = base_speed[holder]
	holder = network_id
	grace = PASS_GRACE
	play_sound("crackle" if fresh else "pass")
	cable.visible = holder != -1
	if holder != -1 and players.has(holder):
		var runner = players[holder]
		base_speed[holder] = base_speed.get(holder, runner.speed)
		runner.speed = base_speed[holder] * HOLDER_BOOST
		if fresh:
			set_countdown_mesage_rpc("%s A LE CABLE !" % player_name(holder).to_upper(), 1.0)

func server_tick(delta: float):
	if holder == -1:
		return
	var runner = players.get(holder, null)
	if not is_instance_valid(runner) or not runner.active:
		# the holder fell off: the cable goes to someone else
		give_rpc.rpc(-1, false)
		await get_tree().create_timer(1.0, false).timeout
		new_cable()
		return
	fuse -= delta
	grace = max(grace - delta, 0.0)
	var interval: float = 0.25 if fuse < 2.0 else (0.45 if fuse < 5.0 else 1.0)
	if interval != beep_interval:
		pace_rpc.rpc(interval)
	if fuse <= 0.0:
		var victim: int = holder
		give_rpc.rpc(-1, false)
		sfx_rpc.rpc("blow")
		crush(victim)
		await get_tree().create_timer(2.0, false).timeout
		if not game_end and active_players.size() > 1:
			new_cable()
		return
	if grace > 0.0:
		return
	for network_id in active_players.keys():
		if network_id == holder:
			continue
		var other = active_players[network_id]
		if is_instance_valid(other) and other.active and other.global_position.distance_to(runner.global_position) < PASS_DISTANCE:
			give_rpc.rpc(network_id, false)
			break

@rpc("authority", "call_local", "reliable")
func pace_rpc(interval: float):
	beep_interval = interval

func visual_tick(delta: float):
	if holder != -1 and players.has(holder) and is_instance_valid(players[holder]):
		cable.global_position = players[holder].global_position + Vector3(0, 2.5, 0)
		cable.rotation.y += delta * 6.0
		spark.light_energy = randf_range(1.5, 6.0)
		# the beeps quicken as the (hidden) fuse runs out; peers only hear the pace
		beep_timer -= delta
		if beep_timer <= 0.0:
			beep_timer = beep_interval
			play_sound("beep")
	if layout == 2 and arm:
		arm_angle += delta * (0.9 + min(play_time * 0.02, 1.5))
		arm.rotation.y = arm_angle
		if running:
			for player in local_runners():
				sweep(player, delta)

func sweep(player, delta: float):
	var network_id: int = player.player_presence.network_id
	hit_timers[network_id] = max(hit_timers.get(network_id, 0.0) - delta, 0.0)
	if hit_timers[network_id] > 0.0 or player.global_position.y > 0.55:
		return
	var flat := Vector3(player.global_position.x, 0.0, player.global_position.z)
	if flat.length() < 0.8 or flat.length() > 8.3:
		return
	var direction := Vector3(cos(arm_angle), 0.0, - sin(arm_angle))
	if flat.dot(direction) < 0.0 or abs(flat.cross(direction).y) > 0.75:
		return
	hit_timers[network_id] = 0.7
	push_runner(player, Vector3(- sin(arm_angle), 0.0, - cos(arm_angle)) + flat.normalized() * 0.6, 15.0)
