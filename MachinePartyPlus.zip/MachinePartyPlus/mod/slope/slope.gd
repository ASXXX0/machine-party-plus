extends "user://mods/machine_party_unlocked/common/mp_base.gd"

## LA PENTE: a steel ramp tilted toward the camera, over a drop. Everyone keeps sliding down a little, so you
## have to keep walking up. Bolts appear on the ramp: grab them for points. Steel balls are released at the top
## (their chute lamp flashes first) and roll straight down, knocking whoever they hit down the slope.
## Falling off the bottom ends your run (your bolts still count). Most bolts wins.

const HALF_X: float = 7.0
const HALF_Z: float = 8.0
const TILT: float = 0.21
const SLIDE: float = 1.4
const BALL_RADIUS: float = 0.75
const LANES: int = 7

var ramp: Node3D
var balls: Dictionary = {}
var next_ball: int = 0
var ball_timer: float = 3.0
var bolt: Node3D
var bolt_position: Vector3 = Vector3.INF
var chute_lamps: Array[OmniLight3D] = []
var hit_timers: Dictionary = {}

func spawn_points() -> Array[Vector3]:
	return [ramp_point(-4.0, 0.0), ramp_point(4.0, 0.0), ramp_point(-1.5, 2.0), ramp_point(1.5, 2.0), ramp_point(0.0, -2.0)]

## A point on the ramp surface: x across, d along the slope (negative = up the ramp).
func ramp_point(x: float, d: float) -> Vector3:
	return Vector3(x, - d * sin(TILT) + 0.15, d * cos(TILT))

func fall_height() -> float:
	return -9.0

func build_arena():

	max_duration = 75.0
	set_camera(Vector3(0.0, 12.0, 17.0), Vector3(0.0, 0.0, 0.0))

	add_sound("ambience", "res://audio/unique/dvd roomba/dvd roomba ambience.ogg", -8.0, true)
	add_sound("release", "res://audio/unique/232136__yottasounds__rolling-cart-002.ogg", -2.0)
	add_sound("hit", "res://audio/unique/disco dodge/dd fall scream impact.ogg", -2.0)
	add_sound("bolt", "res://audio/sfx/manufacture_gun_correct_item_inserted.ogg", -2.0)
	add_sound("warn", "res://audio/sfx/burn_recycle/beep.ogg", -8.0)

	# the train race tunnel around the ramp
	add_backdrop_model("res://minigames/train_race/models/train race visuals1/train race visuals1.glb", Vector3(0.0, -4.0, 6.0))

	ramp = Node3D.new()
	ramp.rotation.x = TILT
	arena.add_child(ramp)
	var deck: StandardMaterial3D = DA.base_material(DA.TEX_FLOOR_HAZARD, Color(0.95, 0.93, 0.9), 1.0 / 7.0)
	add_box(Vector3(HALF_X * 2.0, 0.6, HALF_Z * 2.0), Vector3(0.0, -0.3, 0.0), deck, ramp)
	for side in [-1.0, 1.0]:
		add_box(Vector3(0.3, 1.0, HALF_Z * 2.0), Vector3(side * (HALF_X + 0.15), 0.5, 0.0), DA.kind_material("mp_hazard"), ramp)
	# the top wall with its ball chutes
	add_box(Vector3(HALF_X * 2.0 + 0.6, 2.4, 0.5), Vector3(0.0, 1.2, - HALF_Z - 0.25), DA.kind_material("mp_metal"), ramp)
	for lane in LANES:
		var x: float = lane_x(lane)
		var mouth := add_box(Vector3(1.6, 1.7, 0.3), Vector3(x, 0.85, - HALF_Z + 0.02), unshaded(Color(0.05, 0.05, 0.05)), ramp, false)
		var lamp := OmniLight3D.new()
		lamp.position = Vector3(x, 2.1, - HALF_Z + 0.4)
		lamp.light_color = Color(1.0, 0.3, 0.1)
		lamp.light_energy = 0.0
		lamp.omni_range = 4.0
		ramp.add_child(lamp)
		chute_lamps.append(lamp)
	# ridges: grip lines across the ramp
	for k in 7:
		add_box(Vector3(HALF_X * 2.0, 0.04, 0.12), Vector3(0.0, 0.01, - HALF_Z + 2.0 + k * 2.0), DA.kind_material("mp_dark"), ramp, false)

	bolt = DA.load_model("part.glb")
	bolt.scale = Vector3.ONE * 0.9
	bolt.visible = false
	var glow := OmniLight3D.new()
	glow.light_color = Color(1.0, 0.8, 0.3)
	glow.light_energy = 2.5
	glow.omni_range = 3.0
	glow.position.y = 0.6
	bolt.add_child(glow)
	arena.add_child(bolt)

	add_key_lights(Vector3(0.0, 12.0, 0.0), 75.0, 20.0)

	if Engine.has_meta("mpplus_preview"):
		place_bolt_rpc(ramp_point(2.0, 1.0))
		spawn_ball_rpc(0, 2)
		balls[0].d = -2.0

func lane_x(lane: int) -> float:
	return - HALF_X + (lane + 0.5) * (HALF_X * 2.0 / LANES)

func on_play_start_local():
	fade_in_ambience()
	build_hud(true)

func on_server_play_start():
	new_bolt()

func server_tick(delta: float):

	ball_timer -= delta
	if ball_timer <= 0.0:
		ball_timer = max(2.2 - play_time * 0.02, 0.8)
		var lane: int = randi() % LANES
		warn_lane_rpc.rpc(lane)
		release_later(lane)

	for network_id in active_players.keys():
		var player = active_players[network_id]
		if not is_instance_valid(player) or not player.active:
			continue
		if bolt_position != Vector3.INF and player.global_position.distance_to(bolt_position) < 1.0:
			add_points(network_id)
			sfx_rpc.rpc("bolt")
			new_bolt()

func release_later(lane: int):
	await get_tree().create_timer(0.9, false).timeout
	if game_end or not is_inside_tree():
		return
	spawn_ball_rpc.rpc(next_ball, lane)
	next_ball += 1

func new_bolt():
	bolt_position = ramp_point(randf_range(- HALF_X + 1.0, HALF_X - 1.0), randf_range(- HALF_Z + 2.5, HALF_Z - 2.0))
	place_bolt_rpc.rpc(bolt_position)

@rpc("authority", "call_local", "reliable")
func place_bolt_rpc(position: Vector3):
	bolt.position = position
	bolt.visible = true

@rpc("authority", "call_local", "reliable")
func warn_lane_rpc(lane: int):
	play_sound("warn")
	var lamp: OmniLight3D = chute_lamps[lane]
	var t := lamp.create_tween()
	t.tween_property(lamp, "light_energy", 9.0, 0.15)
	t.tween_property(lamp, "light_energy", 2.0, 0.15)
	t.tween_property(lamp, "light_energy", 9.0, 0.15)
	t.tween_property(lamp, "light_energy", 0.0, 0.5)

@rpc("authority", "call_local", "reliable")
func spawn_ball_rpc(id: int, lane: int):
	play_sound("release")
	var ball := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = BALL_RADIUS
	sphere.height = BALL_RADIUS * 2.0
	ball.mesh = sphere
	ball.material_override = DA.kind_material("mp_rod")
	ramp.add_child(ball)
	balls[id] = {"node": ball, "x": lane_x(lane), "d": - HALF_Z + 0.8, "speed": 3.0 + play_time * 0.05}
	ball.position = Vector3(balls[id].x, BALL_RADIUS, balls[id].d)

func visual_tick(delta: float):

	if bolt.visible:
		bolt.rotation.y += delta * 2.0

	for id in balls.keys():
		var ball: Dictionary = balls[id]
		ball.speed = min(ball.speed + 6.0 * delta, 14.0)
		ball.d += ball.speed * delta
		ball.node.position = Vector3(ball.x, BALL_RADIUS, ball.d)
		ball.node.rotation.x += ball.speed * delta / BALL_RADIUS
		if ball.d > HALF_Z + 3.0:
			ball.node.queue_free()
			balls.erase(id)

	if not running:
		return

	var downhill := Vector3(0.0, 0.0, 1.0)
	for player in local_runners():
		var network_id: int = player.player_presence.network_id
		if player.is_on_floor():
			player.move_and_collide(downhill * SLIDE * delta)
		hit_timers[network_id] = max(hit_timers.get(network_id, 0.0) - delta, 0.0)
		if hit_timers[network_id] > 0.0:
			continue
		var local: Vector3 = ramp.to_local(player.global_position)
		for ball in balls.values():
			if Vector2(local.x - ball.x, local.z - ball.d).length() < BALL_RADIUS + 0.4 and player.global_position.y < ramp.to_global(Vector3(ball.x, BALL_RADIUS * 2.0, ball.d)).y:
				hit_timers[network_id] = 0.8
				sfx_rpc.rpc("hit")
				push_runner(player, Vector3(sign(local.x - ball.x) * 0.4, 0.0, 1.0), 12.0 + ball.speed * 0.6)
				break

func compute_scores() -> Dictionary[int, int]:
	return rank_scores(points)

func check_game_end_on_death():
	if game_end:
		return
	if active_players.is_empty():
		end_game()
