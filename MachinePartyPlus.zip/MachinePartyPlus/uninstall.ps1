﻿# Machine Party+ : désinstallation. Retire override.cfg (le jeu redevient normal) et les fichiers du mod.

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$marker = "; machine-party-unlocked"
. (Join-Path $here "find_game.ps1")

Write-Host ""
Write-Host "=== Machine Party+ : désinstallation ===" -ForegroundColor Cyan
Write-Host ""

$gameDir = Find-GameDir
if (-not $gameDir) {
	$gameDir = (Read-Host "Colle le chemin du dossier qui contient 'Machine Party.exe'").Trim('"', ' ')
}
$cfg = Join-Path $gameDir "override.cfg"
if ((Test-Path $cfg) -and ((Get-Content $cfg -Raw).Contains($marker))) {
	Remove-Item $cfg -Force
	Write-Host "override.cfg retiré : le jeu est revenu à la normale." -ForegroundColor Green
} else {
	Write-Host "Pas d'override.cfg du mod dans $gameDir."
}

$modDir = Join-Path $env:APPDATA "Godot\app_userdata\Machine Party\mods\machine_party_unlocked"
if (Test-Path $modDir) {
	Remove-Item $modDir -Recurse -Force
	Write-Host "Fichiers du mod supprimés." -ForegroundColor Green
}
Write-Host ""
Read-Host "Appuie sur Entrée pour fermer"
