﻿# Machine Party+ : installation du mod sur ton propre jeu.
#
# Ce paquet ne contient aucun fichier du jeu. Le script :
#   1. trouve Machine Party dans ta bibliothèque Steam ;
#   2. télécharge GDRE Tools 2.7.4 depuis GitHub (vérifié par SHA-256) et décompile les quelques scripts du jeu
#      à modifier, depuis TA copie du jeu ;
#   3. applique les modifications du mod (edits.json) et installe le mod dans
#      %APPDATA%\Godot\app_userdata\Machine Party\mods\ ;
#   4. ajoute override.cfg à côté de "Machine Party.exe" (c'est ce fichier qui active le mod).
# Pour retirer le mod : Desinstaller.bat.

param([string]$GameDir = "", [switch]$NoPause)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$utf8 = New-Object System.Text.UTF8Encoding $false
$marker = "; machine-party-unlocked"
. (Join-Path $here "find_game.ps1")

function Say([string]$message, [string]$color = "Gray") { Write-Host $message -ForegroundColor $color }
function Fail([string]$message) {
	Say ""
	Say "ERREUR : $message" Red
	Say ""
	Read-Host "Appuie sur Entrée pour fermer"
	exit 1
}

function Read-AllText([string]$path) { return ([System.IO.File]::ReadAllText($path, $utf8)).Replace("`r`n", "`n") }
function Write-AllText([string]$path, [string]$text) {
	$dir = Split-Path -Parent $path
	if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
	[System.IO.File]::WriteAllText($path, $text, $utf8)
}

Say ""
Say "=== Machine Party+ : installation ===" Cyan
Say ""

$data = Read-AllText (Join-Path $here "edits.json") | ConvertFrom-Json
Say ("Version du mod : {0} (pour Machine Party {1})" -f $data.mod_version, $data.game_version)

# 1. the game
if (-not $GameDir) { $GameDir = Find-GameDir }
if (-not $GameDir -or -not (Test-Path (Join-Path $GameDir "Machine Party.exe"))) {
	Say "Je n'ai pas trouvé Machine Party automatiquement." Yellow
	$GameDir = Read-Host "Colle le chemin du dossier qui contient 'Machine Party.exe'"
	$GameDir = $GameDir.Trim('"', ' ')
}
$pck = Join-Path $GameDir "Machine Party.pck"
if (-not (Test-Path (Join-Path $GameDir "Machine Party.exe")) -or -not (Test-Path $pck)) {
	Fail "Machine Party introuvable dans '$GameDir'."
}
Say "Jeu trouvé : $GameDir" Green

while (Get-Process -Name "Machine Party" -ErrorAction SilentlyContinue) {
	Read-Host "Machine Party est ouvert : ferme le jeu puis appuie sur Entrée"
}

# 2. GDRE Tools, from its official GitHub release
$work = Join-Path $env:TEMP "MachinePartyPlus"
New-Item -ItemType Directory -Force -Path $work | Out-Null
$zip = Join-Path $work "gdre.zip"
$gdreDir = Join-Path $work "gdre"
$gdre = Join-Path $gdreDir "gdre_tools.exe"
$haveZip = (Test-Path $zip) -and ((Get-FileHash $zip -Algorithm SHA256).Hash -eq $data.gdre_sha256.ToUpper())
if (-not $haveZip) {
	Say "Téléchargement de GDRE Tools 2.7.4 (42 Mo, github.com/GDRETools/gdsdecomp)..."
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	$ProgressPreference = "SilentlyContinue"
	try { Invoke-WebRequest -Uri $data.gdre_url -OutFile $zip -UseBasicParsing }
	catch { Fail "le téléchargement de GDRE Tools a échoué : $($_.Exception.Message)" }
	if ((Get-FileHash $zip -Algorithm SHA256).Hash -ne $data.gdre_sha256.ToUpper()) {
		Remove-Item $zip -Force
		Fail "le fichier téléchargé ne correspond pas à la version attendue (SHA-256)."
	}
}
if (-not (Test-Path $gdre)) {
	if (Test-Path $gdreDir) { Remove-Item $gdreDir -Recurse -Force }
	Expand-Archive -Path $zip -DestinationPath $gdreDir -Force
	$found = Get-ChildItem -Path $gdreDir -Recurse -Filter "gdre_tools.exe" | Select-Object -First 1
	if (-not $found) { Fail "gdre_tools.exe introuvable dans l'archive." }
	$gdre = $found.FullName
}
$gdre = (Get-ChildItem -Path $gdreDir -Recurse -Filter "gdre_tools.exe" | Select-Object -First 1).FullName

# 3. decompile only the scripts the mod changes, from the player's own copy
$decomp = Join-Path $work "decomp"
if (Test-Path $decomp) { Remove-Item $decomp -Recurse -Force }
$arguments = @("--headless", "--recover=`"$pck`"", "--output=`"$decomp`"")
foreach ($file in $data.files) { $arguments += ("--include=`"{0}c`"" -f $file.res) }
Say "Décompilation des scripts à modifier (ça prend une minute)..."
$log = Join-Path $work "gdre.log"
$process = Start-Process -FilePath $gdre -ArgumentList $arguments -Wait -PassThru -NoNewWindow -RedirectStandardOutput $log -RedirectStandardError (Join-Path $work "gdre.err.log")
foreach ($file in $data.files) {
	$source = Join-Path $decomp ($file.res.Replace("res://", "").Replace("/", "\"))
	if (-not (Test-Path $source)) { Fail ("la décompilation n'a pas produit {0} (voir {1})." -f $file.res, $log) }
}

# 4. apply the edits and install the mod
$modDir = Join-Path $env:APPDATA ("Godot\app_userdata\Machine Party\mods\" + $data.mod_dir)
Say "Installation dans $modDir"
New-Item -ItemType Directory -Force -Path $modDir | Out-Null
Copy-Item -Path (Join-Path $here "mod\*") -Destination $modDir -Recurse -Force

foreach ($file in $data.files) {
	$source = Join-Path $decomp ($file.res.Replace("res://", "").Replace("/", "\"))
	$text = Read-AllText $source
	foreach ($edit in $file.edits) {
		$old = [string]$edit[0]
		$new = [string]$edit[1]
		$at = $text.IndexOf($old, [System.StringComparison]::Ordinal)
		if ($at -lt 0 -or $text.IndexOf($old, $at + 1, [System.StringComparison]::Ordinal) -ge 0) {
			Fail ("ton jeu n'est pas la version {0} attendue ({1} ne correspond pas). Mets le jeu à jour ou demande une nouvelle version du mod." -f $data.game_version, $file.res)
		}
		$text = $text.Substring(0, $at) + $new + $text.Substring($at + $old.Length)
	}
	Write-AllText (Join-Path $modDir ($file.out.Replace("/", "\"))) $text
}
Write-AllText (Join-Path $modDir "patches\list.txt") (($data.patch_list -join "`n") + "`n")

# 5. activate it
$cfg = Join-Path $GameDir "override.cfg"
if ((Test-Path $cfg) -and -not ((Read-AllText $cfg).Contains($marker))) {
	Fail "un fichier override.cfg qui ne vient pas de ce mod existe déjà dans le dossier du jeu. Je n'y touche pas."
}
$override = "$marker`n[autoload]`n`nGlobals=`"*user://mods/$($data.mod_dir)/globals.gd`"`nMachinePartyMod=`"*user://mods/$($data.mod_dir)/mod_main.gd`"`n"
try { Write-AllText $cfg $override }
catch { Fail "impossible d'écrire $cfg. Relance Installer.bat en clic droit > Exécuter en tant qu'administrateur." }

Say ""
Say "C'est installé ! Lance Machine Party depuis Steam." Green
Say ("En bas à droite du menu tu dois voir : {0}-{1}" -f $data.mod_version, $data.game_version) Green
Say "Pour jouer ensemble, tout le monde doit avoir exactement cette version."
Say ""
if (-not $NoPause) { Read-Host "Appuie sur Entrée pour fermer" }
